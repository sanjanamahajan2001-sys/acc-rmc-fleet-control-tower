import React, { useEffect, useState } from 'react';
import { PageContainer } from '../../../layouts/PageContainer';
import { Button } from '../../../components/inputs/Button';
import { useReportsStore } from '../store/reports.store';
import { ReportCatalogGrid } from '../components/ReportCatalogGrid';
import { ReportExecutionHistoryTable } from '../components/ReportExecutionHistoryTable';
import { ReportExportModal } from '../components/ReportExportModal';

import { ReportDefinitionDTO } from '../types/report.types';
import { adaptFilterStateToReportScope } from '../utils/reportScopeAdapter';
import { useDashboardFilters } from '../../site_dashboard/orchestration/DashboardFilterProvider';
import { GlobalDashboardFilterBar } from '../../site_dashboard/components/GlobalDashboardFilterBar';
import { RefreshCw, FileSpreadsheet } from 'lucide-react';

export const ReportsManagementPage: React.FC = () => {
  const { catalog, isCatalogLoading, catalogError, loadCatalog } = useReportsStore();
  const { filters } = useDashboardFilters();

  const [selectedReport, setSelectedReport] = useState<ReportDefinitionDTO | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    loadCatalog();
  }, [loadCatalog]);

  const handleExportSelect = (report: ReportDefinitionDTO) => {
    setSelectedReport(report);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedReport(null);
  };

  const currentScope = adaptFilterStateToReportScope(filters);

  return (
    <PageContainer title="Reports & Export Management">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
        {/* Global Operational Dashboard Filter Bar */}
        <GlobalDashboardFilterBar />

        {/* Workspace Subheader */}

        <div
          style={{
            display: 'flex',
            justify: 'space-between',
            alignItems: 'center',
            backgroundColor: '#0F172A',
            padding: 16,
            borderRadius: 8,
            border: '1px solid #1E293B',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ padding: 10, borderRadius: 8, backgroundColor: 'rgba(56, 189, 248, 0.1)', color: '#38BDF8' }}>
              <FileSpreadsheet size={24} />
            </div>
            <div>
              <h2 style={{ fontSize: 16, fontWeight: 600, color: '#F8FAFC' }}>Authoritative Report Catalog</h2>
              <p style={{ fontSize: 12, color: '#94A3B8' }}>
                Browse, generate, and export certified operational reports for Fleet Control Tower
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => loadCatalog()}
            disabled={isCatalogLoading}
            icon={<RefreshCw size={14} className={isCatalogLoading ? 'animate-spin' : ''} />}
            data-testid="refresh-catalog-btn"
          >
            Refresh Catalog
          </Button>
        </div>

        {/* Loading State */}
        {isCatalogLoading && catalog.length === 0 && (
          <div
            style={{ padding: 40, textAlign: 'center', color: '#38BDF8', fontSize: 14 }}
            data-testid="catalog-loading-state"
          >
            Loading backend report catalog...
          </div>
        )}

        {/* Error State */}
        {catalogError && (
          <div
            style={{
              backgroundColor: 'rgba(239, 68, 68, 0.1)',
              border: '1px solid rgba(239, 68, 68, 0.3)',
              color: '#F87171',
              padding: 16,
              borderRadius: 8,
              fontSize: 14,
              display: 'flex',
              justify: 'space-between',
              alignItems: 'center',
            }}
            data-testid="catalog-error-banner"
          >
            <span>{catalogError}</span>
            <Button variant="danger" size="sm" onClick={() => loadCatalog()}>
              Retry
            </Button>
          </div>
        )}

        {/* Catalog Grid */}
        {!isCatalogLoading && !catalogError && (
          <ReportCatalogGrid catalog={catalog} onExportSelect={handleExportSelect} />
        )}

        {/* Real-Time Execution History Section */}
        <div style={{ marginTop: 16 }}>
          <ReportExecutionHistoryTable
            executions={Object.values(useReportsStore.getState().executions)}
            onRefresh={() => loadCatalog()}
          />
        </div>

        {/* Reusable Export Modal Integration */}
        {selectedReport && (
          <ReportExportModal
            isOpen={isModalOpen}
            onClose={handleCloseModal}
            reportId={selectedReport.report_id}
            reportDefinition={selectedReport}
            scope={currentScope}
          />
        )}

      </div>
    </PageContainer>
  );
};
