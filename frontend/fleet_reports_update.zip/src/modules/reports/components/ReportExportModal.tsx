import React, { useState, useEffect } from 'react';
import { Modal } from '../../../components/overlays/Modal';
import { Button } from '../../../components/inputs/Button';
import { Select } from '../../../components/inputs/Select';
import {
  ReportDefinitionDTO,
  ReportFormat,
  ReportScopeDTO,
  ReportStatus,
  ReportExecutionResponse,
} from '../types/report.types';
import { reportsApiClient } from '../api/reports.api';
import { useReportsStore } from '../store/reports.store';
import { useReportExecutionPoll, isTerminalStatus } from '../hooks/useReportExecutionPoll';
import { downloadReportArtifact } from '../utils/downloadReportArtifact';

export interface ReportExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportId: string;
  reportDefinition?: ReportDefinitionDTO | null;
  scope?: ReportScopeDTO;
  requestedBy?: string;
  onExportSuccess?: (execution: ReportExecutionResponse) => void;
  onExportError?: (error: any) => void;
}

export const ReportExportModal: React.FC<ReportExportModalProps> = ({
  isOpen,
  onClose,
  reportId,
  reportDefinition,
  scope = {},
  requestedBy = 'SYSTEM',
  onExportSuccess,
  onExportError,
}) => {
  const [selectedFormat, setSelectedFormat] = useState<ReportFormat>(ReportFormat.PDF);
  const [activeExecutionId, setActiveExecutionId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submissionError, setSubmissionError] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  const addExecution = useReportsStore((s) => s.addExecution);

  const { execution, isPolling, isTerminal, pollingError } = useReportExecutionPoll({
    executionId: activeExecutionId,
    enabled: Boolean(activeExecutionId),
    intervalMs: 1500,
  });

  // Format selection options based on report definition or default
  const supportedFormats = reportDefinition?.supported_formats || [
    ReportFormat.PDF,
    ReportFormat.XLSX,
    ReportFormat.JSON,
  ];

  useEffect(() => {
    if (!isOpen) {
      setActiveExecutionId(null);
      setIsSubmitting(false);
      setSubmissionError(null);
      setIsDownloading(false);
    }
  }, [isOpen]);

  const handleGenerate = async () => {
    if (isSubmitting || activeExecutionId) return;

    setIsSubmitting(true);
    setSubmissionError(null);

    try {
      const response = await reportsApiClient.generateReportAsync({
        report_id: reportId,
        format: selectedFormat,
        scope,
        requested_by: requestedBy,
      });

      addExecution(response);
      setActiveExecutionId(response.execution_id);
    } catch (err: any) {
      const errMsg = err.message || 'Failed to submit report execution request';
      setSubmissionError(errMsg);
      if (onExportError) onExportError(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDownload = async () => {
    if (!activeExecutionId || isDownloading) return;
    setIsDownloading(true);
    try {
      await downloadReportArtifact({
        executionId: activeExecutionId,
        format: selectedFormat,
        reportId,
        onSuccess: () => {
          if (execution && onExportSuccess) onExportSuccess(execution);
        },
      });
    } catch (err: any) {
      if (onExportError) onExportError(err);
    } finally {
      setIsDownloading(false);
    }
  };

  const formatOptions = supportedFormats.map((fmt) => ({
    value: fmt,
    label: fmt,
  }));

  const getStatusDisplay = () => {
    if (isSubmitting) return 'Submitting request...';
    if (!execution) return null;

    switch (execution.status) {
      case ReportStatus.QUEUED:
        return 'Report queued in background...';
      case ReportStatus.PROCESSING:
      case ReportStatus.RUNNING:
        return 'Generating report...';
      case ReportStatus.COMPLETED:
        return 'Report generation complete!';
      case ReportStatus.NO_DATA:
        return 'Report generated with no matching data.';
      case ReportStatus.FAILED:
        return `Report generation failed: ${execution.error_message || execution.error_code || 'Internal Error'}`;
      case ReportStatus.SCOPE_VALIDATION_FAILED:
        return `Scope Validation Failed: ${execution.error_message || 'Invalid parameters'}`;
      default:
        return `Status: ${execution.status}`;
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Export Report — ${reportDefinition?.title || reportId}`}
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={isSubmitting || isDownloading}>
            Close
          </Button>
          {!activeExecutionId && (
            <Button
              variant="primary"
              onClick={handleGenerate}
              disabled={isSubmitting}
              data-testid="export-modal-submit-button"
            >
              {isSubmitting ? 'Submitting...' : 'Generate & Export'}
            </Button>
          )}
          {execution?.status === ReportStatus.COMPLETED && (
            <Button
              variant="primary"
              onClick={handleDownload}
              disabled={isDownloading}
              data-testid="export-modal-download-button"
            >
              {isDownloading ? 'Downloading...' : 'Download File'}
            </Button>
          )}
        </>
      }
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div>
          <label style={{ fontSize: 12, color: '#94A3B8', marginBottom: 6, display: 'block' }}>
            Export Format
          </label>
          <Select
            value={selectedFormat}
            onChange={(e) => setSelectedFormat(e.target.value as ReportFormat)}
            options={formatOptions}
            disabled={isSubmitting || Boolean(activeExecutionId)}
            data-testid="export-modal-format-select"
          />
        </div>

        {/* Scope Context Information */}
        <div
          style={{
            backgroundColor: '#0F172A',
            padding: 12,
            borderRadius: 6,
            border: '1px solid #1E293B',
            fontSize: 12,
            color: '#94A3B8',
          }}
        >
          <div style={{ fontWeight: 600, color: '#CBD5E1', marginBottom: 4 }}>Applied Scope</div>
          <div>Plant: {scope.plant_id || 'ALL'}</div>
          <div>Customer: {scope.customer_id || 'ALL'}</div>
          <div>Date: {scope.operation_date || '2026-08-05'}</div>
        </div>

        {/* Status / Feedback Banner */}
        {(submissionError || pollingError) && (
          <div
            style={{
              backgroundColor: 'rgba(239, 68, 68, 0.1)',
              border: '1px solid rgba(239, 68, 68, 0.3)',
              color: '#F87171',
              padding: 10,
              borderRadius: 6,
              fontSize: 13,
            }}
            data-testid="export-modal-error-banner"
          >
            {submissionError || pollingError}
          </div>
        )}

        {activeExecutionId && (
          <div
            style={{
              backgroundColor: 'rgba(56, 189, 248, 0.08)',
              border: '1px solid rgba(56, 189, 248, 0.2)',
              color: '#38BDF8',
              padding: 12,
              borderRadius: 6,
              fontSize: 13,
            }}
            data-testid="export-modal-status-banner"
          >
            <div style={{ fontWeight: 600 }}>{getStatusDisplay()}</div>
            {isPolling && <div style={{ fontSize: 11, marginTop: 4, color: '#94A3B8' }}>Polling backend status...</div>}
          </div>
        )}
      </div>
    </Modal>
  );
};
