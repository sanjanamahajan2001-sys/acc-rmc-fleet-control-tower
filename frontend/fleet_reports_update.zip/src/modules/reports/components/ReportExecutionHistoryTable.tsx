import React, { useState } from 'react';
import { ReportExecutionResponse, ReportStatus } from '../types/report.types';
import { StatusChip } from '../../../components/display/StatusChip';
import { Button } from '../../../components/inputs/Button';
import { downloadReportArtifact } from '../utils/downloadReportArtifact';
import { Download, RefreshCw, AlertCircle, Info } from 'lucide-react';

export interface ReportExecutionHistoryTableProps {
  executions: ReportExecutionResponse[];
  isLoading?: boolean;
  error?: string | null;
  onRefresh?: () => void;
}

export const ReportExecutionHistoryTable: React.FC<ReportExecutionHistoryTableProps> = ({
  executions,
  isLoading = false,
  error = null,
  onRefresh,
}) => {
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [selectedExecution, setSelectedExecution] = useState<ReportExecutionResponse | null>(null);

  const handleDownload = async (exec: ReportExecutionResponse) => {
    if (downloadingId || exec.status !== ReportStatus.COMPLETED) return;
    setDownloadingId(exec.execution_id);
    try {
      await downloadReportArtifact({
        executionId: exec.execution_id,
        format: exec.format,
        reportId: exec.report_id,
      });
    } catch (err) {
      // Error handled inside downloader
    } finally {
      setDownloadingId(null);
    }
  };

  const getStatusChip = (status: ReportStatus) => {
    switch (status) {
      case ReportStatus.COMPLETED:
        return <StatusChip label="COMPLETED" status="success" />;
      case ReportStatus.NO_DATA:
        return <StatusChip label="NO_DATA" status="info" />;
      case ReportStatus.QUEUED:
        return <StatusChip label="QUEUED" status="warning" />;
      case ReportStatus.PROCESSING:
      case ReportStatus.RUNNING:
        return <StatusChip label="PROCESSING" status="warning" />;
      case ReportStatus.FAILED:
      case ReportStatus.SCOPE_VALIDATION_FAILED:
        return <StatusChip label="FAILED" status="danger" />;
      case ReportStatus.PURGED:
        return <StatusChip label="PURGED" status="muted" />;
      default:
        return <StatusChip label={status} status="info" />;
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }} data-testid="execution-history-container">
      {/* Subheader & Refresh Action */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3 style={{ fontSize: 15, fontWeight: 600, color: '#F8FAFC' }}>Recent Execution Audit History</h3>
        {onRefresh && (
          <Button
            variant="outline"
            size="sm"
            onClick={onRefresh}
            disabled={isLoading}
            icon={<RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />}
            data-testid="refresh-executions-btn"
          >
            Refresh History
          </Button>
        )}
      </div>

      {/* Error State */}
      {error && (
        <div
          style={{
            padding: 12,
            borderRadius: 6,
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            border: '1px solid rgba(239, 68, 68, 0.3)',
            color: '#F87171',
            fontSize: 13,
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}
          data-testid="history-error-banner"
        >
          <AlertCircle size={16} />
          <span>{error}</span>
        </div>
      )}

      {/* Loading State */}
      {isLoading && executions.length === 0 ? (
        <div style={{ padding: 32, textAlign: 'center', color: '#38BDF8', fontSize: 13 }} data-testid="history-loading-state">
          Loading execution history...
        </div>
      ) : executions.length === 0 ? (
        <div
          style={{
            padding: 32,
            textAlign: 'center',
            color: '#94A3B8',
            fontSize: 13,
            backgroundColor: '#0F172A',
            borderRadius: 6,
            border: '1px dashed #1E293B',
          }}
          data-testid="history-empty-state"
        >
          No historical report executions found.
        </div>
      ) : (
        <div style={{ overflowX: 'auto', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 6 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: '#1E293B', borderBottom: '1px solid rgba(255,255,255,0.08)', color: '#94A3B8' }}>
                <th style={{ padding: '10px 14px', fontWeight: 600 }}>Execution ID</th>
                <th style={{ padding: '10px 14px', fontWeight: 600 }}>Report ID</th>
                <th style={{ padding: '10px 14px', fontWeight: 600 }}>Format</th>
                <th style={{ padding: '10px 14px', fontWeight: 600 }}>Status</th>
                <th style={{ padding: '10px 14px', fontWeight: 600 }}>Records</th>
                <th style={{ padding: '10px 14px', fontWeight: 600 }}>Requested At</th>
                <th style={{ padding: '10px 14px', fontWeight: 600, textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {executions.map((exec, idx) => (
                <tr
                  key={exec.execution_id}
                  style={{
                    borderBottom: '1px solid rgba(255,255,255,0.04)',
                    backgroundColor: idx % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.01)',
                  }}
                  data-testid={`execution-row-${exec.execution_id}`}
                >
                  <td style={{ padding: '10px 14px', fontFamily: 'monospace', fontSize: 12, color: '#CBD5E1' }}>
                    {exec.execution_id}
                  </td>
                  <td style={{ padding: '10px 14px', fontWeight: 600, color: '#F8FAFC' }}>{exec.report_id}</td>
                  <td style={{ padding: '10px 14px', color: '#94A3B8' }}>{exec.format}</td>
                  <td style={{ padding: '10px 14px' }}>{getStatusChip(exec.status)}</td>
                  <td style={{ padding: '10px 14px', color: '#94A3B8' }}>{exec.record_count ?? 0}</td>
                  <td style={{ padding: '10px 14px', color: '#64748B', fontSize: 12 }}>
                    {exec.requested_at ? new Date(exec.requested_at).toLocaleTimeString() : 'N/A'}
                  </td>
                  <td style={{ padding: '10px 14px', textAlign: 'right' }}>
                    <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', alignItems: 'center' }}>
                      <button
                        onClick={() => setSelectedExecution(exec)}
                        style={{
                          background: 'none',
                          border: 'none',
                          color: '#38BDF8',
                          cursor: 'pointer',
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: 4,
                          fontSize: 12,
                        }}
                        data-testid={`scope-btn-${exec.execution_id}`}
                      >
                        <Info size={14} /> Scope
                      </button>
                      {exec.status === ReportStatus.COMPLETED && (
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={downloadingId === exec.execution_id}
                          onClick={() => handleDownload(exec)}
                          icon={<Download size={12} />}
                          data-testid={`download-btn-${exec.execution_id}`}
                        >
                          {downloadingId === exec.execution_id ? 'Downloading...' : 'Download'}
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Execution Scope Detail View Modal */}
      {selectedExecution && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(15, 23, 42, 0.8)',
            backdropFilter: 'blur(4px)',
            zIndex: 999,
            display: 'flex',
            alignItems: 'center',
            justify: 'center',
          }}
          onClick={() => setSelectedExecution(null)}
          data-testid="execution-scope-modal"
        >
          <div
            className="glass-card"
            style={{ width: '100%', maxWidth: 450, padding: 20, margin: 16, backgroundColor: '#0F172A' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
              <h4 style={{ fontSize: 15, fontWeight: 600, color: '#F8FAFC' }}>
                Immutable Execution Scope Details
              </h4>
              <button
                onClick={() => setSelectedExecution(null)}
                style={{ background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer' }}
              >
                ✕
              </button>
            </div>
            <div style={{ fontSize: 12, color: '#CBD5E1', display: 'flex', flexDirection: 'column', gap: 6 }}>
              <div><strong>Execution ID:</strong> {selectedExecution.execution_id}</div>
              <div><strong>Report ID:</strong> {selectedExecution.report_id}</div>
              <div><strong>Requested By:</strong> {selectedExecution.requested_by}</div>
              <div><strong>Plant ID:</strong> {String(selectedExecution.effective_scope?.plant_id || selectedExecution.requested_scope?.plant_id || 'ALL')}</div>
              <div><strong>Customer ID:</strong> {String(selectedExecution.effective_scope?.customer_id || selectedExecution.requested_scope?.customer_id || 'ALL')}</div>
              <div><strong>Operation Date:</strong> {String(selectedExecution.effective_scope?.operation_date || selectedExecution.requested_scope?.operation_date || 'N/A')}</div>
              <div><strong>Scope Fingerprint:</strong> <span style={{ fontFamily: 'monospace', fontSize: 11 }}>{selectedExecution.scope_fingerprint}</span></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
