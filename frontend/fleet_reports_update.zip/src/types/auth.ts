export interface UserClaims {
  sub: string;
  username?: string;
  jti?: string;
  type?: 'access' | 'refresh';
  tenant_id?: string | null;
  plant_id?: string | null;
  exp?: number;
  iat?: number;
}

export interface AuthState {
  token: string | null;
  user: UserClaims | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}
