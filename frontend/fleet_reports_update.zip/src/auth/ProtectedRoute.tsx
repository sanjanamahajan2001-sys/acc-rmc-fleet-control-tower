import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from '../store/auth';

export const ProtectedRoute: React.FC = () => {
  const token = useAuthStore((state) => state.token);

  // In development mode, allow seamless access or check for explicit token
  if (!token && typeof window !== 'undefined') {
    const devToken = localStorage.getItem('fct_auth_token') || localStorage.getItem('token');
    if (!devToken && process.env.NODE_ENV !== 'development') {
      return <Navigate to="/login" replace />;
    }
  }

  return <Outlet />;
};
