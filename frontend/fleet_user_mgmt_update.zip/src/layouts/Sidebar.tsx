import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAppStore } from '../store/app';
import { useAuthStore } from '../store/auth';
import { Home, Layers, FileSearch, Settings, LayoutDashboard, BarChart3, Clock, Zap, Bell, PlaySquare, Activity, Brain, FileSpreadsheet, Users } from 'lucide-react';

interface NavItem {
  label: string;
  to: string;
  icon: React.ReactNode;
}

const navItems: NavItem[] = [
  { label: 'Platform Home', to: '/', icon: <Home size={16} /> },
  { label: 'Site Dashboard', to: '/site-dashboard', icon: <LayoutDashboard size={16} /> },
  { label: 'Overall Dashboard', to: '/overall-dashboard', icon: <BarChart3 size={16} /> },
  { label: 'Site Comparison', to: '/site-comparison', icon: <BarChart3 size={16} /> },
  { label: 'Dispatch Analysis', to: '/dispatch-analysis', icon: <Clock size={16} /> },
  { label: 'Dispatch Optimization', to: '/dispatch-optimization', icon: <Zap size={16} /> },
  { label: 'Operational Intelligence', to: '/operational-intelligence', icon: <Activity size={16} /> },
  { label: 'Predictive Intelligence', to: '/predictive-intelligence', icon: <Brain size={16} /> },
  { label: 'Control Tower Actions', to: '/control-tower-actions', icon: <Zap size={16} /> },
  { label: 'Alert Center', to: '/alerts', icon: <Bell size={16} /> },
  { label: 'Timeline Replay', to: '/timeline-replay', icon: <PlaySquare size={16} /> },
  { label: 'Reports & Exports', to: '/reports', icon: <FileSpreadsheet size={16} /> },
  { label: 'ERP Import', to: '/erp/import', icon: <Layers size={16} /> },
  { label: 'ERP Data Explorer', to: '/erp/explorer', icon: <FileSearch size={16} /> },
  { label: 'Settings Center', to: '/settings', icon: <Settings size={16} /> },
  { label: 'User Management', to: '/settings/users', icon: <Users size={16} /> },
];

interface SidebarProps {
  onNavigate?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onNavigate }) => {
  const { isSidebarCollapsed, toggleSidebar } = useAppStore();
  const user = useAuthStore((state) => state.user);

  // If user state is initializing or null, fallback to showing item or checking token
  const isAdmin = !user || user.is_superuser || user.roles?.includes('Administrator') || user.roles?.includes('admin');


  const visibleNavItems = navItems.filter((item) => {
    if (item.to === '/settings/users') {
      return isAdmin;
    }
    return true;
  });

  return (
    <aside className={`h-full bg-slate-900 border-r border-slate-800 flex flex-col transition-all duration-200 ${isSidebarCollapsed ? 'w-16' : 'w-56'} w-full md:w-auto`}>
      <div className="p-3 border-b border-slate-800 flex items-center justify-between">
        {!isSidebarCollapsed && (
          <span className="text-[11px] font-bold text-indigo-400 tracking-wider uppercase">CONTROL TOWER</span>
        )}
        <button
          onClick={toggleSidebar}
          className="p-1 rounded text-slate-400 hover:text-slate-200 hidden md:block"
        >
          {isSidebarCollapsed ? '▶' : '◀'}
        </button>
      </div>
      <nav className="flex flex-col gap-1 p-2 flex-1">
        {visibleNavItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end
            onClick={() => onNavigate && onNavigate()}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition min-h-[44px] sm:min-h-[36px] ${
                isActive
                  ? 'bg-indigo-600/20 text-indigo-300 border-l-2 border-indigo-500 font-bold'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
              }`
            }
          >
            {item.icon}
            {(!isSidebarCollapsed || (typeof window !== 'undefined' && window.innerWidth < 768)) && (
              <span>{item.label}</span>
            )}
          </NavLink>
        ))}
      </nav>

    </aside>
  );
};
