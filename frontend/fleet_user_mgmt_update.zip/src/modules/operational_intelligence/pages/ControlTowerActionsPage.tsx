import React, { useEffect, useState, useCallback } from 'react';
import { ShieldAlert, CheckCircle2, RefreshCw, Filter, Info } from 'lucide-react';
import { PageContainer } from '../../../layouts/PageContainer';
import { GlobalDashboardFilterBar } from '../../site_dashboard/components/GlobalDashboardFilterBar';
import { DashboardFilterProvider, useDashboardFilters } from '../../site_dashboard/orchestration/DashboardFilterProvider';
import { actionExecutionApi, ActionLogItem } from '../api/actionExecutionApi';
import { ActionSummaryKPIRibbon } from '../components/ActionSummaryKPIRibbon';
import { ControlTowerActionCard } from '../components/ControlTowerActionCard';
import {
  AcceptActionModal,
  ConfirmExecutionModal,
  RejectDeferModal,
  ActionAuditModal,
} from '../components/ActionModals';

const safeUUID = () => {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

export const ControlTowerActionsContent: React.FC = () => {
  const { filters } = useDashboardFilters();
  const [actions, setActions] = useState<ActionLogItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Modal States
  const [selectedAction, setSelectedAction] = useState<ActionLogItem | null>(null);
  const [isAcceptOpen, setIsAcceptOpen] = useState(false);
  const [isConfirmExecOpen, setIsConfirmExecOpen] = useState(false);
  const [isRejectDeferOpen, setIsRejectDeferOpen] = useState(false);
  const [rejectDeferMode, setRejectDeferMode] = useState<'REJECT' | 'DEFER'>('REJECT');
  const [isAuditOpen, setIsAuditOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Status & Pagination Filter
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [pageSize, setPageSize] = useState<number>(20);
  const [currentPage, setCurrentPage] = useState<number>(1);

  const fetchActionQueue = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await actionExecutionApi.getActionQueue({
        plant_id: filters.plant_id,
        customer_id: filters.customer_id,
        dataset_type: filters.dataset_type,
        action_status: statusFilter === 'ALL' ? undefined : statusFilter,
      });
      setActions(res.items || []);
      setCurrentPage(1);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch action queue recommendations');
    } finally {
      setIsLoading(false);
    }
  }, [filters.plant_id, filters.customer_id, filters.dataset_type, statusFilter]);

  useEffect(() => {
    fetchActionQueue();
  }, [fetchActionQueue]);

  // Action Handlers
  const handleOpenAccept = (action: ActionLogItem) => {
    setSelectedAction(action);
    setIsAcceptOpen(true);
  };

  const handleConfirmAccept = async (notes: string, role: 'DISPATCHER' | 'SUPERVISOR' | 'ADMIN') => {
    if (!selectedAction) return;
    setIsSubmitting(true);
    try {
      await actionExecutionApi.acceptRecommendation(selectedAction.action_id, {
        dispatcher_id: 'USER-DISPATCHER-1',
        dispatcher_role: role,
        idempotency_key: `EXEC-ACCEPT-${safeUUID()}`,
        version_lock: selectedAction.version_lock,
        notes,
      });
      setIsAcceptOpen(false);
      await fetchActionQueue();
    } catch (err: any) {
      alert(`Accept Failure: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleStartProgress = async (action: ActionLogItem) => {
    setIsLoading(true);
    try {
      await actionExecutionApi.startProgress(action.action_id, {
        dispatcher_id: 'USER-DISPATCHER-1',
        dispatcher_role: 'DISPATCHER',
        idempotency_key: `EXEC-START-${safeUUID()}`,
        version_lock: action.version_lock,
        notes: 'Operational progress started by dispatcher',
      });
      await fetchActionQueue();
    } catch (err: any) {
      alert(`Start Progress Failure: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenConfirmExec = (action: ActionLogItem) => {
    setSelectedAction(action);
    setIsConfirmExecOpen(true);
  };

  const handleConfirmExec = async (notes: string, role: 'DISPATCHER' | 'SUPERVISOR' | 'ADMIN') => {
    if (!selectedAction) return;
    setIsSubmitting(true);
    try {
      await actionExecutionApi.confirmExecution(selectedAction.action_id, {
        dispatcher_id: 'USER-DISPATCHER-1',
        dispatcher_role: role,
        idempotency_key: `EXEC-CONFIRM-${safeUUID()}`,
        version_lock: selectedAction.version_lock,
        notes,
      });
      setIsConfirmExecOpen(false);
      await fetchActionQueue();
    } catch (err: any) {
      alert(`Execution Confirmation Failure: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOpenReject = (action: ActionLogItem) => {
    setSelectedAction(action);
    setRejectDeferMode('REJECT');
    setIsRejectDeferOpen(true);
  };

  const handleOpenDefer = (action: ActionLogItem) => {
    setSelectedAction(action);
    setRejectDeferMode('DEFER');
    setIsRejectDeferOpen(true);
  };

  const handleConfirmRejectDefer = async (reasonCode: string, notes: string, retryAt?: string) => {
    if (!selectedAction) return;
    setIsSubmitting(true);
    try {
      if (rejectDeferMode === 'REJECT') {
        await actionExecutionApi.rejectRecommendation(selectedAction.action_id, {
          dispatcher_id: 'USER-DISPATCHER-1',
          dispatcher_role: 'DISPATCHER',
          idempotency_key: `EXEC-REJECT-${safeUUID()}`,
          version_lock: selectedAction.version_lock,
          reason_code: reasonCode,
          notes,
        });
      } else {
        await actionExecutionApi.deferRecommendation(selectedAction.action_id, {
          dispatcher_id: 'USER-DISPATCHER-1',
          dispatcher_role: 'DISPATCHER',
          idempotency_key: `EXEC-DEFER-${safeUUID()}`,
          version_lock: selectedAction.version_lock,
          reason_code: reasonCode,
          retry_at: retryAt,
          notes,
        });
      }
      setIsRejectDeferOpen(false);
      await fetchActionQueue();
    } catch (err: any) {
      alert(`Action Failure: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleViewAudit = (action: ActionLogItem) => {
    setSelectedAction(action);
    setIsAuditOpen(true);
  };

  return (
    <PageContainer title="Control Tower Decision & Action Execution Canvas">
      {/* Global Filter Bar Integration */}
      <div className="mb-6">
        <GlobalDashboardFilterBar />
      </div>

      {/* Human-In-The-Loop Governance Banner */}
      <div className="bg-indigo-950/40 border border-indigo-800/60 rounded-xl p-4 mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Info className="w-5 h-5 text-indigo-400 flex-shrink-0" />
          <div className="text-xs text-indigo-200">
            <strong className="text-white">Human-In-The-Loop Execution Guarantee:</strong> Recording dispatcher decisions and confirming operational execution does NOT trigger automatic external ERP write-backs. Dispatcher confirmations are logged for continuous learning.
          </div>
        </div>
      </div>

      {/* Summary KPI Ribbon */}
      <ActionSummaryKPIRibbon actions={actions} isLoading={isLoading} onRefresh={fetchActionQueue} />

      {/* Filter Tabs & Queue Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-6 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-bold text-slate-300 uppercase">Queue Filter:</span>
          {['ALL', 'PENDING', 'ACCEPTED', 'IN_PROGRESS', 'EXECUTED', 'REJECTED', 'DEFERRED'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition ${
                statusFilter === st
                  ? 'bg-indigo-600 text-white shadow-sm font-bold'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
          <div className="flex items-center gap-2">
            <span>Show per page:</span>
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="bg-slate-800 border border-slate-700 text-white font-bold rounded-lg px-2 py-1"
            >
              <option value={10}>10</option>
              <option value={20}>20</option>
              <option value={50}>50</option>
            </select>
          </div>
          <div>
            Showing <span className="text-white font-bold">{Math.min(actions.length, (currentPage - 1) * pageSize + 1)}-{Math.min(actions.length, currentPage * pageSize)}</span> of <span className="text-white font-bold">{actions.length}</span> recommendations
          </div>
        </div>
      </div>

      {/* Error Message Display */}
      {error && (
        <div className="bg-rose-950/50 border border-rose-800 p-4 rounded-xl mb-6 text-xs text-rose-300 flex items-center gap-3">
          <ShieldAlert className="w-5 h-5 text-rose-400 flex-shrink-0" />
          <div>{error}</div>
        </div>
      )}

      {/* Action Cards Queue Grid */}
      {isLoading ? (
        <div className="p-12 text-center text-slate-400 text-xs flex flex-col items-center gap-2">
          <RefreshCw className="w-6 h-6 animate-spin text-indigo-400" />
          Fetching filter-scoped action queue from PostgreSQL DB...
        </div>
      ) : actions.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center text-slate-400 text-xs">
          <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
          <p className="font-bold text-slate-200 text-sm">No Action Recommendations in Current Filter Scope</p>
          <p className="mt-1">All dispatches for plant <span className="text-indigo-400">{filters.plant_id}</span> are operating within standard parameters.</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {actions
              .slice((currentPage - 1) * pageSize, currentPage * pageSize)
              .map((action) => (
                <ControlTowerActionCard
                  key={action.action_id}
                  action={action}
                  onAccept={handleOpenAccept}
                  onStartProgress={handleStartProgress}
                  onConfirmExecution={handleOpenConfirmExec}
                  onReject={handleOpenReject}
                  onDefer={handleOpenDefer}
                  onViewAudit={handleViewAudit}
                />
              ))}
          </div>

          {/* Pagination Controls */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mt-6 flex items-center justify-between">
            <div className="text-xs text-slate-400">
              Page <span className="font-bold text-white">{currentPage}</span> of{' '}
              <span className="font-bold text-white">{Math.max(1, Math.ceil(actions.length / pageSize))}</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition"
              >
                Previous
              </button>
              <button
                disabled={currentPage >= Math.ceil(actions.length / pageSize)}
                onClick={() => setCurrentPage((prev) => Math.min(Math.ceil(actions.length / pageSize), prev + 1))}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600 text-white hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed transition"
              >
                Next Page
              </button>
            </div>
          </div>
        </>
      )}

      {/* Action Execution Modals */}
      <AcceptActionModal
        action={selectedAction}
        isOpen={isAcceptOpen}
        onClose={() => setIsAcceptOpen(false)}
        onConfirm={handleConfirmAccept}
        isSubmitting={isSubmitting}
      />

      <ConfirmExecutionModal
        action={selectedAction}
        isOpen={isConfirmExecOpen}
        onClose={() => setIsConfirmExecOpen(false)}
        onConfirm={handleConfirmExec}
        isSubmitting={isSubmitting}
      />

      <RejectDeferModal
        action={selectedAction}
        isOpen={isRejectDeferOpen}
        mode={rejectDeferMode}
        onClose={() => setIsRejectDeferOpen(false)}
        onConfirm={handleConfirmRejectDefer}
        isSubmitting={isSubmitting}
      />

      <ActionAuditModal
        action={selectedAction}
        isOpen={isAuditOpen}
        onClose={() => setIsAuditOpen(false)}
      />
    </PageContainer>
  );
};

export const ControlTowerActionsPage: React.FC = () => {
  return (
    <DashboardFilterProvider>
      <ControlTowerActionsContent />
    </DashboardFilterProvider>
  );
};
