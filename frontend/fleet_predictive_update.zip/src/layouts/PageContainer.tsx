import React from 'react';

export const PageContainer: React.FC<{ children: React.ReactNode; title?: string }> = ({ children, title }) => {
  return (
    <div className="glass-card" style={{ padding: 20, minHeight: 'calc(100vh - 160px)' }}>
      {title && <h1 style={{ fontSize: 18, fontWeight: 600, color: '#F8FAFC', marginBottom: 16 }}>{title}</h1>}
      {children}
    </div>
  );
};
