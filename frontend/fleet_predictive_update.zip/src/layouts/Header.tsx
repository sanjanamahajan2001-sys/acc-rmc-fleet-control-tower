import React, { useEffect, useState } from 'react';
import { Menu, LogOut, User } from 'lucide-react';
import { useAuthStore } from '../store/auth';

interface HeaderProps {
  onToggleMobileMenu?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleMobileMenu }) => {
  const { user, clearAuth } = useAuthStore();
  const [timeStr, setTimeStr] = useState(() => new Date().toLocaleTimeString());

  useEffect(() => {
    const timer = setInterval(() => setTimeStr(new Date().toLocaleTimeString()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleLogout = async () => {
    try {
      await fetch('/fleet-api/v1/auth/logout', { method: 'POST' });
    } catch (e) {
      // Ignore network errors on logout
    }
    clearAuth();
    localStorage.removeItem('fct_auth_token');
    localStorage.removeItem('token');
    window.location.href = '/login';
  };

  return (
    <header className="h-14 md:h-12 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-4 text-slate-100 shrink-0 z-30">
      <div className="flex items-center gap-3">
        {/* Mobile Hamburger Toggle Button */}
        <button
          type="button"
          onClick={onToggleMobileMenu}
          className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 md:hidden min-h-[44px] min-w-[44px] flex items-center justify-center"
          title="Open Navigation Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="text-xs md:text-sm font-semibold tracking-tight truncate">
          Fleet Control Tower <span className="text-slate-400 font-normal hidden sm:inline">| Ready Mix Concrete</span>
        </div>
      </div>

      <div className="flex items-center gap-3 md:gap-4 text-xs">
        <span className="text-slate-400 hidden lg:inline font-mono">Last Updated: {timeStr}</span>
        <div className="flex items-center gap-2">
          <span className="bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 px-2.5 py-1 rounded-md font-semibold text-[11px] flex items-center gap-1.5">
            <User className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {user ? (user.username || (typeof user.sub === 'string' ? user.sub.slice(0, 8) : 'Admin')) : 'Admin Operator'}
            </span>
          </span>
          <button
            onClick={handleLogout}
            className="px-2.5 py-1 rounded-md bg-slate-800 border border-slate-700/80 hover:bg-slate-700 text-slate-300 text-[11px] font-medium flex items-center gap-1 min-h-[36px] sm:min-h-[28px]"
          >
            <LogOut className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </div>
    </header>
  );
};
