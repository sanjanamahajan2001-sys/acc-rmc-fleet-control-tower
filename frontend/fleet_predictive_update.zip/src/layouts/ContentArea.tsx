import React from 'react';

export const ContentArea: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div style={{ flex: 1, padding: 20, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 16 }}>
      {children}
    </div>
  );
};
