export interface UserClaims {
  id?: string;
  sub?: string;
  username?: string;
  email?: string;
  full_name?: string | null;
  jti?: string;
  type?: 'access' | 'refresh';
  tenant_id?: string | null;
  plant_id?: string | null;
  token_version?: number;
  auth_stage?: 'NORMAL' | 'PASSWORD_CHANGE_REQUIRED' | string;
  must_change_password?: boolean;
  is_password_temporary?: boolean;
  is_active?: boolean;
  is_superuser?: boolean;
  roles?: string[];
  exp?: number;
  iat?: number;
}

export interface AuthState {
  token: string | null;
  user: UserClaims | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

