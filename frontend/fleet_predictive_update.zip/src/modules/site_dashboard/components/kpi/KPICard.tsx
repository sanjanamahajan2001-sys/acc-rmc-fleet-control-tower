import React from 'react';
import { KPIStatusBadge } from './KPIStatusBadge';

export interface KPICardData {
  key: string;
  label: string;
  current_value: number;
  unit?: string;
  threshold?: number;
  target?: number;
  variance?: number;
  status: 'OPTIMAL' | 'WARNING' | 'CRITICAL';
  trend?: 'UP' | 'DOWN' | 'STABLE';
}

interface KPICardProps {
  data: KPICardData;
}

export const KPICard: React.FC<KPICardProps> = ({ data }) => {
  return (
    <div className="p-5 rounded-2xl bg-gradient-to-b from-slate-900/95 to-slate-950/95 border border-slate-800/90 hover:border-slate-700/80 transition-all duration-200 shadow-xl shadow-black/40 space-y-3.5 backdrop-blur-md">
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
          {data.label}
        </span>
        <KPIStatusBadge status={data.status} />
      </div>

      <div className="flex items-baseline gap-2">
        <span className="text-3xl sm:text-4xl font-black text-white tracking-tight font-mono">
          {data.current_value.toLocaleString()}
        </span>
        {data.unit && (
          <span className="text-xs font-bold text-slate-400">
            {data.unit}
          </span>
        )}
      </div>

      <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium pt-2 border-t border-slate-800/70">
        {data.target !== undefined && data.target !== null ? (
          <span>Target SLA: <strong className="text-slate-200">{data.target}%</strong></span>
        ) : data.threshold !== undefined && data.threshold !== null ? (
          <span>SLA Threshold: <strong className="text-slate-200">{data.threshold} {data.unit}</strong></span>
        ) : (
          <span>Canonical Aggregate</span>
        )}

        {data.variance !== undefined && data.variance !== null && (
          <span className={data.variance >= 0 ? 'text-emerald-400 font-extrabold' : 'text-rose-400 font-extrabold'}>
            {data.variance >= 0 ? `+${data.variance}%` : `${data.variance}%`}
          </span>
        )}
      </div>
    </div>
  );
};
