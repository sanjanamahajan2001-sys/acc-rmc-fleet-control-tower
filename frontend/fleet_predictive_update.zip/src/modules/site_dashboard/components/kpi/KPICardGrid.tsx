import React from 'react';
import { KPICard, KPICardData } from './KPICard';

interface KPICardGridProps {
  cards: KPICardData[];
  loading?: boolean;
}

export const KPICardGrid: React.FC<KPICardGridProps> = ({ cards, loading }) => {
  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="h-32 rounded-2xl bg-slate-900/60 border border-slate-800 animate-pulse p-4 space-y-3">
            <div className="h-3 w-24 bg-slate-800 rounded" />
            <div className="h-8 w-16 bg-slate-800 rounded" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
      {cards.map((card) => (
        <KPICard key={card.key} data={card} />
      ))}
    </div>
  );
};
