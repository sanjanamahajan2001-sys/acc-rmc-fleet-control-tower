import React, { useState } from 'react';

export interface QueuePoint {
  timestamp: string;
  active_queue_count: number;
}

interface QueueTrendChartProps {
  points: QueuePoint[];
}

export const QueueTrendChart: React.FC<QueueTrendChartProps> = ({ points }) => {
  const [hoveredPoint, setHoveredPoint] = useState<QueuePoint | null>(null);

  if (!points || points.length === 0) {
    return (
      <div className="p-8 text-center text-xs text-slate-500 italic border border-slate-800/80 rounded-xl bg-slate-950/60">
        No queue trend data available for active filters.
      </div>
    );
  }

  const maxQ = Math.max(...points.map((p) => p.active_queue_count), 5);
  const width = 600;
  const height = 180;
  const paddingX = 40;
  const paddingY = 30;

  const chartWidth = width - paddingX * 2;
  const chartHeight = height - paddingY * 2;

  // Handle single/sparse data points gracefully
  const coords = points.map((p, idx) => {
    const x = points.length === 1
      ? width / 2
      : paddingX + (idx / Math.max(1, points.length - 1)) * chartWidth;
    const y = height - paddingY - (p.active_queue_count / maxQ) * chartHeight;
    return { x, y, point: p };
  });

  // Generate SVG path string with smooth Catmull-Rom curves
  const pathD = coords.reduce((acc, curr, idx, arr) => {
    if (idx === 0) return `M ${curr.x} ${curr.y}`;
    const prev = arr[idx - 1];
    const cp1x = prev.x + (curr.x - prev.x) / 2;
    const cp1y = prev.y;
    const cp2x = prev.x + (curr.x - prev.x) / 2;
    const cp2y = curr.y;
    return `${acc} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${curr.x} ${curr.y}`;
  }, '');

  // Area under curve
  const firstX = coords[0].x;
  const lastX = coords[coords.length - 1].x;
  const bottomY = height - paddingY;
  const areaD = coords.length > 1 ? `${pathD} L ${lastX} ${bottomY} L ${firstX} ${bottomY} Z` : '';

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider">
          QUEUE AT SITE OVER TIME (NUMBER OF TMS)
        </h3>
        <div className="flex items-center gap-2 text-[11px] font-semibold text-slate-300">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shadow-sm shadow-blue-500/50" />
          <span>Queue Count (TMs)</span>
        </div>
      </div>

      <div className="relative bg-slate-950 border border-slate-800/90 rounded-xl p-4 shadow-inner overflow-hidden">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-48 overflow-visible">
          <defs>
            <linearGradient id="queueCurveGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Background Horizontal Grid Lines & Brighter Y-Axis Labels */}
          {[0, 1, 2, 3, 4, 5].map((level) => {
            const y = height - paddingY - (level / maxQ) * chartHeight;
            return (
              <g key={level}>
                <line
                  x1={paddingX}
                  y1={y}
                  x2={width - paddingX}
                  y2={y}
                  stroke="#1e293b"
                  strokeDasharray="3 3"
                  strokeWidth="1"
                />
                {/* Increased contrast Y-axis labels (#94a3b8 instead of #64748b) */}
                <text x={paddingX - 12} y={y + 3} fill="#94a3b8" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="end">
                  {level}
                </text>
              </g>
            );
          })}

          {/* Area Fill with Smooth Transition */}
          {areaD && <path d={areaD} fill="url(#queueCurveGrad)" className="transition-all duration-300 ease-in-out" />}

          {/* Smooth Trend Line with 250ms CSS Transition */}
          {pathD && (
            <path
              d={pathD}
              fill="none"
              stroke="#3b82f6"
              strokeWidth="3"
              strokeLinecap="round"
              className="transition-all duration-300 ease-in-out"
            />
          )}

          {/* Circular Data Points & Interactivity */}
          {coords.map(({ x, y, point }, idx) => (
            <g key={idx} className="cursor-pointer group" onMouseEnter={() => setHoveredPoint(point)} onMouseLeave={() => setHoveredPoint(null)}>
              {/* Brighter 2px active/hover marker stroke */}
              <circle
                cx={x}
                cy={y}
                r="5"
                fill="#3b82f6"
                stroke="#60a5fa"
                strokeWidth="2"
                className="transition-all duration-200 group-hover:scale-150 group-hover:stroke-white"
              />
              <circle cx={x} cy={y} r="12" fill="transparent" />
              
              {/* X Axis Time Labels */}
              <text x={x} y={height - 8} fill="#94a3b8" fontSize="10" fontFamily="monospace" textAnchor="middle" fontWeight="bold">
                {point.timestamp}
              </text>
            </g>
          ))}
        </svg>

        {/* Hover Tooltip Popup */}
        {hoveredPoint && (
          <div className="absolute top-4 right-6 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 shadow-xl text-xs font-mono flex items-center gap-2.5 backdrop-blur-md">
            <span className="text-slate-300 font-bold">{hoveredPoint.timestamp}</span>
            <span className="w-2 h-2 rounded-full bg-blue-500" />
            <span className="text-white font-extrabold">{hoveredPoint.active_queue_count} TMs</span>
          </div>
        )}
      </div>
    </div>
  );
};
