import { QueueTrendChart, QueuePoint } from './QueueTrendChart';
import { QueueStatisticsPanel, QueueData } from './QueueStatisticsPanel';
import { CauseItem } from './QueueReasonTable';

export interface QueueAnalyticsContainerData {
  queue: QueueData & { points: QueuePoint[] };
  root_causes: CauseItem[];
}

interface QueueAnalyticsContainerProps {
  data: QueueAnalyticsContainerData | null;
  loading?: boolean;
}

export const QueueAnalyticsContainer: React.FC<QueueAnalyticsContainerProps> = ({ data, loading }) => {
  if (loading || !data) {
    return (
      <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/95 to-slate-950/95 border border-slate-800/90 animate-pulse space-y-4 shadow-xl">
        <div className="h-4 w-48 bg-slate-800 rounded" />
        <div className="h-44 w-full bg-slate-800/80 rounded-xl" />
      </div>
    );
  }

  return (
    <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/95 to-slate-950/95 border border-slate-800/90 space-y-6 shadow-2xl backdrop-blur-md">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
        <h2 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
          QUEUE ANALYTICS & OPERATIONAL TREND INTELLIGENCE
        </h2>
        <span className="text-[11px] font-mono text-slate-500 font-bold uppercase">Workstream 2.5 Active</span>
      </div>

      {/* 1. Queue Statistics Metric Cards */}
      <QueueStatisticsPanel data={data.queue} />

      {/* 2. Interactive Time-Series Queue Trend Chart */}
      <QueueTrendChart points={data.queue.points || []} />
    </div>
  );
};
