import React from 'react';

export interface QueueData {
  avg_queue: number;
  max_queue: number;
  queue_duration_hours: number;
  total_overlap_mins: number;
  weighted_overlap_tm_mins: number;
}

interface QueueStatisticsPanelProps {
  data: QueueData;
}

export const QueueStatisticsPanel: React.FC<QueueStatisticsPanelProps> = ({ data }) => {
  const stats = [
    { label: 'Average Queue', value: `${data.avg_queue} TMs` },
    { label: 'Maximum Queue', value: `${data.max_queue} TMs` },
    { label: 'Queue Duration', value: `${data.queue_duration_hours} hrs` },
    { label: 'Total Overlap', value: `${data.total_overlap_mins} min` },
    { label: 'Weighted Overlap', value: `${data.weighted_overlap_tm_mins} TM-min` },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
      {stats.map((s) => (
        <div key={s.label} className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/90 space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">{s.label}</span>
          <span className="text-base font-extrabold text-slate-100 font-mono">{s.value}</span>
        </div>
      ))}
    </div>
  );
};
