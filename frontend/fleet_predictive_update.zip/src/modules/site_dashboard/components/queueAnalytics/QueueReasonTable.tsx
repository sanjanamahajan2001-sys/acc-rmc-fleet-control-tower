import React from 'react';

export interface CauseItem {
  rule_code: string;
  potential_reason: string;
  impact_level: string;
  issue_type: string;
  confidence_score: number;
  evidence_statement: string;
}

interface QueueReasonTableProps {
  causes: CauseItem[];
}

export const QueueReasonTable: React.FC<QueueReasonTableProps> = ({ causes }) => {
  return (
    <div className="space-y-3">
      <h3 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider">
        OPERATIONAL ROOT CAUSES & BOTTLENECK EXPLANATIONS
      </h3>

      {causes.length === 0 ? (
        <div className="p-6 text-center text-xs text-slate-500 italic border border-slate-800/80 rounded-xl bg-slate-950/60">
          No operational bottlenecks detected for active filters.
        </div>
      ) : (
        <div className="overflow-x-auto border border-slate-800/90 rounded-xl bg-slate-950/60">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[10px] uppercase border-b border-slate-800">
              <tr>
                <th className="px-4 py-2.5">Rule Code</th>
                <th className="px-4 py-2.5">Potential Reason</th>
                <th className="px-4 py-2.5">Issue Type</th>
                <th className="px-4 py-2.5">Impact</th>
                <th className="px-4 py-2.5">Confidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {causes.map((c) => (
                <tr key={c.rule_code} className="hover:bg-slate-900/50 transition">
                  <td className="px-4 py-2.5 font-mono text-indigo-400 font-bold">{c.rule_code}</td>
                  <td className="px-4 py-2.5 text-slate-200">{c.potential_reason}</td>
                  <td className="px-4 py-2.5 text-slate-400">{c.issue_type}</td>
                  <td className="px-4 py-2.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                        c.impact_level === 'High'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {c.impact_level}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 font-mono text-slate-300 font-bold">
                    {(c.confidence_score * 100).toFixed(0)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
