import React from 'react';
import { TMDetailsStatusBadge } from './TMDetailsStatusBadge';

export interface TMDetailItem {
  dispatch_id: string;
  tm_no: string;
  vehicle_plate: string;
  plant_name: string;
  customer_name: string;
  dispatch_time: string;
  site_in_time: string;
  unload_start_time: string;
  unload_end_time: string;
  site_out_time: string;
  holding_mins: number;
  unloading_mins: number;
  retention_mins: number;
  total_site_mins: number;
  dispatch_accuracy_pct: number;
  operational_status: string;
  sla_status: string;
  delay_classification: string;
}

interface TMDetailsRowProps {
  item: TMDetailItem;
}

export const TMDetailsRow: React.FC<TMDetailsRowProps> = ({ item }) => {
  return (
    <tr className="hover:bg-slate-900/60 transition group border-b border-slate-800/60">
      <td className="px-3.5 py-2.5 font-mono text-indigo-400 font-bold">{item.tm_no}</td>
      <td className="px-3.5 py-2.5 font-mono text-slate-200 font-bold">{item.vehicle_plate}</td>
      <td className="px-3.5 py-2.5 text-slate-300 font-medium truncate max-w-[140px]" title={item.plant_name}>
        {item.plant_name}
      </td>
      <td className="px-3.5 py-2.5 text-slate-300 font-medium truncate max-w-[160px]" title={item.customer_name}>
        {item.customer_name}
      </td>
      <td className="px-3 py-2.5 font-mono text-slate-400 text-center">{item.dispatch_time}</td>
      <td className="px-3 py-2.5 font-mono text-slate-400 text-center">{item.site_in_time}</td>
      <td className="px-3 py-2.5 font-mono text-slate-400 text-center">{item.unload_start_time}</td>
      <td className="px-3 py-2.5 font-mono text-slate-400 text-center">{item.unload_end_time}</td>
      <td className="px-3 py-2.5 font-mono text-slate-400 text-center">{item.site_out_time}</td>
      <td className="px-3.5 py-2.5 font-mono text-rose-400 font-bold text-right">{item.holding_mins}m</td>
      <td className="px-3.5 py-2.5 font-mono text-indigo-400 font-bold text-right">{item.unloading_mins}m</td>
      <td className="px-3.5 py-2.5 font-mono text-amber-400 font-bold text-right">{item.retention_mins}m</td>
      <td className="px-3.5 py-2.5 font-mono text-white font-extrabold text-right text-sm">{item.total_site_mins}m</td>
      <td className="px-3.5 py-2.5 font-mono tabular-nums text-emerald-400 font-bold text-right">{item.dispatch_accuracy_pct}%</td>
      <td className="px-3.5 py-2.5 text-center">
        <TMDetailsStatusBadge status={item.operational_status} />
      </td>
      <td className="px-3.5 py-2.5 text-center">
        <TMDetailsStatusBadge status={item.sla_status} />
      </td>
    </tr>
  );
};
