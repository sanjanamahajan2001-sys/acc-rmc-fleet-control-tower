import React from 'react';
import { TMDetailsRow, TMDetailItem } from './TMDetailsRow';

interface TMDetailsTableProps {
  items: TMDetailItem[];
}

export const TMDetailsTable: React.FC<TMDetailsTableProps> = ({ items }) => {
  return (
    <div className="overflow-x-auto border border-slate-800/90 rounded-xl bg-slate-950/60 max-h-[450px]">
      <table className="w-full text-left text-xs">
        <thead className="sticky top-0 z-10 bg-slate-950 text-slate-400 font-mono text-[10px] uppercase border-b border-slate-800 shadow-md">
          <tr>
            <th className="px-3.5 py-3 w-28">TM No</th>
            <th className="px-3.5 py-3 w-28">Vehicle</th>
            <th className="px-3.5 py-3 min-w-[140px]">Site / Plant</th>
            <th className="px-3.5 py-3 min-w-[160px]">Customer</th>
            <th className="px-3 py-3 w-20 text-center">Dispatch</th>
            <th className="px-3 py-3 w-20 text-center">Site In</th>
            <th className="px-3 py-3 w-24 text-center">Unload Start</th>
            <th className="px-3 py-3 w-24 text-center">Unload End</th>
            <th className="px-3 py-3 w-20 text-center">Site Out</th>
            <th className="px-3.5 py-3 text-right">Holding</th>
            <th className="px-3.5 py-3 text-right">Unloading</th>
            <th className="px-3.5 py-3 text-right">Retention</th>
            <th className="px-3.5 py-3 text-right font-extrabold text-slate-200">Total Time</th>
            <th className="px-3.5 py-3 text-right">Accuracy</th>
            <th className="px-3.5 py-3 text-center">Status</th>
            <th className="px-3.5 py-3 text-center">SLA</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800/60 font-medium">
          {items.map((item, idx) => (
            <TMDetailsRow key={`${item.tm_no}-${item.dispatch_id}-${idx}`} item={item} />
          ))}
        </tbody>
      </table>
    </div>
  );
};
