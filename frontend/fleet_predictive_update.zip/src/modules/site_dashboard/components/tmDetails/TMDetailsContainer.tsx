import React from 'react';
import { TMDetailsTable } from './TMDetailsTable';
import { TMDetailItem } from './TMDetailsRow';

export interface TMDetailsContainerData {
  total_count: number;
  page: number;
  page_size: number;
  items: TMDetailItem[];
}

interface TMDetailsContainerProps {
  data: TMDetailsContainerData | null;
  loading?: boolean;
}

export const TMDetailsContainer: React.FC<TMDetailsContainerProps> = ({ data, loading }) => {
  if (loading || !data) {
    return (
      <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/95 to-slate-950/95 border border-slate-800/90 animate-pulse space-y-4 shadow-xl">
        <div className="h-4 w-56 bg-slate-800 rounded" />
        <div className="h-48 w-full bg-slate-800/80 rounded-xl" />
      </div>
    );
  }

  return (
    <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/95 to-slate-950/95 border border-slate-800/90 space-y-5 shadow-2xl backdrop-blur-md">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-800/80">
        <div>
          <h2 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
            TM DETAILS (HOLDING & RETENTION DISPATCH INTELLIGENCE)
          </h2>
          <p className="text-xs text-slate-400 font-medium mt-1">
            Displaying <span className="text-indigo-400 font-mono font-bold">{data.items.length}</span> of{' '}
            <span className="text-slate-200 font-mono font-bold">{data.total_count}</span> Total Filtered Dispatches
          </p>
        </div>

        <span className="text-[11px] font-mono text-slate-500 font-bold uppercase">Workstream 2.6 Active</span>
      </div>

      {data.items.length === 0 ? (
        <div className="p-8 text-center text-xs text-slate-500 italic border border-slate-800/80 rounded-xl bg-slate-950/60">
          No dispatch details recorded for active filters.
        </div>
      ) : (
        <TMDetailsTable items={data.items} />
      )}
    </div>
  );
};
