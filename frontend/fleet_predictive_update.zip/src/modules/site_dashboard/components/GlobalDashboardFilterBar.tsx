import React from 'react';
import { useDashboardFilters } from '../orchestration/DashboardFilterProvider';
import { Filter, Database, Calendar, Clock, FileSpreadsheet } from 'lucide-react';

export const GlobalDashboardFilterBar: React.FC = () => {
  const { filters, metadata, plantOptions, customerOptions, setPlantFilter, setCustomerFilter, setDatasetTypeFilter } = useDashboardFilters();

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-4 shadow-xl">
      {/* Top Row: Informational Read-Only Dataset Metadata Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-slate-800/80 text-xs">
        <div className="flex flex-wrap items-center gap-4 text-slate-400 font-medium">
          <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-lg border border-slate-800">
            <Calendar className="w-3.5 h-3.5 text-indigo-400" />
            <span>Op Date: <strong className="text-slate-200">{metadata?.operational_date || '2026-08-05'}</strong></span>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-lg border border-slate-800">
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Dispatches: <strong className="text-slate-200">{metadata?.total_dispatches ?? 3532}</strong></span>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-lg border border-slate-800">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Imported: <strong className="text-slate-200">{metadata?.import_timestamp ? new Date(metadata.import_timestamp).toLocaleTimeString() : 'Just Now'}</strong></span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
          <Database className="w-3.5 h-3.5 text-indigo-400" />
          <span>DATASET ID: {metadata?.dataset_id || 'DS-20260805-001'} ({metadata?.dataset_status || 'ACTIVE'})</span>
        </div>
      </div>

      {/* Bottom Row: Dynamic Active Dropdown Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* 1. Dynamic Plant Filter Dropdown */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Filter className="w-3 h-3 text-indigo-400" /> Plant Selection
          </label>
          <select
            value={filters.plant_id}
            onChange={(e) => setPlantFilter(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-indigo-500 font-semibold cursor-pointer min-h-[44px] sm:min-h-[36px]"
          >
            {plantOptions.map((p) => (
              <option key={p.id} value={p.id} className="bg-slate-900 text-slate-200">
                {p.name}
              </option>
            ))}
          </select>
        </div>

        {/* 2. Dynamic Customer Filter Dropdown */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Filter className="w-3 h-3 text-indigo-400" /> Customer Filter
          </label>
          <select
            value={filters.customer_id}
            onChange={(e) => setCustomerFilter(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-indigo-500 font-semibold cursor-pointer min-h-[44px] sm:min-h-[36px]"
          >
            {customerOptions.map((c) => (
              <option key={c.id} value={c.id} className="bg-slate-900 text-slate-200">
                {c.name}
              </option>
            ))}
          </select>
        </div>

        {/* 3. Dataset Type Filter Dropdown */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Filter className="w-3 h-3 text-indigo-400" /> Dataset Scope
          </label>
          <select
            value={filters.dataset_type}
            onChange={(e) => setDatasetTypeFilter(e.target.value as any)}
            className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-indigo-500 font-semibold cursor-pointer min-h-[44px] sm:min-h-[36px]"
          >
            <option value="ALL">All Imported Data</option>
            <option value="REAL_ONLY">Real Data Only</option>
            <option value="SYNTHETIC_ONLY">Synthetic Only</option>
          </select>
        </div>
      </div>
    </div>
  );
};
