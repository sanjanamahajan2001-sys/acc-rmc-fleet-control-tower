import React from 'react';
import { useDashboardSync } from '../orchestration/DashboardSyncProvider';
import { RefreshCw, Users, Database } from 'lucide-react';

export const SyncStatusHeaderBadge: React.FC = () => {
  const { syncStatus, triggerManualRefresh, isRefreshing } = useDashboardSync();

  const status = syncStatus?.sync_status || 'SYNCHRONIZED';
  const operators = syncStatus?.active_operators_count || 1;
  const snapshot = syncStatus?.snapshot_version || 'v2.11-LIVE';

  let badgeColor = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
  let statusText = 'SYNCHRONIZED';

  if (isRefreshing || status === 'REFRESHING') {
    badgeColor = 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
    statusText = 'REFRESHING';
  } else if (status === 'LAGGING') {
    badgeColor = 'bg-amber-500/20 text-amber-400 border-amber-500/30';
    statusText = 'LAGGING';
  } else if (status === 'DISCONNECTED') {
    badgeColor = 'bg-rose-500/20 text-rose-400 border-rose-500/30';
    statusText = 'DISCONNECTED';
  }

  return (
    <div className="flex items-center space-x-3 text-xs font-mono">
      {/* Live Status Badge */}
      <div className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-full border ${badgeColor}`}>
        <span className={`w-2 h-2 rounded-full ${isRefreshing ? 'bg-cyan-400 animate-ping' : status === 'DISCONNECTED' ? 'bg-rose-400' : 'bg-emerald-400'}`} />
        <span className="font-semibold tracking-wide">{statusText}</span>
      </div>

      {/* Snapshot Version */}
      <div className="hidden md:flex items-center space-x-1 text-slate-400 bg-slate-800/60 px-2.5 py-1 rounded border border-slate-700/50">
        <Database className="w-3.5 h-3.5 text-cyan-400" />
        <span>{snapshot}</span>
      </div>

      {/* Active Operators Count */}
      <div className="hidden sm:flex items-center space-x-1 text-slate-400 bg-slate-800/60 px-2.5 py-1 rounded border border-slate-700/50">
        <Users className="w-3.5 h-3.5 text-indigo-400" />
        <span>{operators} {operators === 1 ? 'Operator' : 'Operators'}</span>
      </div>

      {/* Manual Refresh Trigger Button */}
      <button
        onClick={triggerManualRefresh}
        disabled={isRefreshing}
        title="Trigger Dashboard Refresh"
        className="p-1.5 rounded bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white transition-colors disabled:opacity-50"
      >
        <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-cyan-400' : ''}`} />
      </button>
    </div>
  );
};
