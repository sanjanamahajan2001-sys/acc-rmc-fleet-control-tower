import React from 'react';

export interface TimelinePhase {
  phase: 'HOLDING' | 'UNLOADING' | 'RETENTION';
  start_time: string;
  end_time: string;
  duration_mins: number;
}

export interface TMTimelineItem {
  tm_no: string;
  site_in: string;
  unloading_start: string;
  unloading_end: string;
  site_out: string;
  phases: TimelinePhase[];
}

export interface TimelineData {
  first_unloading_time: string;
  tm_timelines: TMTimelineItem[];
}

interface TMQueueTimelineGanttProps {
  data: TimelineData | null;
  loading?: boolean;
}

export const TMQueueTimelineGantt: React.FC<TMQueueTimelineGanttProps> = ({ data, loading }) => {
  if (loading || !data) {
    return (
      <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-slate-800 animate-pulse space-y-4 shadow-xl">
        <div className="h-4 w-48 bg-slate-800 rounded" />
        <div className="space-y-2">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-8 w-full bg-slate-800/80 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  const hours = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];

  return (
    <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/95 to-slate-950/95 border border-slate-800/90 space-y-4 shadow-2xl backdrop-blur-md">
      {/* Header & Legend */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
            TM QUEUE TIMELINE (GANTT ENGINE)
          </h2>
          <p className="text-xs text-slate-400 font-medium mt-1">
            First Unloading Started: <span className="text-indigo-400 font-mono font-bold">{data.first_unloading_time}</span>
            <span className="ml-3 text-slate-500 font-mono">({data.tm_timelines.length} Dispatched Mixers)</span>
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-semibold bg-slate-950/60 px-3.5 py-1.5 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-rose-500 border border-rose-400/50 shadow-sm shadow-rose-500/20" />
            <span className="text-slate-300">Holding (Wait)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-indigo-500 border border-indigo-400/50 shadow-sm shadow-indigo-500/20" />
            <span className="text-slate-300">Unloading</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-amber-500 border border-amber-400/50 shadow-sm shadow-amber-500/20" />
            <span className="text-slate-300">Retention</span>
          </div>
        </div>
      </div>

      {/* Timeline Gantt Chart Container with Ergonomic 380px Viewport (5-6 visible TMs) & Sticky Time Axis Header */}
      {data.tm_timelines.length === 0 ? (
        <div className="p-8 text-center text-xs text-slate-500 italic">
          No operational timeline dispatches recorded for active filters.
        </div>
      ) : (
        <div className="flex flex-col h-[380px] border border-slate-800/80 rounded-xl bg-slate-950/60 overflow-hidden">
          {/* Sticky Time Axis Marks Header */}
          <div className="sticky top-0 z-10 flex items-center text-[11px] font-mono text-slate-400 font-bold bg-slate-950 border-b border-slate-800/90 px-3.5 py-2 shadow-md">
            <div className="w-28 shrink-0 tracking-wider">TM / VEHICLE</div>
            <div className="flex-1 grid grid-cols-10 text-center">
              {hours.map((h) => (
                <span key={h}>{h}</span>
              ))}
            </div>
          </div>

          {/* Virtualized Scrollable TM Timeline Rows (5-6 Visible at 380px) */}
          <div className="flex-1 overflow-y-auto p-2.5 space-y-1.5 focus:outline-none custom-scrollbar">
            {data.tm_timelines.map((item, idx) => (
              <div key={`${item.tm_no}-${idx}`} className="flex items-center text-xs font-semibold group hover:bg-slate-900/50 px-1 py-0.5 rounded-lg transition">
                <div className="w-28 shrink-0 font-mono text-slate-200 group-hover:text-indigo-400 transition font-bold">
                  {item.tm_no}
                </div>

                <div className="flex-1 h-7 bg-slate-950 rounded-lg border border-slate-800/90 p-0.5 flex items-center gap-1 relative overflow-hidden shadow-inner">
                  {item.phases.map((p, idx) => {
                    const colorMap = {
                      HOLDING: 'bg-rose-500/90 border-rose-400/60 text-rose-50 shadow-sm shadow-rose-950/40',
                      UNLOADING: 'bg-indigo-500/90 border-indigo-400/60 text-indigo-50 shadow-sm shadow-indigo-950/40',
                      RETENTION: 'bg-amber-500/90 border-amber-400/60 text-amber-50 shadow-sm shadow-amber-950/40',
                    };

                    const flexWeight = Math.max(1, p.duration_mins);

                    return (
                      <div
                        key={idx}
                        style={{ flex: flexWeight }}
                        className={`h-full rounded border flex items-center justify-center text-[10px] font-mono font-extrabold px-1 overflow-hidden truncate transition-all duration-150 hover:brightness-125 cursor-pointer ${colorMap[p.phase]}`}
                        title={`${p.phase}: ${p.start_time} - ${p.end_time} (${p.duration_mins} min)`}
                      >
                        {p.phase[0]}:{p.duration_mins}m
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
