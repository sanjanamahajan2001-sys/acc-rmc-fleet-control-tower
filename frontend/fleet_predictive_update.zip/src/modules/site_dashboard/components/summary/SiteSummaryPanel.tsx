import React from 'react';
import { TopFiveBarChart, TopSiteItem } from './TopFiveBarChart';

export interface SummaryData {
  total_quantity_m3: number;
  avg_holding_mins: number;
  avg_retention_mins: number;
  max_queue_tms: number;
  queue_duration_mins: number;
  total_overlap_mins: number;
  weighted_overlap_tm_mins: number;
  dispatch_accuracy_pct: number;
  top_sites_holding: TopSiteItem[];
  top_sites_retention: TopSiteItem[];
}

interface SiteSummaryPanelProps {
  data: SummaryData | null;
  loading?: boolean;
}

export const SiteSummaryPanel: React.FC<SiteSummaryPanelProps> = ({ data, loading }) => {
  if (loading || !data) {
    return (
      <div className="p-5 rounded-2xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-slate-800 animate-pulse space-y-4 shadow-xl">
        <div className="h-4 w-36 bg-slate-800 rounded" />
        <div className="space-y-2.5">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-4 w-full bg-slate-800/80 rounded" />
          ))}
        </div>
      </div>
    );
  }

  const metrics = [
    { label: 'Total Quantity', value: `${data.total_quantity_m3.toLocaleString()} Cum` },
    { label: 'Average Holding Time', value: `${data.avg_holding_mins} min` },
    { label: 'Average Retention Time', value: `${data.avg_retention_mins} min` },
    { label: 'Maximum Queue', value: `${data.max_queue_tms} TMs` },
    { label: 'Queue Duration', value: `${data.queue_duration_mins} min` },
    { label: 'Total Overlap Minutes', value: `${data.total_overlap_mins} min` },
    { label: 'Weighted Overlap', value: `${data.weighted_overlap_tm_mins} TM-min` },
    { label: 'Dispatch Accuracy', value: `${data.dispatch_accuracy_pct}%` },
  ];

  return (
    <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/95 to-slate-950/95 border border-slate-800/90 space-y-7 shadow-2xl backdrop-blur-md">
      <div>
        <h2 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-1.5 h-3.5 bg-emerald-500 rounded-full" />
          SITE SUMMARY (YESTERDAY)
        </h2>

        <div className="space-y-3 text-xs border-b border-slate-800/80 pb-5">
          {metrics.map((m) => (
            <div key={m.label} className="flex justify-between items-center group pr-1">
              <span className="text-slate-400 font-medium group-hover:text-slate-300 transition">{m.label}</span>
              <span className="text-slate-100 font-bold font-mono">{m.value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Top 5 Sites by Holding */}
      <div className="pt-1">
        <TopFiveBarChart
          title="TOP 5 SITES BY HOLDING (BEYOND 20 MIN)"
          sites={data.top_sites_holding}
          barColorClass="bg-gradient-to-r from-rose-500 to-amber-500"
        />
      </div>

      {/* Top 5 Sites by Retention */}
      <div className="pt-1">
        <TopFiveBarChart
          title="TOP 5 SITES BY RETENTION (BEYOND 10 MIN)"
          sites={data.top_sites_retention}
          barColorClass="bg-gradient-to-r from-amber-500 to-indigo-500"
        />
      </div>
    </div>
  );
};
