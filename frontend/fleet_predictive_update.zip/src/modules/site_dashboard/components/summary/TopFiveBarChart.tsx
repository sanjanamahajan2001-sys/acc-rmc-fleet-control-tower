import React from 'react';

export interface TopSiteItem {
  site_code: string;
  site_name: string;
  value: number;
  unit: string;
}

interface TopFiveBarChartProps {
  title: string;
  sites: TopSiteItem[];
  barColorClass: string;
}

export const TopFiveBarChart: React.FC<TopFiveBarChartProps> = ({ title, sites, barColorClass }) => {
  const maxValue = Math.max(...sites.map((s) => s.value), 1.0);

  return (
    <div className="space-y-3 pt-1">
      <h3 className="text-[11px] font-extrabold text-slate-300 uppercase tracking-wider">
        {title}
      </h3>

      {sites.length === 0 ? (
        <p className="text-xs text-slate-500 italic py-1">No site data available</p>
      ) : (
        <div className="space-y-2.5">
          {sites.map((site) => {
            const pct = Math.min(100, (site.value / maxValue) * 100);
            return (
              <div key={site.site_code} className="space-y-1">
                <div className="flex justify-between text-xs font-semibold pr-1">
                  <span className="text-slate-300 font-mono font-bold truncate max-w-[170px]">{site.site_name}</span>
                  <span className="text-slate-400 font-bold font-mono shrink-0">{site.value} {site.unit}</span>
                </div>
                <div className="h-2.5 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800/90 shadow-inner">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${barColorClass}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
