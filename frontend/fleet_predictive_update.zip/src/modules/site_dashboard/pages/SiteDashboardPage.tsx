import React, { useEffect, useState } from 'react';
import { LayoutDashboard } from 'lucide-react';
import { KPICardGrid } from '../components/kpi/KPICardGrid';
import { KPICardData } from '../components/kpi/KPICard';
import { SiteSummaryPanel } from '../components/summary/SiteSummaryPanel';
import { TMQueueTimelineGantt, TimelineData } from '../components/timeline/TMQueueTimelineGantt';
import { QueueAnalyticsContainer, QueueAnalyticsContainerData } from '../components/queueAnalytics/QueueAnalyticsContainer';
import { QueueReasonTable } from '../components/queueAnalytics/QueueReasonTable';
import { TMDetailsContainer, TMDetailsContainerData } from '../components/tmDetails/TMDetailsContainer';
import { SitePerformanceContainer, SitePerformanceContainerData } from '../components/sitePerformance/SitePerformanceContainer';
import { FleetUtilizationContainer, FleetUtilizationContainerData } from '../components/fleetUtilization/FleetUtilizationContainer';
import { DecisionIntelligenceContainer, DecisionIntelligenceContainerData } from '../components/decisionIntelligence/DecisionIntelligenceContainer';
import { OperationalWidgetsContainer, OperationalWidgetsContainerData } from '../components/operationalWidgets/OperationalWidgetsContainer';
import { DashboardSyncProvider } from '../orchestration/DashboardSyncProvider';
import { SyncStatusHeaderBadge } from '../components/SyncStatusHeaderBadge';
import { DashboardFilterProvider, useDashboardFilters } from '../orchestration/DashboardFilterProvider';
import { GlobalDashboardFilterBar } from '../components/GlobalDashboardFilterBar';

const SiteDashboardContent: React.FC = () => {
  const { filters, updateMetadata } = useDashboardFilters();
  const [kpis, setKpis] = useState<KPICardData[]>([]);
  const [summaryData, setSummaryData] = useState<any>(null);
  const [timelineData, setTimelineData] = useState<TimelineData | null>(null);
  const [queueAnalyticsData, setQueueAnalyticsData] = useState<QueueAnalyticsContainerData | null>(null);
  const [tmDetailsData, setTmDetailsData] = useState<TMDetailsContainerData | null>(null);
  const [sitePerformanceData, setSitePerformanceData] = useState<SitePerformanceContainerData | null>(null);
  const [fleetUtilizationData, setFleetUtilizationData] = useState<FleetUtilizationContainerData | null>(null);
  const [decisionIntelligenceData, setDecisionIntelligenceData] = useState<DecisionIntelligenceContainerData | null>(null);
  const [operationalWidgetsData, setOperationalWidgetsData] = useState<OperationalWidgetsContainerData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, [filters.plant_id, filters.customer_id, filters.dataset_type]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const query = new URLSearchParams({
        plant_id: filters.plant_id,
        customer_id: filters.customer_id,
        dataset_type: filters.dataset_type,
      }).toString();

      const [resMaster, resQueue, resTm, resPerf, resFleet, resDecision, resWidgets] = await Promise.all([
        fetch(`/fleet-api/v1/site-dashboard?${query}`),
        fetch(`/fleet-api/v1/site-dashboard/queue-analytics?${query}`),
        fetch(`/fleet-api/v1/site-dashboard/tm-details?${query}`),
        fetch(`/fleet-api/v1/site-dashboard/site-performance?${query}`),
        fetch(`/fleet-api/v1/site-dashboard/fleet-utilization?${query}`),
        fetch(`/fleet-api/v1/site-dashboard/decision-intelligence?${query}`),
        fetch(`/fleet-api/v1/site-dashboard/operational-widgets?${query}`),
      ]);

      const dataMaster = await resMaster.json();
      const dataQueue = await resQueue.json();
      const dataTm = await resTm.json();
      const dataPerf = await resPerf.json();
      const dataFleet = await resFleet.json();
      const dataDecision = await resDecision.json();
      const dataWidgets = await resWidgets.json();

      if (dataMaster.success && dataMaster.data) {
        const master = dataMaster.data;
        setKpis([
          master.kpis.dispatches,
          master.kpis.holding,
          master.kpis.retention,
          master.kpis.overlap,
          master.kpis.accuracy,
        ]);
        setSummaryData(master.summary);
        setTimelineData(master.timeline);
        if (master.response_metadata) {
          updateMetadata(master.response_metadata);
        }
      }

      if (dataQueue.success && dataQueue.data) {
        setQueueAnalyticsData(dataQueue.data);
      }

      if (dataTm.success && dataTm.data) {
        setTmDetailsData(dataTm.data);
      }

      if (dataPerf.success && dataPerf.data) {
        setSitePerformanceData(dataPerf.data);
      }

      if (dataFleet.success && dataFleet.data) {
        setFleetUtilizationData(dataFleet.data);
      }

      if (dataDecision.success && dataDecision.data) {
        setDecisionIntelligenceData(dataDecision.data);
      }

      if (dataWidgets.success && dataWidgets.data) {
        setOperationalWidgetsData(dataWidgets.data);
      }
    } catch (e) {
      // Fallback display
      setKpis([
        { key: 'dispatches', label: 'Total Dispatches', current_value: 0, unit: 'Trips', status: 'OPTIMAL' },
        { key: 'holding', label: 'Holding Beyond 20 min', current_value: 0.0, unit: 'hrs', threshold: 5.0, status: 'OPTIMAL' },
        { key: 'retention', label: 'Retention Beyond 10 min', current_value: 0.0, unit: 'hrs', threshold: 3.0, status: 'OPTIMAL' },
        { key: 'overlap', label: 'TM Overlap (Weighted)', current_value: 0.0, unit: 'TM-min', threshold: 60.0, status: 'OPTIMAL' },
        { key: 'accuracy', label: 'Dispatch Accuracy', current_value: 100.0, unit: '%', target: 90.0, variance: 10.0, status: 'OPTIMAL' },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <DashboardSyncProvider onRefreshNeeded={fetchDashboardData}>
      <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-5 space-y-6">
        {/* Top Bar Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-600/15 text-indigo-400 border border-indigo-500/30">
              <LayoutDashboard className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-100">
                Site Operational Intelligence Dashboard
              </h1>
              <p className="text-xs text-slate-400">
                Real-time Concrete Batching, Dispatch SLAs & TM Queue Monitoring
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <SyncStatusHeaderBadge />
          </div>
        </div>

        {/* Workstream 2.2 Global Dashboard Filter Bar */}
        <GlobalDashboardFilterBar />

        {/* Workstream 2.2 KPI Intelligence Cards */}
        <KPICardGrid cards={kpis} loading={loading} />

        {/* Master Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Column (3/4 Width): Core Operational Intelligence Panels */}
          <div className="lg:col-span-3 space-y-6">
            {/* Workstream 2.4 TM Queue Timeline (Gantt Engine) */}
            <TMQueueTimelineGantt data={timelineData} loading={loading} />

            {/* Workstream 2.5 Queue Analytics & Operational Trend Intelligence */}
            <QueueAnalyticsContainer data={queueAnalyticsData} loading={loading} />

            {/* Workstream 2.6 TM Details & Dispatch Intelligence Subsystem */}
            <TMDetailsContainer data={tmDetailsData} loading={loading} />

            {/* Workstream 2.7 Site Performance Intelligence & SLA Insights */}
            <SitePerformanceContainer data={sitePerformanceData} loading={loading} />

            {/* Workstream 2.8 Fleet Utilization, Vehicle Productivity & Asset Intelligence */}
            <FleetUtilizationContainer data={fleetUtilizationData} loading={loading} />

            {/* Workstream 2.9 Operational Decision Intelligence & Recommended Actions */}
            <DecisionIntelligenceContainer data={decisionIntelligenceData} loading={loading} />

            {/* Workstream 2.10 Site Operational Intelligence Dashboard Widgets */}
            <OperationalWidgetsContainer data={operationalWidgetsData} loading={loading} />
          </div>

          {/* Right Column (1/4 Width): Workstream 2.3 Site Summary Panel & Relocated Workstream 2.5 Root Causes */}
          <div className="lg:col-span-1 space-y-6">
            <SiteSummaryPanel data={summaryData} loading={loading} />
            
            {/* Relocated Workstream 2.5 Operational Root Causes & Bottleneck Panel */}
            <div className="p-5 rounded-2xl bg-gradient-to-b from-slate-900/95 to-slate-950/95 border border-slate-800/90 shadow-2xl backdrop-blur-md">
              <QueueReasonTable causes={queueAnalyticsData?.root_causes || []} />
            </div>
          </div>
        </div>
      </div>
    </DashboardSyncProvider>
  );
};

export const SiteDashboardPage: React.FC = () => {
  return (
    <DashboardFilterProvider>
      <SiteDashboardContent />
    </DashboardFilterProvider>
  );
};

export default SiteDashboardPage;
