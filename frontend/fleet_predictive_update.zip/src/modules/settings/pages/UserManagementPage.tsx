import React, { useState, useEffect } from 'react';
import { PageContainer } from '../../../layouts/PageContainer';
import { useAuthStore } from '../../../store/auth';
import { CreateUserModal } from '../components/CreateUserModal';
import { EditUserModal } from '../components/EditUserModal';
import { ResetPasswordModal } from '../components/ResetPasswordModal';
import {
  Users,
  UserCheck,
  UserX,
  KeyRound,
  ShieldAlert,
  Search,
  UserPlus,
  Edit2,
  RefreshCw,
  Trash2,
  AlertCircle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

interface PlantScope {
  id: string;
  code: string;
  name: string;
}

interface UserDetail {
  id: string;
  username: string;
  email: string;
  full_name: string | null;
  is_active: boolean;
  is_superuser: boolean;
  must_change_password: boolean;
  auth_stage: string;
  is_password_temporary: boolean;
  password_changed_at: string | null;
  deleted_at: string | null;
  deleted_by: string | null;
  roles: string[];
  plant_scopes: PlantScope[];
  last_login_at: string | null;
}

export const UserManagementPage: React.FC = () => {
  const [users, setUsers] = useState<UserDetail[]>([]);
  const [totalUsers, setTotalUsers] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(15);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [roleFilter, setRoleFilter] = useState<string>('ALL');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Modals state
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserDetail | null>(null);
  const [resetUser, setResetUser] = useState<{ id: string; username: string } | null>(null);
  const [deactivatingUser, setDeactivatingUser] = useState<UserDetail | null>(null);

  const token = useAuthStore((state) => state.token);

  // Hardcoded canonical roles and plants for options
  const availableRoles = [
    { id: 'Administrator', name: 'Administrator' },
    { id: 'Plant Dispatcher', name: 'Plant Dispatcher' },
    { id: 'Fleet Supervisor', name: 'Fleet Supervisor' },
    { id: 'Executive Viewer', name: 'Executive Viewer' },
  ];

  const availablePlants = [
    { id: 'PLANT-001', code: 'PLANT-001', name: 'Alcon Ready Mix Plant A' },
    { id: 'PLANT-002', code: 'PLANT-002', name: 'Alcon Ready Mix Plant B' },
    { id: 'PLANT-003', code: 'PLANT-003', name: 'Central Distribution Hub' },
  ];

  const fetchUsers = async () => {
    setLoading(true);
    setError(null);

    try {
      let url = `/fleet-api/v1/users?page=${page}&size=${pageSize}`;
      if (search) url += `&search=${encodeURIComponent(search)}`;
      if (statusFilter === 'ACTIVE') url += '&is_active=true';
      if (statusFilter === 'DISABLED') url += '&is_active=false';
      if (statusFilter === 'PASSWORD_CHANGE') url += '&must_change_password=true';
      if (roleFilter !== 'ALL') url += `&role=${encodeURIComponent(roleFilter)}`;

      const response = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) {
        if (response.status === 403) {
          throw new Error('403 Forbidden: Administrator access required');
        }
        throw new Error(`Failed to fetch users (${response.status})`);
      }

      const result = await response.json();
      const payload = result.data || result;
      setUsers(payload.items || []);
      setTotalUsers(payload.total || 0);
      setTotalPages(payload.pages || 1);


    } catch (err: any) {
      setError(err.message || 'Error loading users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [page, statusFilter, roleFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchUsers();
  };

  const handleDeactivate = async () => {
    if (!deactivatingUser) return;

    try {
      const response = await fetch(`/fleet-api/v1/users/${deactivatingUser.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error?.message || result.detail || 'Failed to deactivate user');
      }

      setDeactivatingUser(null);
      fetchUsers();
    } catch (err: any) {
      alert(err.message || 'Error deactivating user');
    }
  };

  // Metrics derivation
  const activeCount = users.filter((u) => u.is_active).length;
  const adminCount = users.filter((u) => u.is_superuser || u.roles.includes('Administrator')).length;
  const passwordChangeReqCount = users.filter((u) => u.must_change_password).length;

  return (
    <PageContainer title="User Management & Administrative Governance">
      <div className="space-y-6">
        {/* KPI Ribbon */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
            <div className="p-3 rounded-xl bg-indigo-500/15 text-indigo-400">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Total Users</p>
              <h3 className="text-xl font-bold text-slate-100">{totalUsers}</h3>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
            <div className="p-3 rounded-xl bg-emerald-500/15 text-emerald-400">
              <UserCheck className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Active Users (Page)</p>
              <h3 className="text-xl font-bold text-emerald-400">{activeCount}</h3>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
            <div className="p-3 rounded-xl bg-purple-500/15 text-purple-400">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Administrators (Page)</p>
              <h3 className="text-xl font-bold text-purple-400">{adminCount}</h3>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
            <div className="p-3 rounded-xl bg-amber-500/15 text-amber-400">
              <KeyRound className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Password Pending (Page)</p>
              <h3 className="text-xl font-bold text-amber-400">{passwordChangeReqCount}</h3>
            </div>
          </div>
        </div>

        {/* Action Controls & Filters */}
        <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800">
          <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 flex-1 max-w-md">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search username, email, full name..."
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <button
              type="submit"
              className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition"
            >
              Search
            </button>
          </form>

          <div className="flex flex-wrap items-center gap-3">
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(1);
              }}
              className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none"
            >
              <option value="ALL">All Statuses</option>
              <option value="ACTIVE">Active Accounts</option>
              <option value="DISABLED">Disabled Accounts</option>
              <option value="PASSWORD_CHANGE">Password Change Required</option>
            </select>

            <select
              value={roleFilter}
              onChange={(e) => {
                setRoleFilter(e.target.value);
                setPage(1);
              }}
              className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 focus:outline-none"
            >
              <option value="ALL">All Roles</option>
              <option value="Administrator">Administrator</option>
              <option value="Plant Dispatcher">Plant Dispatcher</option>
              <option value="Fleet Supervisor">Fleet Supervisor</option>
              <option value="Executive Viewer">Executive Viewer</option>
            </select>

            <button
              onClick={() => setIsCreateOpen(true)}
              className="py-2 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-indigo-500/20 transition"
            >
              <UserPlus className="w-4 h-4" />
              <span>Create New User</span>
            </button>
          </div>
        </div>

        {/* Error Notification */}
        {error && (
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400" />
              <span>{error}</span>
            </div>
            <button onClick={() => fetchUsers()} className="underline font-semibold text-rose-400 hover:text-rose-200">
              Retry
            </button>
          </div>
        )}

        {/* Users Data Table */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider text-[10px] font-bold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">User Identity</th>
                  <th className="py-3 px-4">Assigned Roles</th>
                  <th className="py-3 px-4">Account Status</th>
                  <th className="py-3 px-4">Password Stage</th>
                  <th className="py-3 px-4">Last Login</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {loading ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      Loading user directory from server...
                    </td>
                  </tr>
                ) : users.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      No user accounts found matching current query.
                    </td>
                  </tr>
                ) : (
                  users.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-800/40 transition">
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-100">{u.username}</div>
                        <div className="text-[11px] text-slate-400">{u.email}</div>
                        {u.full_name && <div className="text-[10px] text-slate-500">{u.full_name}</div>}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex flex-wrap gap-1">
                          {u.is_superuser && (
                            <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 text-[10px] font-bold">
                              Superuser
                            </span>
                          )}
                          {u.roles.map((r) => (
                            <span key={r} className="px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-300 text-[10px]">
                              {r}
                            </span>
                          ))}
                        </div>
                      </td>



                      <td className="py-3.5 px-4">
                        {u.is_active ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-400 font-semibold text-[10px]">
                            <CheckCircle2 className="w-3 h-3" /> Active
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-500/15 text-rose-400 font-semibold text-[10px]">
                            <UserX className="w-3 h-3" /> Disabled
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        {u.must_change_password ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/15 text-amber-400 font-semibold text-[10px]">
                            <KeyRound className="w-3 h-3" /> Temp / Pending Change
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400">Normal</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-slate-400 text-[11px]">
                        {u.last_login_at ? new Date(u.last_login_at).toLocaleString() : 'Never'}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setEditingUser(u)}
                            title="Edit User Details"
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => setResetUser({ id: u.id, username: u.username })}
                            title="Reset Password"
                            className="p-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/30 text-amber-400 transition"
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => setDeactivatingUser(u)}
                            title="Deactivate Account"
                            className="p-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 text-rose-400 transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination Footer */}
          <div className="p-4 bg-slate-950/60 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>
              Showing Page <strong>{page}</strong> of <strong>{totalPages}</strong> ({totalUsers} total users)
            </span>

            <div className="flex items-center gap-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Modals */}
        <CreateUserModal
          isOpen={isCreateOpen}
          onClose={() => setIsCreateOpen(false)}
          onSuccess={fetchUsers}
          token={token}
          availableRoles={availableRoles}
          availablePlants={availablePlants}
        />

        <EditUserModal
          isOpen={Boolean(editingUser)}
          user={editingUser}
          onClose={() => setEditingUser(null)}
          onSuccess={fetchUsers}
          token={token}
          availableRoles={availableRoles}
          availablePlants={availablePlants}
        />

        <ResetPasswordModal
          isOpen={Boolean(resetUser)}
          userId={resetUser?.id || null}
          username={resetUser?.username || null}
          onClose={() => setResetUser(null)}
          onSuccess={fetchUsers}
          token={token}
        />

        {/* Deactivation Confirmation Modal */}
        {deactivatingUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
            <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
              <div className="flex items-center gap-2.5 text-rose-400 font-bold text-base">
                <Trash2 className="w-5 h-5" />
                <span>Confirm Soft Deactivation</span>
              </div>

              <p className="text-xs text-slate-300">
                Are you sure you want to deactivate the user account for <strong>{deactivatingUser.username}</strong>?
                The user account will be soft-deleted (`deleted_at = NOW()`), active sessions will be invalidated, and login will be disabled.
              </p>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800 text-xs">
                <button
                  onClick={() => setDeactivatingUser(null)}
                  className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeactivate}
                  className="py-2.5 px-5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold transition"
                >
                  Deactivate Account
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </PageContainer>
  );
};

export default UserManagementPage;
