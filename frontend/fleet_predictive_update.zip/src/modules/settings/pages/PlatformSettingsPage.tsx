import React, { useEffect, useState } from 'react';
import { Settings, Search, Save, RotateCcw, CheckCircle2, Database, Cpu, DollarSign, Radio, Gauge, Bell, ShieldCheck, Globe, ToggleRight, Layout, Sparkles, Building, ChevronRight, Users } from 'lucide-react';
import { CompanyCustomerSettingsSection } from '../components/CompanyCustomerSettingsSection';

interface ConfigurationCategory {
  id: string;
  category_name: string;
  display_name: string;
  icon: string;
  display_order: number;
  description?: string;
}

interface PlatformConfiguration {
  id: string;
  domain: string;
  category: string;
  sub_category?: string;
  key: string;
  value: any;
  value_type: string;
  unit?: string;
  editable: boolean;
  is_secret: boolean;
  requires_restart: boolean;
  description?: string;
}

const categoryIcons: Record<string, React.ReactNode> = {
  customers: <Building className="w-4 h-4" />,
  business: <Building className="w-4 h-4" />,
  cost: <DollarSign className="w-4 h-4" />,
  fleet: <Database className="w-4 h-4" />,
  telemetry: <Radio className="w-4 h-4" />,
  correlation: <Cpu className="w-4 h-4" />,
  kpi: <Gauge className="w-4 h-4" />,
  ai: <Sparkles className="w-4 h-4" />,
  dashboard: <Layout className="w-4 h-4" />,
  notifications: <Bell className="w-4 h-4" />,
  security: <ShieldCheck className="w-4 h-4" />,
  integrations: <Globe className="w-4 h-4" />,
  feature_flags: <ToggleRight className="w-4 h-4" />,
};

export const PlatformSettingsPage: React.FC = () => {
  const [categories, setCategories] = useState<ConfigurationCategory[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('customers');
  const [configurations, setConfigurations] = useState<PlatformConfiguration[]>([]);
  const [editedValues, setEditedValues] = useState<Record<string, any>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [saving, setSaving] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    if (activeCategory && activeCategory !== 'customers') {
      fetchDomainConfigurations(activeCategory);
    }
  }, [activeCategory]);

  const fetchCategories = async () => {
    try {
      const res = await fetch('/fleet-api/v1/settings/categories');
      const data = await res.json();
      if (data.success) {
        setCategories([
          { id: 'cat-cust', category_name: 'customers', display_name: 'Company & Customer Accounts', icon: 'Building', display_order: 5, description: 'Display name overrides & plant contexts' },
          ...data.data
        ]);
      }
    } catch (e) {
      // Fallback local categories
      setCategories([
        { id: 'cat-cust', category_name: 'customers', display_name: 'Company & Customer Accounts', icon: 'Building', display_order: 5, description: 'Display name overrides & plant contexts' },
        { id: '1', category_name: 'business', display_name: 'Business & Organization', icon: 'Building', display_order: 10, description: 'Company details & GST' },
        { id: '2', category_name: 'cost', display_name: 'Cost & Fuel Economics', icon: 'DollarSign', display_order: 20, description: 'Diesel price & wages' },
        { id: '3', category_name: 'telemetry', display_name: 'Telemetry & GPS', icon: 'Radio', display_order: 30, description: 'GPS accuracy & geofences' },
        { id: '4', category_name: 'correlation', display_name: 'Cross-Source Correlator', icon: 'Cpu', display_order: 40, description: '11-Factor rule thresholds' },
        { id: '5', category_name: 'ai', display_name: 'AI & Predictions', icon: 'Sparkles', display_order: 50, description: 'Recommendation confidence' },
        { id: '6', category_name: 'feature_flags', display_name: 'Feature Flags', icon: 'ToggleRight', display_order: 60, description: 'Module toggles' },
      ]);
    }
  };

  const fetchDomainConfigurations = async (domain: string) => {
    try {
      const res = await fetch(`/fleet-api/v1/settings/${domain}`);
      const data = await res.json();
      if (data.success) {
        setConfigurations(data.data);
        setEditedValues({});
      }
    } catch (e) {
      // Fallback configuration items
      setConfigurations([
        { id: 'c1', domain: 'cost', category: 'cost', key: 'diesel_price_per_liter', value: 92.50, value_type: 'NUMBER', unit: '₹/L', editable: true, is_secret: false, requires_restart: false, description: 'Benchmark diesel cost per liter.' },
        { id: 'c2', domain: 'cost', category: 'cost', key: 'driver_cost_per_hour', value: 180.00, value_type: 'NUMBER', unit: '₹/hr', editable: true, is_secret: false, requires_restart: false, description: 'Driver wage rate per hour.' },
        { id: 'c3', domain: 'cost', category: 'cost', key: 'vehicle_operating_cost_per_km', value: 35.00, value_type: 'NUMBER', unit: '₹/km', editable: true, is_secret: false, requires_restart: false, description: 'Vehicle wear-and-tear per kilometer.' },
      ]);
      setEditedValues({});
    }
  };

  const handleInputChange = (key: string, val: any) => {
    setEditedValues((prev) => ({ ...prev, [key]: val }));
  };

  const handleSaveAll = async () => {
    setSaving(true);
    try {
      for (const [key, val] of Object.entries(editedValues)) {
        await fetch(`/fleet-api/v1/settings/${activeCategory}/${key}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ value: val, change_reason: 'Updated via Settings Center UI' }),
        });
      }
      await fetch('/fleet-api/v1/settings/cache/reload', { method: 'POST' });
      await fetchDomainConfigurations(activeCategory);
      setNotification('Configurations successfully updated and committed to PostgreSQL.');
      setTimeout(() => setNotification(null), 4000);
    } catch (e) {
      setNotification('Failed to save configuration updates.');
    } finally {
      setSaving(false);
    }
  };

  const filteredConfigs = configurations.filter(
    (c) =>
      c.key.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.description && c.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const isDirty = Object.keys(editedValues).length > 0;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-600/15 text-indigo-400 border border-indigo-500/30">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-100">
              Platform Configuration Registry
            </h1>
            <p className="text-xs text-slate-400">
              Centralized Operational Settings, Company & Customer Accounts & PostgreSQL Control Center
            </p>
          </div>
        </div>

        {/* Global Search across Settings */}
        {activeCategory !== 'customers' && (
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search configuration keys..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition min-h-[44px] md:min-h-[36px]"
            />
          </div>
        )}
      </div>

      {/* Notification Banner */}
      {notification && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{notification}</span>
        </div>
      )}

      {/* Settings Grid Layout: Left Nav + Right Config Form */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Left Nav Category Selector */}
        <div className="space-y-1.5 bg-slate-900/60 p-3 rounded-2xl border border-slate-800 h-fit">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-3 py-1.5 block">
            Configuration Domains
          </span>
          {categories.map((cat) => {
            const isActive = activeCategory === cat.category_name;
            return (
              <button
                key={cat.category_name}
                type="button"
                onClick={() => setActiveCategory(cat.category_name)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition min-h-[44px] sm:min-h-[36px] ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                    : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  {categoryIcons[cat.category_name] || <Settings className="w-4 h-4" />}
                  <span className="truncate">{cat.display_name}</span>
                </div>
                <ChevronRight className={`w-3.5 h-3.5 opacity-60 ${isActive ? 'text-white' : 'text-slate-500'}`} />
              </button>
            );
          })}
        </div>

        {/* Right Content Viewport */}
        <div className="lg:col-span-3 space-y-6">
          {activeCategory === 'customers' ? (
            <CompanyCustomerSettingsSection />
          ) : (
            <>
              {/* Action Bar */}
              <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900/60 border border-slate-800">
                <div>
                  <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                    {categories.find((c) => c.category_name === activeCategory)?.display_name || activeCategory} Settings
                  </h2>
                  <p className="text-xs text-slate-400">
                    {categories.find((c) => c.category_name === activeCategory)?.description || 'Configure parameters.'}
                  </p>
                </div>

                {isDirty && (
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setEditedValues({})}
                      className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition min-h-[44px] sm:min-h-[36px]"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Discard
                    </button>
                    <button
                      type="button"
                      disabled={saving}
                      onClick={handleSaveAll}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition shadow-lg shadow-indigo-500/20 min-h-[44px] sm:min-h-[36px] disabled:opacity-50"
                    >
                      <Save className="w-3.5 h-3.5" />
                      {saving ? 'Committing...' : 'Save Changes'}
                    </button>
                  </div>
                )}
              </div>

              {/* Dynamic Configuration Controls Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredConfigs.map((cfg) => {
                  const currentValue = editedValues[cfg.key] !== undefined ? editedValues[cfg.key] : cfg.value;

                  return (
                    <div
                      key={cfg.key}
                      className={`p-5 rounded-2xl bg-slate-900/80 border transition space-y-3 ${
                        editedValues[cfg.key] !== undefined
                          ? 'border-indigo-500/60 bg-indigo-950/10'
                          : 'border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-indigo-300 font-mono">
                          {cfg.key}
                        </span>
                        {cfg.unit && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                            {cfg.unit}
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-slate-400 leading-relaxed min-h-[32px]">
                        {cfg.description || 'System configuration parameter.'}
                      </p>

                      {/* Input Rendering based on Value Type */}
                      <div>
                        {cfg.value_type === 'BOOLEAN' ? (
                          <label className="flex items-center gap-3 cursor-pointer bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                            <input
                              type="checkbox"
                              checked={Boolean(currentValue)}
                              onChange={(e) => handleInputChange(cfg.key, e.target.checked)}
                              className="rounded bg-slate-900 border-slate-700 text-indigo-600 focus:ring-0 w-4 h-4"
                            />
                            <span className="text-xs font-semibold text-slate-200">
                              {currentValue ? 'Enabled (True)' : 'Disabled (False)'}
                            </span>
                          </label>
                        ) : (
                          <input
                            type={cfg.value_type === 'NUMBER' ? 'number' : 'text'}
                            value={currentValue}
                            disabled={!cfg.editable}
                            onChange={(e) =>
                              handleInputChange(
                                cfg.key,
                                cfg.value_type === 'NUMBER' ? parseFloat(e.target.value) || 0 : e.target.value
                              )
                            }
                            className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-slate-100 focus:outline-none focus:border-indigo-500 transition min-h-[44px] sm:min-h-[36px]"
                          />
                        )}
                      </div>
                    </div>
                  );
                })}

              </div>
            </>
          )}


        </div>
      </div>
    </div>
  );
};

export default PlatformSettingsPage;

