import React, { useState } from 'react';
import { X, KeyRound, Copy, Check, ShieldAlert, AlertCircle } from 'lucide-react';

interface ResetPasswordModalProps {
  isOpen: boolean;
  userId: string | null;
  username: string | null;
  onClose: () => void;
  onSuccess: () => void;
  token: string | null;
}

export const ResetPasswordModal: React.FC<ResetPasswordModalProps> = ({
  isOpen,
  userId,
  username,
  onClose,
  onSuccess,
  token,
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tempPassword, setTempPassword] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen || !userId) return null;

  const handleReset = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/fleet-api/v1/users/${userId}/reset-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error?.message || result.detail || 'Failed to reset password');
      }

      setTempPassword(result.data.temporary_password);
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Error resetting password');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (tempPassword) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(tempPassword);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = tempPassword;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };


  const handleClose = () => {
    setTempPassword(null);
    setError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5 relative">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">Reset User Password</h2>
              <p className="text-[11px] text-slate-400">Invalidate active sessions & generate temporary credential</p>
            </div>
          </div>
          <button onClick={handleClose} className="text-slate-400 hover:text-slate-200 p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {tempPassword ? (
          <div className="space-y-4 py-2 text-xs">
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 space-y-1.5">
              <div className="flex items-center gap-2 font-bold text-amber-400">
                <ShieldAlert className="w-4 h-4" />
                <span>Password Reset Successfully!</span>
              </div>
              <p className="text-slate-300">
                All active sessions for <strong>{username}</strong> have been invalidated. Provide this temporary credential to the user.
              </p>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                New One-Time Temporary Password
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={tempPassword}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-sm text-amber-400 font-bold select-all focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleCopy}
                  className="py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold flex items-center gap-1.5 transition"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>
            </div>

            <button
              onClick={handleClose}
              className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold transition"
            >
              Done & Close Dialog
            </button>
          </div>
        ) : (
          <div className="space-y-4 text-xs">
            <p className="text-slate-300">
              Are you sure you want to reset the password for user <strong>{username}</strong>?
            </p>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 text-[11px] space-y-1">
              <p>• Generating a new temporary password</p>
              <p>• Setting status to <code>PASSWORD_CHANGE_REQUIRED</code></p>
              <p>• Immediately invalidating all active user sessions (`token_version++`)</p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={handleClose}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleReset}
                disabled={loading}
                className="py-2.5 px-5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold transition disabled:opacity-50"
              >
                {loading ? 'Resetting Password...' : 'Confirm Password Reset'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
