import React, { useState, useEffect } from 'react';
import { X, UserCheck, AlertCircle } from 'lucide-react';

interface RoleOption {
  id: string;
  name: string;
}

interface PlantOption {
  id: string;
  code: string;
  name: string;
}

interface UserDetail {
  id: string;
  username: string;
  email: string;
  full_name: string | null;
  is_active: boolean;
  roles: string[];
  plant_scopes: { id: string; code: string; name: string }[];
}

interface EditUserModalProps {
  isOpen: boolean;
  user: UserDetail | null;
  onClose: () => void;
  onSuccess: () => void;
  token: string | null;
  availableRoles: RoleOption[];
  availablePlants: PlantOption[];
}

export const EditUserModal: React.FC<EditUserModalProps> = ({
  isOpen,
  user,
  onClose,
  onSuccess,
  token,
  availableRoles,
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [selectedRoleIds, setSelectedRoleIds] = useState<string[]>([]);
  const [selectedPlantIds, setSelectedPlantIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      setFullName(user.full_name || '');
      setEmail(user.email || '');
      setIsActive(user.is_active);
      setSelectedRoleIds(user.roles || []);
      setSelectedPlantIds((user.plant_scopes || []).map((p) => p.code));
    }
  }, [user]);

  if (!isOpen || !user) return null;

  const handleRoleToggle = (roleName: string) => {
    setSelectedRoleIds((prev) =>
      prev.includes(roleName) ? prev.filter((r) => r !== roleName) : [...prev, roleName]
    );
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/fleet-api/v1/users/${user.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          full_name: fullName,
          email,
          is_active: isActive,
          role_ids: selectedRoleIds,
          plant_ids: selectedPlantIds,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error?.message || result.detail || 'Failed to update user');
      }

      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Error updating user');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="max-w-lg w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5 relative">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-500/15 text-purple-400">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">Edit User Details</h2>
              <p className="text-[11px] text-slate-400">Update profile, account status, roles, and plant authorization</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200 p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-slate-400 uppercase tracking-wider block">
                Username (Immutable)
              </label>
              <input
                type="text"
                disabled
                value={user.username}
                className="w-full px-3 py-2 rounded-xl bg-slate-950/60 border border-slate-800/60 text-slate-400 cursor-not-allowed"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300 uppercase tracking-wider block">
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-slate-300 uppercase tracking-wider block">
                Full Name
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-purple-500"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-300 uppercase tracking-wider block">
                Account Status
              </label>
              <select
                value={isActive ? 'true' : 'false'}
                onChange={(e) => setIsActive(e.target.value === 'true')}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-purple-500"
              >
                <option value="true">Active Account</option>
                <option value="false">Disabled / Locked</option>
              </select>
            </div>
          </div>

          {/* Roles Selection */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-300 uppercase tracking-wider block">
              Manage Roles
            </label>
            <div className="flex flex-wrap gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 max-h-28 overflow-y-auto">
              {availableRoles.map((role) => {
                const active = selectedRoleIds.includes(role.name) || selectedRoleIds.includes(role.id);
                return (
                  <button
                    key={role.id}
                    type="button"
                    onClick={() => handleRoleToggle(role.name)}
                    className={`px-2.5 py-1 rounded-lg border font-medium transition text-[11px] ${
                      active
                        ? 'bg-purple-600/30 border-purple-500 text-purple-300'
                        : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {role.name}
                  </button>

                );
              })}

              </div>
            </div>


          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">


            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="py-2.5 px-5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold flex items-center gap-2 transition disabled:opacity-50"
            >
              {loading ? 'Saving Changes...' : 'Save & Invalidate Stale Sessions'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
