import React from 'react';
import { AlertCircle, AlertTriangle, Building, Users, Clock, ExternalLink } from 'lucide-react';
import { KPICard } from '../../../components/common/KPICard';
import { useNavigate } from 'react-router-dom';

export interface AlertSummaryCounts {
  total_active: number;
  open_count: number;
  acknowledged_count: number;
  critical_count: number;
  warning_count: number;
  info_count: number;
}

export interface AlertSeverityDistributionItem {
  severity: string;
  count: number;
  percentage: number;
}

export interface AlertCategoryDistributionItem {
  alert_type: string;
  label: string;
  severity: string;
  count: number;
  percentage: number;
}

export interface AlertConcentrationItem {
  group_type: 'PLANT' | 'CUSTOMER';
  group_code: string;
  group_name: string;
  critical_count: number;
  warning_count: number;
  total_count: number;
}

export interface PriorityAlertItem {
  id: string;
  alert_type: string;
  severity: string;
  status: string;
  plant_id: string;
  customer_id: string;
  metric_name?: string | null;
  actual_value?: number | null;
  threshold_value?: number | null;
  unit?: string | null;
  business_impact?: string | null;
  detected_at: string;
}

export interface OperationalAlertIntelligenceData {
  summary: AlertSummaryCounts;
  severity_distribution: AlertSeverityDistributionItem[];
  top_categories: AlertCategoryDistributionItem[];
  plant_concentration: AlertConcentrationItem[];
  customer_concentration: AlertConcentrationItem[];
  priority_alerts: PriorityAlertItem[];
  calculation_status: 'SUCCESS' | 'NO_RECORDS' | 'NOT_CONFIGURED' | 'ERROR';
  calculation_notes: string;
}

interface OperationalAlertIntelligenceSectionProps {
  data: OperationalAlertIntelligenceData | null;
}

export const OperationalAlertIntelligenceSection: React.FC<OperationalAlertIntelligenceSectionProps> = ({ data }) => {
  const navigate = useNavigate();

  if (!data || !data.summary) return null;

  const { summary, severity_distribution, top_categories, plant_concentration, customer_concentration, priority_alerts } = data;

  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'CRITICAL':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
            CRITICAL
          </span>
        );
      case 'WARNING':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
            WARNING
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-500/15 text-sky-400 border border-sky-500/30">
            INFO
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Summary Ribbon: 5 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard
          title="Total Active Alerts"
          value={summary.total_active}
          change={summary.total_active > 0 ? `${summary.open_count} Open` : 'Clear'}
          changeType={summary.total_active > 0 ? 'negative' : 'positive'}
          subtitle="Status: OPEN or ACKNOWLEDGED"
        />
        <KPICard
          title="Active Critical"
          value={summary.critical_count}
          change={summary.critical_count > 0 ? 'P1 Immediate' : 'Zero'}
          changeType={summary.critical_count > 0 ? 'negative' : 'positive'}
          subtitle="Severity: CRITICAL"
        />
        <KPICard
          title="Active Warning"
          value={summary.warning_count}
          change={summary.warning_count > 0 ? 'P2 Risk' : 'Zero'}
          changeType={summary.warning_count > 0 ? 'negative' : 'positive'}
          subtitle="Severity: WARNING"
        />
        <KPICard
          title="Active Informational"
          value={summary.info_count}
          change="P3 Notice"
          changeType="neutral"
          subtitle="Severity: INFO"
        />
        <KPICard
          title="In-Triage Acknowledged"
          value={summary.acknowledged_count}
          change="Acknowledged"
          changeType="positive"
          subtitle="Status: ACKNOWLEDGED"
        />
      </div>

      {/* 2. Middle Grid: Severity Risk Distribution & Top Categories */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Severity Risk Distribution */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-indigo-400" /> Severity & Operational Risk Distribution
            </h3>
            <span className="text-[11px] font-mono text-slate-400">Total Active: {summary.total_active}</span>
          </div>

          <div className="space-y-3">
            {severity_distribution.map((item) => (
              <div key={item.severity} className="space-y-1">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-300">{item.severity}</span>
                  <span className="font-mono text-slate-400">{item.count} ({item.percentage}%)</span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                  <div
                    className={`h-full rounded-full transition-all ${
                      item.severity === 'CRITICAL'
                        ? 'bg-rose-500'
                        : item.severity === 'WARNING'
                        ? 'bg-amber-500'
                        : 'bg-sky-500'
                    }`}
                    style={{ width: `${Math.min(100, Math.max(0, item.percentage))}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Active Alert Categories */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-4">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-indigo-400" /> Top Active Exception Categories
          </h3>

          <div className="space-y-2.5">
            {top_categories.length === 0 ? (
              <div className="text-xs text-slate-500 italic py-4 text-center">No active exception categories</div>
            ) : (
              top_categories.map((cat) => (
                <div key={cat.alert_type} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <div className="flex items-center gap-2.5">
                    {getSeverityBadge(cat.severity)}
                    <span className="font-semibold text-slate-200">{cat.label}</span>
                  </div>
                  <div className="font-mono text-slate-400">
                    <strong className="text-slate-200">{cat.count}</strong> ({cat.percentage}%)
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* 3. Operational Concentration Grid: Plant & Customer */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Plant Concentration */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Building className="w-4 h-4 text-indigo-400" /> Plant Operational Alert Concentration
          </h3>
          <div className="space-y-2">
            {plant_concentration.length === 0 ? (
              <div className="text-xs text-slate-500 italic py-3 text-center">No active plant concentration</div>
            ) : (
              plant_concentration.map((p) => (
                <div key={p.group_code} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <span className="font-semibold text-slate-300 font-mono">{p.group_name}</span>
                  <div className="flex items-center gap-3 font-mono">
                    <span className="text-rose-400">{p.critical_count} Critical</span>
                    <span className="text-slate-600">|</span>
                    <span className="text-amber-400">{p.warning_count} Warning</span>
                    <span className="text-slate-600">|</span>
                    <strong className="text-slate-200">{p.total_count} Total</strong>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Customer Concentration */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Users className="w-4 h-4 text-indigo-400" /> Customer Operational Alert Concentration
          </h3>
          <div className="space-y-2">
            {customer_concentration.length === 0 ? (
              <div className="text-xs text-slate-500 italic py-3 text-center">No active customer concentration</div>
            ) : (
              customer_concentration.map((c) => (
                <div key={c.group_code} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <span className="font-semibold text-slate-300 font-mono truncate max-w-[200px]">{c.group_name}</span>
                  <div className="flex items-center gap-3 font-mono shrink-0">
                    <span className="text-rose-400">{c.critical_count} Critical</span>
                    <span className="text-slate-600">|</span>
                    <span className="text-amber-400">{c.warning_count} Warning</span>
                    <span className="text-slate-600">|</span>
                    <strong className="text-slate-200">{c.total_count} Total</strong>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* 4. Priority Unresolved Alerts Section */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Clock className="w-4 h-4 text-indigo-400" /> Priority Unresolved Alerts (Ranked by Severity & Age)
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Top 5 highest priority active alerts requiring immediate operational triage</p>
          </div>
          <button
            onClick={() => navigate('/alerts')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-600/30 transition"
          >
            <span>Open Alert Center</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {priority_alerts.length === 0 ? (
            <div className="text-xs text-slate-500 italic py-6 text-center">Zero active unresolved alerts</div>
          ) : (
            priority_alerts.map((a) => (
              <div
                key={a.id}
                onClick={() => navigate(`/alerts?alert_id=${a.id}`)}
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-lg bg-slate-950 border border-slate-800 hover:border-indigo-500/40 transition cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  {getSeverityBadge(a.severity)}
                  <div>
                    <div className="text-xs font-bold text-slate-200 group-hover:text-indigo-300 transition">
                      {a.alert_type.replace(/_/g, ' ')}
                    </div>
                    <div className="text-[11px] font-mono text-slate-400 flex items-center gap-2 mt-0.5">
                      <span>Plant: <strong>{a.plant_id}</strong></span>
                      <span>•</span>
                      <span>Customer: <strong>{a.customer_id}</strong></span>
                      {a.actual_value !== null && a.actual_value !== undefined && (
                        <>
                          <span>•</span>
                          <span>Value: <strong>{a.actual_value} {a.unit || ''}</strong></span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-[11px] font-mono text-slate-400 shrink-0">
                  <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800">{a.status}</span>
                  <span>Detected: {new Date(a.detected_at).toLocaleTimeString()}</span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Provenance Footer */}
        <div className="pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-500">
          <span className="text-indigo-400 font-bold">PostgreSQL Lineage:</span> {data.calculation_notes}
        </div>
      </div>
    </div>
  );
};
