import React from 'react';
import { IndianRupee, TrendingUp, DollarSign, Fuel, Building, Users } from 'lucide-react';
import { KPICard } from '../../../components/common/KPICard';

export interface FinancialSummaryCounts {
  total_financial_exposure_inr: number;
  holding_delay_cost_inr: number;
  retention_sla_penalty_inr: number;
  idle_fuel_waste_inr: number;
  total_penalty_mins: number;
}

export interface FinancialBreakdownItem {
  category: 'PLANT_HOLDING' | 'CUSTOMER_RETENTION' | 'IDLE_FUEL';
  label: string;
  penalty_mins: number;
  cost_rate_per_min: number;
  total_cost_inr: number;
  percentage: number;
}

export interface EntityFinancialRiskItem {
  entity_type: 'PLANT' | 'CUSTOMER';
  entity_code: string;
  entity_name: string;
  penalty_mins: number;
  financial_exposure_inr: number;
}

export interface OperationalFinancialExposureData {
  summary: FinancialSummaryCounts;
  breakdown: FinancialBreakdownItem[];
  top_plant_risk: EntityFinancialRiskItem[];
  top_customer_risk: EntityFinancialRiskItem[];
  calculation_status: 'SUCCESS' | 'NO_RECORDS' | 'NOT_CONFIGURED' | 'ERROR';
  calculation_notes: string;
}

interface OperationalFinancialExposureSectionProps {
  data: OperationalFinancialExposureData | null;
}

export const OperationalFinancialExposureSection: React.FC<OperationalFinancialExposureSectionProps> = ({ data }) => {
  if (!data || !data.summary) return null;

  const { summary, breakdown, top_plant_risk, top_customer_risk } = data;

  const formatINR = (val: number) => {
    return `₹${val.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
  };

  return (
    <div className="space-y-6">
      {/* 1. Financial Summary Ribbon: 5 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard
          title="Total Financial Exposure"
          value={formatINR(summary.total_financial_exposure_inr)}
          change={summary.total_financial_exposure_inr > 0 ? 'Risk Active' : 'Zero Risk'}
          changeType={summary.total_financial_exposure_inr > 0 ? 'negative' : 'positive'}
          subtitle="Quantified Delay Loss & SLA Penalty"
        />
        <KPICard
          title="Plant Holding Loss"
          value={formatINR(summary.holding_delay_cost_inr)}
          change="Rate: ₹25/min"
          changeType="negative"
          subtitle="Excess Queue Holding Cost"
        />
        <KPICard
          title="Customer SLA Penalty"
          value={formatINR(summary.retention_sla_penalty_inr)}
          change="Rate: ₹35/min"
          changeType="negative"
          subtitle="Customer Site Retention SLA Cost"
        />
        <KPICard
          title="Idle Fuel Waste"
          value={formatINR(summary.idle_fuel_waste_inr)}
          change="Rate: ₹15/min"
          changeType="neutral"
          subtitle="Mixer Truck Engine Idle Waste"
        />
        <KPICard
          title="Total Penalty Minutes"
          value={`${summary.total_penalty_mins.toLocaleString()}m`}
          change="Excess Delay"
          changeType="negative"
          subtitle="Sum of Holding + Retention Excess"
        />
      </div>

      {/* 2. Middle Grid: Cost Breakdown & Top Plant Risk */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Cost Category Breakdown */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <IndianRupee className="w-4 h-4 text-indigo-400" /> Quantified Cost Category Breakdown
            </h3>
            <span className="text-[11px] font-mono text-slate-400">Total: {formatINR(summary.total_financial_exposure_inr)}</span>
          </div>

          <div className="space-y-3">
            {breakdown.map((item) => (
              <div key={item.category} className="space-y-1.5 p-3 rounded-lg bg-slate-950 border border-slate-800">
                <div className="flex justify-between items-center text-xs font-semibold">
                  <div className="flex items-center gap-2 text-slate-200">
                    {item.category === 'PLANT_HOLDING' ? (
                      <DollarSign className="w-3.5 h-3.5 text-amber-400" />
                    ) : item.category === 'CUSTOMER_RETENTION' ? (
                      <TrendingUp className="w-3.5 h-3.5 text-rose-400" />
                    ) : (
                      <Fuel className="w-3.5 h-3.5 text-sky-400" />
                    )}
                    <span>{item.label}</span>
                  </div>
                  <div className="font-mono text-slate-200">
                    <strong>{formatINR(item.total_cost_inr)}</strong> ({item.percentage}%)
                  </div>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                  <div
                    className={`h-full rounded-full transition-all ${
                      item.category === 'PLANT_HOLDING'
                        ? 'bg-amber-500'
                        : item.category === 'CUSTOMER_RETENTION'
                        ? 'bg-rose-500'
                        : 'bg-sky-500'
                    }`}
                    style={{ width: `${Math.min(100, Math.max(0, item.percentage))}%` }}
                  />
                </div>
                <div className="flex justify-between text-[11px] text-slate-500 font-mono pt-0.5">
                  <span>Penalty: {item.penalty_mins} mins</span>
                  <span>Rate: ₹{item.cost_rate_per_min}/min</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Plant Financial Risk Concentration */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Building className="w-4 h-4 text-indigo-400" /> Plant Financial Risk Concentration
          </h3>
          <div className="space-y-2">
            {top_plant_risk.length === 0 ? (
              <div className="text-xs text-slate-500 italic py-4 text-center">Zero plant financial risk</div>
            ) : (
              top_plant_risk.map((p) => (
                <div key={p.entity_code} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <span className="font-semibold text-slate-300 font-mono">{p.entity_name}</span>
                  <div className="flex items-center gap-3 font-mono">
                    <span className="text-slate-400">{p.penalty_mins} mins</span>
                    <span className="text-slate-600">|</span>
                    <strong className="text-rose-400">{formatINR(p.financial_exposure_inr)}</strong>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* 3. Customer Financial Risk Concentration */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <Users className="w-4 h-4 text-indigo-400" /> Customer Financial Risk Concentration
        </h3>
        <div className="space-y-2">
          {top_customer_risk.length === 0 ? (
            <div className="text-xs text-slate-500 italic py-4 text-center">Zero customer financial risk</div>
          ) : (
            top_customer_risk.map((c) => (
              <div key={c.entity_code} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                <span className="font-semibold text-slate-300 font-mono truncate max-w-[300px]">{c.entity_name}</span>
                <div className="flex items-center gap-3 font-mono shrink-0">
                  <span className="text-slate-400">{c.penalty_mins} mins</span>
                  <span className="text-slate-600">|</span>
                  <strong className="text-rose-400">{formatINR(c.financial_exposure_inr)}</strong>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Lineage Provenance Footer */}
        <div className="pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-500">
          <span className="text-indigo-400 font-bold">PostgreSQL Lineage:</span> {data.calculation_notes}
        </div>
      </div>
    </div>
  );
};
