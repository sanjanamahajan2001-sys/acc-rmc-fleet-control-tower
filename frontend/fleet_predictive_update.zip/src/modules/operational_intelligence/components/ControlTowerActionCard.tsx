import React from 'react';
import { Clock, CheckCircle2, Play, AlertCircle, Info, ShieldAlert, Truck, Building2, User } from 'lucide-react';
import { ActionLogItem } from '../api/actionExecutionApi';

interface ControlTowerActionCardProps {
  action: ActionLogItem;
  onAccept: (action: ActionLogItem) => void;
  onStartProgress: (action: ActionLogItem) => void;
  onConfirmExecution: (action: ActionLogItem) => void;
  onReject: (action: ActionLogItem) => void;
  onDefer: (action: ActionLogItem) => void;
  onViewAudit: (action: ActionLogItem) => void;
}

export const ControlTowerActionCard: React.FC<ControlTowerActionCardProps> = ({
  action,
  onAccept,
  onStartProgress,
  onConfirmExecution,
  onReject,
  onDefer,
  onViewAudit,
}) => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'PENDING':
        return <span className="px-2.5 py-1 text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full flex items-center gap-1"><Clock className="w-3 h-3"/> PENDING DECISION</span>;
      case 'ACCEPTED':
        return <span className="px-2.5 py-1 text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full flex items-center gap-1"><CheckCircle2 className="w-3 h-3"/> INTENT APPROVED</span>;
      case 'IN_PROGRESS':
        return <span className="px-2.5 py-1 text-xs font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-full flex items-center gap-1 animate-pulse"><Play className="w-3 h-3"/> IN PROGRESS</span>;
      case 'EXECUTED':
        return <span className="px-2.5 py-1 text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full flex items-center gap-1"><CheckCircle2 className="w-3 h-3"/> PHYSICAL EXECUTION CONFIRMED</span>;
      case 'REJECTED':
        return <span className="px-2.5 py-1 text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-full flex items-center gap-1"><AlertCircle className="w-3 h-3"/> REJECTED</span>;
      case 'DEFERRED':
        return <span className="px-2.5 py-1 text-xs font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-full flex items-center gap-1"><Clock className="w-3 h-3"/> DEFERRED</span>;
      default:
        return <span className="px-2.5 py-1 text-xs font-bold bg-slate-700 text-slate-300 rounded-full">{status}</span>;
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 hover:border-indigo-500/40 rounded-xl p-5 shadow-md transition-all duration-200 flex flex-col justify-between">
      <div>
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] font-bold tracking-wider text-indigo-400 uppercase bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/40">
                {action.action_type}
              </span>
              <span className="text-xs text-slate-400 font-mono">REC ID: {action.recommendation_id}</span>
            </div>
            <h3 className="text-sm font-bold text-white leading-snug">
              Dispatch {action.dispatch_code || action.dispatch_id}
            </h3>
            <div className="text-xs text-indigo-300 font-semibold mt-1 bg-indigo-950/40 px-2.5 py-1 rounded border border-indigo-800/30 flex items-center gap-1.5">
              <span className="text-slate-400">Recommended Action:</span>
              <span className="text-white font-bold">
                {action.action_type === 'STAGGER_LOADING' && `Stagger Loading Offset by +${action.action_parameters?.offset_mins || 15} mins`}
                {action.action_type === 'TRANSIT_BUFFER' && `Add +${action.action_parameters?.buffer_mins || 20} mins Transit Buffer`}
                {action.action_type === 'SLA_PRIORITIZE' && `Set Dispatch Priority to ${action.action_parameters?.priority_level || 'URGENT'}`}
                {action.action_type === 'INTRA_ZONE_REALLOCATE' && `Intra-Zone Reallocate to ${action.action_parameters?.target_plant_code || 'Adjacent Plant'} (+${action.action_parameters?.predicted_improvement_mins || 14.5}m Improvement)`}
                {!['STAGGER_LOADING', 'TRANSIT_BUFFER', 'SLA_PRIORITIZE', 'INTRA_ZONE_REALLOCATE'].includes(action.action_type) && action.action_type}
              </span>
            </div>
          </div>
          <div>{getStatusBadge(action.action_status)}</div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs mb-4 bg-slate-850 p-3 rounded-lg border border-slate-800">
          <div className="flex items-center gap-1.5 text-slate-300">
            <Building2 className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">Plant:</span>
            <span className="font-semibold text-white">{action.plant_code}</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">Customer:</span>
            <span className="font-semibold text-white truncate max-w-[120px]">{action.customer_code}</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <Truck className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">Model Family:</span>
            <span className="font-mono text-indigo-300">{action.model_family}</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <Info className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">Version:</span>
            <span className="font-mono text-slate-300 truncate max-w-[120px]">{action.model_version}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 p-3 bg-slate-950/70 rounded-lg border border-slate-800/80 mb-4">
          <div>
            <span className="text-[10px] font-semibold text-slate-400 block uppercase">Predicted Risk Exposure</span>
            <span className="text-sm font-bold text-amber-400">
              {action.predicted_risk_exposure_inr !== null && action.predicted_risk_exposure_inr !== undefined
                ? `₹${Math.round(action.predicted_risk_exposure_inr).toLocaleString('en-IN')}`
                : 'N/A (Operational Signal)'}
            </span>
          </div>
          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Est. Avoided Exposure</div>
            <div className="text-xs font-semibold text-slate-400 font-mono">
              {action.estimated_avoided_exposure_inr !== null && action.estimated_avoided_exposure_inr !== undefined
                ? `₹${action.estimated_avoided_exposure_inr.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`
                : 'Pending Post-Trip Audit'}
            </div>
          </div>
        </div>

        {action.dispatcher_notes && (
          <div className="text-xs bg-slate-800/40 p-2.5 rounded border border-slate-700/50 mb-4 text-slate-300 italic">
            "{action.dispatcher_notes}"
          </div>
        )}
      </div>

      <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => onViewAudit(action)}
          className="text-xs text-indigo-400 hover:text-indigo-200 font-bold flex items-center gap-1 py-1 cursor-pointer hover:underline"
        >
          <Info className="w-3.5 h-3.5" /> View Full Lineage
        </button>

        <div className="flex items-center gap-2">
          {action.action_status === 'PENDING' && (
            <>
              <button
                onClick={() => onReject(action)}
                className="px-2.5 py-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 text-xs font-semibold rounded-lg transition"
              >
                Reject
              </button>
              <button
                onClick={() => onDefer(action)}
                className="px-2.5 py-1.5 bg-purple-950/40 hover:bg-purple-900/60 text-purple-300 border border-purple-800/50 text-xs font-semibold rounded-lg transition"
              >
                Defer
              </button>
              <button
                onClick={() => onAccept(action)}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg shadow-md transition flex items-center gap-1"
              >
                <CheckCircle2 className="w-3.5 h-3.5" /> Accept Intent
              </button>
            </>
          )}

          {action.action_status === 'ACCEPTED' && (
            <button
              onClick={() => onStartProgress(action)}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg shadow-md transition flex items-center gap-1"
            >
              <Play className="w-3.5 h-3.5" /> Start Progress
            </button>
          )}

          {(action.action_status === 'ACCEPTED' || action.action_status === 'IN_PROGRESS') && (
            <button
              onClick={() => onConfirmExecution(action)}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-md transition flex items-center gap-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5" /> Confirm Execution
            </button>
          )}

          {action.action_status === 'EXECUTED' && (
            <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> Executed (Read-Only)
            </span>
          )}

          {action.action_status === 'REJECTED' && (
            <span className="text-xs font-semibold text-rose-400 flex items-center gap-1">
              <ShieldAlert className="w-3.5 h-3.5" /> Rejected (Read-Only)
            </span>
          )}

          {action.action_status === 'DEFERRED' && (
            <span className="text-xs font-semibold text-purple-400 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" /> Deferred (Read-Only)
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
