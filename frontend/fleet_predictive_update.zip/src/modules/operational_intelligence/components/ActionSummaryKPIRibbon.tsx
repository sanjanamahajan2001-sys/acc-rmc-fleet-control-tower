import React from 'react';
import { Activity, Clock, CheckCircle2, AlertTriangle, XCircle, DollarSign, RefreshCw } from 'lucide-react';
import { ActionLogItem } from '../api/actionExecutionApi';

interface ActionSummaryKPIRibbonProps {
  actions: ActionLogItem[];
  isLoading: boolean;
  onRefresh: () => void;
}

export const ActionSummaryKPIRibbon: React.FC<ActionSummaryKPIRibbonProps> = ({
  actions,
  isLoading,
  onRefresh,
}) => {
  const activeRecs = actions.length;
  const pendingCount = actions.filter((a) => a.action_status === 'PENDING').length;
  const acceptedCount = actions.filter((a) => a.action_status === 'ACCEPTED').length;
  const inProgressCount = actions.filter((a) => a.action_status === 'IN_PROGRESS').length;
  const executedCount = actions.filter((a) => a.action_status === 'EXECUTED').length;
  const deferredCount = actions.filter((a) => a.action_status === 'DEFERRED').length;
  const rejectedCount = actions.filter((a) => a.action_status === 'REJECTED').length;

  const totalEstimatedAvoidedExposure = actions.reduce((acc, a) => {
    return acc + (a.estimated_avoided_exposure_inr || 0);
  }, 0);

  const formatINR = (val: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-6 shadow-lg">
      <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-indigo-400" />
            Control Tower Action Summary & Financial Exposure Ribbon
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Operational ↔ Predictive Intelligence Dispatcher Action Authority
          </p>
        </div>
        <button
          onClick={onRefresh}
          disabled={isLoading}
          className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh Action Queue
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        <div className="bg-slate-800/60 border border-slate-700/50 rounded-lg p-3">
          <span className="text-[11px] font-semibold text-slate-400 block uppercase">Active Recommendations</span>
          <span className="text-lg font-bold text-white">{activeRecs}</span>
        </div>

        <div className="bg-amber-950/20 border border-amber-800/40 rounded-lg p-3">
          <span className="text-[11px] font-semibold text-amber-400 block uppercase flex items-center gap-1">
            <Clock className="w-3 h-3" /> Pending
          </span>
          <span className="text-lg font-bold text-amber-300">{pendingCount}</span>
        </div>

        <div className="bg-indigo-950/20 border border-indigo-800/40 rounded-lg p-3">
          <span className="text-[11px] font-semibold text-indigo-400 block uppercase flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Accepted
          </span>
          <span className="text-lg font-bold text-indigo-300">{acceptedCount}</span>
        </div>

        <div className="bg-blue-950/20 border border-blue-800/40 rounded-lg p-3">
          <span className="text-[11px] font-semibold text-blue-400 block uppercase flex items-center gap-1">
            <Activity className="w-3 h-3" /> In-Progress
          </span>
          <span className="text-lg font-bold text-blue-300">{inProgressCount}</span>
        </div>

        <div className="bg-emerald-950/20 border border-emerald-800/40 rounded-lg p-3">
          <span className="text-[11px] font-semibold text-emerald-400 block uppercase flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Executed Today
          </span>
          <span className="text-lg font-bold text-emerald-300">{executedCount}</span>
        </div>

        <div className="bg-purple-950/20 border border-purple-800/40 rounded-lg p-3">
          <span className="text-[11px] font-semibold text-purple-400 block uppercase flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" /> Deferred
          </span>
          <span className="text-lg font-bold text-purple-300">{deferredCount}</span>
        </div>

        <div className="bg-rose-950/20 border border-rose-800/40 rounded-lg p-3">
          <span className="text-[11px] font-semibold text-rose-400 block uppercase flex items-center gap-1">
            <XCircle className="w-3 h-3" /> Rejected
          </span>
          <span className="text-lg font-bold text-rose-300">{rejectedCount}</span>
        </div>

        <div className="bg-emerald-900/30 border border-emerald-700/50 rounded-lg p-3 col-span-2 md:col-span-1">
          <span className="text-[11px] font-semibold text-emerald-400 block uppercase flex items-center gap-1">
            <DollarSign className="w-3 h-3" /> Estimated Avoided Exposure
          </span>
          <span className="text-base font-bold text-emerald-300">{formatINR(totalEstimatedAvoidedExposure)}</span>
          <span className="text-[10px] text-slate-400 block mt-0.5">*Decision-time estimate</span>
        </div>
      </div>
    </div>
  );
};
