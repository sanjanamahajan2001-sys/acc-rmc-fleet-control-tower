import React from 'react';
import { Lightbulb, Zap, ExternalLink, Sparkles, Clock, AlertTriangle, ShieldAlert } from 'lucide-react';
import { KPICard } from '../../../components/common/KPICard';
import { useNavigate } from 'react-router-dom';

export interface DecisionSummaryCounts {
  active_recommendations: number;
  high_priority_issues: number;
  estimated_delay_reduction_mins: number;
  estimated_sla_recovery_pct: number;
  fleet_efficiency_opportunity_pct: number;
}

export interface RecommendationItem {
  recommendation_id: string;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  recommendation_text: string;
  underlying_reason: string;
  affected_plant: string;
  affected_vehicle?: string | null;
  expected_impact: string;
  confidence_pct: number;
  status: string;
}

export interface DecisionInsightItem {
  title: string;
  category: string;
  action_type: string;
  description: string;
  urgency: 'Immediate' | 'Scheduled' | 'Proactive';
}

export interface OperationalDecisionRecommendationData {
  summary: DecisionSummaryCounts;
  recommendations: RecommendationItem[];
  insights: DecisionInsightItem[];
  calculation_status: 'SUCCESS' | 'NO_RECORDS' | 'NOT_CONFIGURED' | 'ERROR';
  calculation_notes: string;
}

interface OperationalDecisionRecommendationsSectionProps {
  data: OperationalDecisionRecommendationData | null;
}

export const OperationalDecisionRecommendationsSection: React.FC<OperationalDecisionRecommendationsSectionProps> = ({ data }) => {
  const navigate = useNavigate();

  if (!data || !data.summary) return null;

  const { summary, recommendations, insights } = data;

  const getPriorityBadge = (prio: string) => {
    switch (prio) {
      case 'CRITICAL':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
            P1 CRITICAL
          </span>
        );
      case 'HIGH':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
            P2 HIGH
          </span>
        );
      case 'MEDIUM':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
            P3 MEDIUM
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-500/15 text-slate-400 border border-slate-500/30">
            P4 LOW
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Summary Ribbon: 5 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard
          title="Active Recommendations"
          value={summary.active_recommendations}
          change={summary.active_recommendations > 0 ? 'Engine Active' : 'Optimal'}
          changeType={summary.active_recommendations > 0 ? 'negative' : 'positive'}
          subtitle="RecommendationEngine Output"
        />
        <KPICard
          title="High-Priority SLA Breaches"
          value={summary.high_priority_issues}
          change={summary.high_priority_issues > 0 ? 'Action Needed' : 'Zero Breaches'}
          changeType={summary.high_priority_issues > 0 ? 'negative' : 'positive'}
          subtitle="Holding + Retention Breaches"
        />
        <KPICard
          title="Est. Delay Reduction"
          value={`${summary.estimated_delay_reduction_mins}m`}
          change="Calculated Impact"
          changeType="positive"
          subtitle="Queue Delay Savings"
        />
        <KPICard
          title="Est. SLA Recovery"
          value={`${summary.estimated_sla_recovery_pct}%`}
          change="SLA Target"
          changeType="positive"
          subtitle="Target On-Time Delivery"
        />
        <KPICard
          title="Fleet Efficiency Opportunity"
          value={`${summary.fleet_efficiency_opportunity_pct}%`}
          change="Asset Utilization"
          changeType="neutral"
          subtitle="Fleet Redistribution Potential"
        />
      </div>

      {/* 2. Priority Recommendation Queue */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Zap className="w-4 h-4 text-indigo-400" /> Priority Actionable Recommendation Queue
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Rule-assisted decision recommendations from RecommendationEngine authority</p>
          </div>
          <button
            onClick={() => navigate('/alerts')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-600/30 transition"
          >
            <span>View Affected Alerts</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-3">
          {recommendations.length === 0 ? (
            <div className="text-xs text-slate-500 italic py-6 text-center">Zero actionable recommendations — All dispatches operating within SLA targets</div>
          ) : (
            recommendations.map((rec) => (
              <div
                key={rec.recommendation_id}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5 hover:border-indigo-500/40 transition"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    {getPriorityBadge(rec.priority)}
                    <span className="text-xs font-mono font-bold text-slate-400">{rec.recommendation_id}</span>
                    <span className="text-xs font-bold text-slate-100">{rec.recommendation_text}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-mono shrink-0">
                    <span className="px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                      Conf: <strong>{rec.confidence_pct}%</strong>
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                      Impact: <strong>{rec.expected_impact}</strong>
                    </span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-slate-800/60 text-[11px] text-slate-400 font-mono">
                  <div className="flex items-center gap-3">
                    <span>Plant: <strong className="text-slate-200">{rec.affected_plant}</strong></span>
                    {rec.affected_vehicle && (
                      <>
                        <span>•</span>
                        <span>Vehicle: <strong className="text-indigo-300">{rec.affected_vehicle}</strong></span>
                      </>
                    )}
                    <span>•</span>
                    <span className="text-slate-400 italic">{rec.underlying_reason}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                    Status: {rec.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* 3. Authoritative Predictive ML Recommendations (Phase 6 Engine Output) */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 rounded-xl p-4 space-y-3 shadow-lg">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-100 uppercase tracking-wider flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" /> Authoritative Predictive ML Recommendations
          </h3>
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            PREDICTIVE INTELLIGENCE ACTIVE
          </span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* Staggered Loading Offset */}
          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <span className="font-semibold text-xs text-amber-200">Staggered Batch Loading Offset</span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                15-20 min offset
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Recommended: Stagger batch loading by 15–20 mins at assigned plant to prevent loading queue build-up and reduce holding penalty cost.
            </p>
            <div className="text-[10px] font-mono text-amber-400/80">
              Trigger Model: <span className="font-bold">turnaround_regressor (v1.1.0-promoted)</span>
            </div>
          </div>

          {/* Transit Lead-Time Buffer */}
          <div className="p-3.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-cyan-400" />
                <span className="font-semibold text-xs text-cyan-200">Transit Lead-Time Buffer</span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                Stage 15m Early
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Recommended: Stage truck 15 mins early during peak traffic hours to absorb transit delay and protect customer site SLA.
            </p>
            <div className="text-[10px] font-mono text-cyan-400/80">
              Trigger Model: <span className="font-bold">delay_regressor (v1.1.0-promoted)</span>
            </div>
          </div>

          {/* SLA Breach Prioritization */}
          <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <span className="font-semibold text-xs text-rose-200">High SLA Breach Prioritization</span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                Action Needed
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Recommended: Prioritize dispatch queue position for high-SLA risk deliveries to prevent site retention penalty losses.
            </p>
            <div className="text-[10px] font-mono text-rose-400/80">
              Trigger Model: <span className="font-bold">sla_breach_classifier (v1.1.0-promoted)</span>
            </div>
          </div>

          {/* Zone-Constrained Allocation */}
          <div className="p-3.5 rounded-xl bg-purple-500/10 border border-purple-500/30 space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <ShieldAlert className="w-4 h-4 text-purple-400" />
                <span className="font-semibold text-xs text-purple-200">Plant Zone Throughput Allocation</span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Zone Constraint
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Recommended: Re-allocate dispatch loading queue across plant operating zone boundaries to mitigate severe plant congestion.
            </p>
            <div className="text-[10px] font-mono text-purple-400/80">
              Trigger Model: <span className="font-bold">plant_risk_classifier (v1.1.0-promoted)</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Operational Advisory Cards */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <Lightbulb className="w-4 h-4 text-indigo-400" /> Operational Advisory & Optimization Cards
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {insights.map((card, idx) => (
            <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200">{card.title}</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  {card.urgency}
                </span>
              </div>
              <p className="text-xs text-slate-400">{card.description}</p>
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 pt-1">
                <span>Category: {card.category}</span>
                <span>Action: {card.action_type}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Lineage Provenance Footer */}
        <div className="pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-500">
          <span className="text-indigo-400 font-bold">PostgreSQL Lineage:</span> {data.calculation_notes}
        </div>
      </div>
    </div>
  );
};
