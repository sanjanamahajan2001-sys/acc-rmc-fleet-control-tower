import React, { useState, useEffect } from 'react';
import { IndianRupee, ShieldAlert, Cpu, Building, Users, ChevronLeft, ChevronRight } from 'lucide-react';
import { KPICard } from '../../../components/common/KPICard';

export interface CostExposureSummary {
  realized_cost_exposure_inr: number;
  predicted_cost_exposure_inr: number | null;
  holding_penalty_cost_inr: number;
  retention_sla_penalty_inr: number;
  idle_fuel_waste_inr: number;
  high_cost_operations_count: number;
}

export interface HighCostOperationItem {
  dispatch_id: string;
  dispatch_code: string;
  plant_code: string;
  customer_code: string;
  vehicle_code: string;
  holding_penalty_mins: number;
  retention_penalty_mins: number;
  total_exposure_inr: number;
  risk_level: string; // Critical, High, Moderate
}

export interface PaginatedHighCostOperations {
  items: HighCostOperationItem[];
  page: number;
  page_size: number;
  total_items: number;
  total_pages: number;
}

export interface PlantCostRiskItem {
  plant_code: string;
  plant_name: string;
  dispatches_count: number;
  total_exposure_inr: number;
  exposure_percentage: number;
}

export interface CustomerCostRiskItem {
  customer_code: string;
  customer_name: string;
  delivered_trips: number;
  total_exposure_inr: number;
  exposure_percentage: number;
}

export interface PredictionProvenance {
  is_model_configured: boolean;
  prediction_status: string; // AVAILABLE, NOT_CONFIGURED, ERROR
  model_name: string | null;
  model_version: string | null;
  prediction_snapshot_id: string | null;
  prediction_timestamp: string | null;
  confidence_score: number | null;
  notes: string;
}

export interface OperationalCostExposureData {
  summary: CostExposureSummary;
  high_cost_operations: PaginatedHighCostOperations;
  plant_cost_risk: PlantCostRiskItem[];
  customer_cost_risk: CustomerCostRiskItem[];
  provenance: PredictionProvenance;
  calculation_status: string; // SUCCESS, NO_RECORDS, ERROR
  prediction_status: string;  // AVAILABLE, NOT_CONFIGURED, ERROR
  calculation_notes: string;
}

interface OperationalCostExposureSectionProps {
  data: OperationalCostExposureData | null;
  onPageChange?: (page: number) => void;
}

export const OperationalCostExposureSection: React.FC<OperationalCostExposureSectionProps> = ({
  data,
  onPageChange,
}) => {
  const [custPage, setCustPage] = useState<number>(1);
  const CUSTOMER_PAGE_SIZE = 5;

  const customerCostRisk = data?.customer_cost_risk || [];

  useEffect(() => {
    setCustPage(1);
  }, [customerCostRisk.length]);

  if (!data || !data.summary) return null;

  const {
    summary,
    high_cost_operations,
    plant_cost_risk,
    provenance,
  } = data;

  const totalCustPages = Math.ceil(customerCostRisk.length / CUSTOMER_PAGE_SIZE);
  const currentCustPage = Math.min(custPage, totalCustPages || 1);
  const paginatedCustRisk = customerCostRisk.slice(
    (currentCustPage - 1) * CUSTOMER_PAGE_SIZE,
    currentCustPage * CUSTOMER_PAGE_SIZE
  );

  const formatINR = (val: number) => {
    return `₹${val.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
  };

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case 'Critical':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
            Critical
          </span>
        );
      case 'High':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
            High
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
            Moderate
          </span>
        );
    }
  };

  const isPredictionAvailable =
    provenance.prediction_status === 'AVAILABLE' &&
    summary.predicted_cost_exposure_inr !== null;

  return (
    <div className="space-y-6">
      {/* 1. Summary Ribbon: 4 Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          title="Realized Cost Exposure"
          value={formatINR(summary.realized_cost_exposure_inr)}
          change={summary.realized_cost_exposure_inr > 0 ? 'Risk Active' : 'Zero Loss'}
          changeType={summary.realized_cost_exposure_inr > 0 ? 'negative' : 'positive'}
          subtitle="Quantified Realized Delay Exposure"
        />
        <KPICard
          title="Predicted Cost Exposure"
          value={isPredictionAvailable ? formatINR(summary.predicted_cost_exposure_inr!) : 'NOT CONFIGURED'}
          change={isPredictionAvailable ? (provenance.model_version || 'Phase 6 Engine') : 'Phase 6 Engine'}
          changeType={isPredictionAvailable ? 'positive' : 'neutral'}
          subtitle="Trained ML Prediction Model"
        />
        <KPICard
          title="SLA Penalty Exposure"
          value={formatINR(summary.retention_sla_penalty_inr)}
          change="Rate: ₹35/min"
          changeType="negative"
          subtitle="Site Retention Penalty"
        />
        <KPICard
          title="High-Cost Operations"
          value={summary.high_cost_operations_count.toLocaleString()}
          change="Excess SLA Delays"
          changeType={summary.high_cost_operations_count > 0 ? 'negative' : 'positive'}
          subtitle="Dispatches Exceeding SLA Thresholds"
        />
      </div>

      {/* 2. Realized Cost Component Breakdown Ribbon */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <IndianRupee className="w-4 h-4 text-indigo-400" /> Realized Exposure Component Breakdown
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs font-mono">
            <div className="space-y-0.5">
              <span className="text-slate-400">Plant Holding Queue Loss</span>
              <div className="text-[10px] text-slate-500">Rate: ₹25/min (SLA: 20m)</div>
            </div>
            <span className="font-bold text-rose-400">{formatINR(summary.holding_penalty_cost_inr)}</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs font-mono">
            <div className="space-y-0.5">
              <span className="text-slate-400">Customer Site SLA Penalty</span>
              <div className="text-[10px] text-slate-500">Rate: ₹35/min (SLA: 10m)</div>
            </div>
            <span className="font-bold text-amber-400">{formatINR(summary.retention_sla_penalty_inr)}</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs font-mono">
            <div className="space-y-0.5">
              <span className="text-slate-400">Idle Fuel Waste</span>
              <div className="text-[10px] text-slate-500">Rate: ₹15/min (Holding)</div>
            </div>
            <span className="font-bold text-slate-300">{formatINR(summary.idle_fuel_waste_inr)}</span>
          </div>
        </div>
      </div>

      {/* 3. Paginated High-Cost Operations Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between pb-1">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" /> High-Cost Operations (SLA Exception Dispatches)
          </h3>
          <span className="text-[11px] font-mono text-slate-400">
            Total Matching: <strong>{high_cost_operations.total_items}</strong> Dispatches
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase text-[10px]">
              <tr>
                <th className="py-2.5 px-3">Dispatch</th>
                <th className="py-2.5 px-3">Plant</th>
                <th className="py-2.5 px-3">Customer</th>
                <th className="py-2.5 px-3">Vehicle</th>
                <th className="py-2.5 px-3 text-right">Holding Pen</th>
                <th className="py-2.5 px-3 text-right">Retention Pen</th>
                <th className="py-2.5 px-3 text-right">Total Exposure</th>
                <th className="py-2.5 px-3 text-center">Risk Level</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {high_cost_operations.items.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-6 text-center text-slate-500 italic">
                    Zero high-cost operation dispatches detected under the active filter context
                  </td>
                </tr>
              ) : (
                high_cost_operations.items.map((op) => (
                  <tr key={op.dispatch_id} className="hover:bg-slate-800/40 transition">
                    <td className="py-2.5 px-3 font-bold text-slate-100">{op.dispatch_code}</td>
                    <td className="py-2.5 px-3 text-slate-300">{op.plant_code}</td>
                    <td className="py-2.5 px-3 text-slate-300 truncate max-w-[150px]">{op.customer_code}</td>
                    <td className="py-2.5 px-3 text-slate-300">{op.vehicle_code}</td>
                    <td className="py-2.5 px-3 text-right text-rose-400">{op.holding_penalty_mins}m</td>
                    <td className="py-2.5 px-3 text-right text-amber-400">{op.retention_penalty_mins}m</td>
                    <td className="py-2.5 px-3 text-right font-bold text-slate-100">{formatINR(op.total_exposure_inr)}</td>
                    <td className="py-2.5 px-3 text-center">{getRiskBadge(op.risk_level)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Server-Side Pagination Controls */}
        {high_cost_operations.total_pages > 1 && (
          <div className="flex items-center justify-between pt-3 border-t border-slate-800/80 text-xs font-mono text-slate-400">
            <span>
              Page <strong>{high_cost_operations.page}</strong> of <strong>{high_cost_operations.total_pages}</strong>
            </span>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => onPageChange?.(high_cost_operations.page - 1)}
                disabled={high_cost_operations.page <= 1}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 flex items-center gap-1 transition"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>Prev</span>
              </button>
              <button
                onClick={() => onPageChange?.(high_cost_operations.page + 1)}
                disabled={high_cost_operations.page >= high_cost_operations.total_pages}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 flex items-center gap-1 transition"
              >
                <span>Next</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 4. Plant and Customer Cost Risk Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Plant Cost Risk Concentration */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Building className="w-4 h-4 text-indigo-400" /> Plant Cost Risk Concentration
          </h3>
          <div className="space-y-2">
            {plant_cost_risk.length === 0 ? (
              <div className="text-xs text-slate-500 italic py-4 text-center">Zero plant cost risk records</div>
            ) : (
              plant_cost_risk.map((p) => (
                <div key={p.plant_code} className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <div className="space-y-0.5">
                    <span className="font-semibold text-slate-200">{p.plant_name}</span>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Dispatches: <strong>{p.dispatches_count}</strong>
                    </div>
                  </div>
                  <div className="text-right font-mono">
                    <div className="font-bold text-rose-400">{formatINR(p.total_exposure_inr)}</div>
                    <div className="text-[11px] text-slate-400">Share: {p.exposure_percentage}%</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Customer Cost Risk Concentration */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-1">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Users className="w-4 h-4 text-indigo-400" /> Customer Cost Risk Concentration
              </h3>
              {customerCostRisk.length > 0 && (
                <span className="text-[11px] font-mono text-slate-400">
                  Total: <strong>{customerCostRisk.length}</strong> Customers
                </span>
              )}
            </div>

            <div className="space-y-2">
              {customerCostRisk.length === 0 ? (
                <div className="text-xs text-slate-500 italic py-4 text-center">Zero customer cost risk records</div>
              ) : (
                paginatedCustRisk.map((c) => (
                  <div key={c.customer_code} className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                    <div className="space-y-0.5">
                      <span className="font-semibold text-slate-200 truncate max-w-[200px]">{c.customer_name}</span>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Delivered Trips: <strong>{c.delivered_trips}</strong>
                      </div>
                    </div>
                    <div className="text-right font-mono">
                      <div className="font-bold text-amber-300">{formatINR(c.total_exposure_inr)}</div>
                      <div className="text-[11px] text-slate-400">Share: {c.exposure_percentage}%</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Customer Risk Pagination Controls */}
          {totalCustPages > 1 && (
            <div className="flex items-center justify-between pt-3 mt-2 border-t border-slate-800/80 text-xs font-mono text-slate-400">
              <span>
                Page <strong>{currentCustPage}</strong> of <strong>{totalCustPages}</strong>
              </span>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setCustPage((p) => Math.max(1, p - 1))}
                  disabled={currentCustPage <= 1}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 flex items-center gap-1 transition"
                >
                  <ChevronLeft className="w-3 h-3" />
                  <span>Prev</span>
                </button>
                <button
                  onClick={() => setCustPage((p) => Math.min(totalCustPages, p + 1))}
                  disabled={currentCustPage >= totalCustPages}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 flex items-center gap-1 transition"
                >
                  <span>Next</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 5. Model Prediction Provenance Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-400" /> Authoritative Production Inference Provenance
          </h3>
          <span
            className={`px-2.5 py-0.5 rounded text-[10px] font-bold border ${
              isPredictionAvailable
                ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                : 'bg-amber-500/15 text-amber-400 border-amber-500/30'
            }`}
          >
            {isPredictionAvailable ? 'PREDICTIVE INTELLIGENCE | AUTHORITATIVE' : `Status: ${provenance.prediction_status}`}
          </span>
        </div>
        <p className="text-xs font-mono text-slate-400 leading-relaxed">
          {provenance.notes}
        </p>
      </div>

      {/* 6. PostgreSQL Lineage Provenance Footer */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 text-[10px] font-mono text-slate-500">
        <span className="text-indigo-400 font-bold">PostgreSQL Lineage:</span> {data.calculation_notes}
      </div>
    </div>
  );
};
