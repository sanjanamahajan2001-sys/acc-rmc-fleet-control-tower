import React from 'react';
import { AlertTriangle, Clock, ShieldAlert, Truck } from 'lucide-react';
import { OperationalPredictionItem, ModelAuthorityItem } from '../pages/PredictiveIntelligencePage';

interface PredictiveRiskWidgetProps {
  prediction?: OperationalPredictionItem;
  snapshot?: OperationalPredictionItem;
  model?: ModelAuthorityItem;
  className?: string;
}

/**
 * PredictiveRiskWidget Component
 * Last-mile presentation layer rendering backend-authoritative ML predictions
 * and smart RMC recommendations.
 * 
 * Strictly renders backend-provided DTO payload values without client-side decision logic.
 */
export const PredictiveRiskWidget: React.FC<PredictiveRiskWidgetProps> = ({ prediction, snapshot, model, className = '' }) => {
  const target = prediction || snapshot || (model as any);
  if (!target) return null;

  const model_name = target.model_name;
  const model_version = target.model_version || (model as any)?.active_version || 'v1.1.0-promoted';
  const predicted_value = target.predicted_value;
  const financial_exposure_inr = target.financial_exposure_inr;
  const sla_penalty_risk_inr = target.sla_penalty_risk_inr;
  const prediction_outputs = target.prediction_outputs;

  // Render Staggered Loading Card (Plant Turnaround Regressor)
  if (model_name === 'turnaround_regressor') {
    const turnaroundMins = predicted_value ?? prediction_outputs?.predicted_avg_turnaround_mins ?? 0;
    const staggerMins = prediction_outputs?.recommended_stagger_mins ?? (turnaroundMins > 25 ? 15 : 0);
    return (
      <div className={`p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 space-y-2 ${className}`} data-testid="staggered-loading-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-amber-400" />
            <span className="font-semibold text-sm">Plant Turnaround Notice</span>
          </div>
          <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
            {turnaroundMins.toFixed(1)} mins est.
          </span>
        </div>
        <p className="text-xs text-slate-300">
          {staggerMins > 0
            ? `Recommended: Stagger batch loading by ${staggerMins} mins at assigned plant to prevent loading queue build-up.`
            : 'Plant turnaround within normal operating parameters.'}
        </p>
      </div>
    );
  }

  // Render Transit Lead-Time Buffer Card (Traffic Congestion Regressor)
  if (model_name === 'delay_regressor') {
    const delayMins = predicted_value ?? prediction_outputs?.predicted_delay_mins ?? 0;
    const bufferMins = prediction_outputs?.recommended_lead_time_buffer_mins ?? (delayMins > 15 ? 15 : 0);
    return (
      <div className={`p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 space-y-2 ${className}`} data-testid="transit-buffer-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Truck className="w-5 h-5 text-cyan-400" />
            <span className="font-semibold text-sm">Transit Lead-Time Buffer</span>
          </div>
          <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
            +{delayMins.toFixed(1)} mins delay
          </span>
        </div>
        <p className="text-xs text-slate-300">
          {bufferMins > 0
            ? `Recommended: Stage truck ${bufferMins} mins earlier for peak traffic lead-time buffering.`
            : 'Transit traffic conditions normal.'}
        </p>
      </div>
    );
  }

  // Render Priority SLA Risk Badge (SLA Breach Classifier)
  if (model_name === 'sla_breach_classifier') {
    const probability = predicted_value ?? prediction_outputs?.sla_breach_probability ?? 0;
    const penaltyInr = sla_penalty_risk_inr ?? financial_exposure_inr ?? prediction_outputs?.sla_penalty_risk_inr ?? 0;
    const isHighRisk = probability >= 0.5;
    return (
      <div className={`p-4 rounded-xl ${isHighRisk ? 'bg-rose-500/10 border-rose-500/30 text-rose-300' : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'} space-y-2 ${className}`} data-testid="sla-risk-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShieldAlert className={`w-5 h-5 ${isHighRisk ? 'text-rose-400' : 'text-emerald-400'}`} />
            <span className="font-semibold text-sm">SLA Breach Risk</span>
          </div>
          <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 border border-slate-700">
            {(probability * 100).toFixed(0)}% Breach Probability
          </span>
        </div>
        {penaltyInr > 0 && (
          <p className="text-xs font-semibold">
            Financial Exposure Risk: ₹{penaltyInr.toLocaleString('en-IN')}
          </p>
        )}
        <p className="text-xs text-slate-300">
          {isHighRisk
            ? 'Recommended: Elevate dispatch to top loading priority to prevent contractual penalty breach.'
            : 'Low SLA breach risk detected.'}
        </p>
      </div>
    );
  }

  // Render Plant Congestion Indicator (Plant Risk Classifier)
  if (model_name === 'plant_risk_classifier') {
    const rawClass = predicted_value ?? prediction_outputs?.multiclass_class ?? 0;
    const riskLevelMap: Record<number, { label: string; color: string }> = {
      0: { label: 'NORMAL', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
      1: { label: 'MODERATE', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
      2: { label: 'SEVERE', color: 'bg-rose-500/20 text-rose-300 border-rose-500/30' },
    };
    const riskInfo = riskLevelMap[rawClass] || riskLevelMap[0];
    return (
      <div className={`p-4 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-300 space-y-2 ${className}`} data-testid="plant-risk-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-purple-400" />
            <span className="font-semibold text-sm">Plant Throughput Congestion</span>
          </div>
          <span className={`text-xs font-mono px-2.5 py-0.5 rounded border ${riskInfo.color}`}>
            {riskInfo.label}
          </span>
        </div>
        <p className="text-xs text-slate-300">
          {rawClass > 0
            ? 'Recommended: Optimize batching queue and monitor mechanical throughput at plant.'
            : 'Plant operating at normal capacity.'}
        </p>
      </div>
    );
  }

  return (
    <div className={`p-3 rounded-lg bg-slate-800/60 border border-slate-700 text-slate-300 ${className}`}>
      <span className="text-xs font-mono">{model_name} ({model_version}): {predicted_value}</span>
    </div>
  );
};
