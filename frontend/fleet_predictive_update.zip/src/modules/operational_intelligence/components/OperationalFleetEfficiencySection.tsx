import React, { useState } from 'react';
import { Building, Users, ChevronLeft, ChevronRight } from 'lucide-react';
import { KPICard } from '../../../components/common/KPICard';

export interface FleetEfficiencySummaryCounts {
  overall_efficiency_index: number;
  fleet_utilization_pct: number;
  avg_turnaround_time_mins: number;
  avg_holding_time_mins: number;
  avg_retention_time_mins: number;
  turnaround_efficiency_pct: number;
  site_unloading_efficiency_pct: number;
}

export interface PlantEfficiencyItem {
  plant_code: string;
  plant_name: string;
  active_vehicles: number;
  total_dispatches: number;
  avg_holding_mins: number;
  turnaround_efficiency_pct: number;
  efficiency_grade: 'Good' | 'Needs Improvement' | 'Critical';
}

export interface CustomerEfficiencyItem {
  customer_code: string;
  customer_name: string;
  total_trips: number;
  avg_retention_mins: number;
  cei_score: number;
  efficiency_grade: 'Good' | 'Needs Improvement' | 'Critical';
}

export interface OperationalFleetEfficiencyData {
  summary: FleetEfficiencySummaryCounts;
  plant_efficiency: PlantEfficiencyItem[];
  customer_efficiency: CustomerEfficiencyItem[];
  calculation_status: 'SUCCESS' | 'NO_RECORDS' | 'NOT_CONFIGURED' | 'ERROR';
  calculation_notes: string;
}

interface OperationalFleetEfficiencySectionProps {
  data: OperationalFleetEfficiencyData | null;
}

export const OperationalFleetEfficiencySection: React.FC<OperationalFleetEfficiencySectionProps> = ({ data }) => {
  const [custPage, setCustPage] = useState<number>(1);
  const itemsPerPage = 5;

  if (!data || !data.summary) return null;

  const { summary, plant_efficiency, customer_efficiency } = data;

  const totalCustPages = Math.ceil(customer_efficiency.length / itemsPerPage) || 1;
  const currentCustItems = customer_efficiency.slice((custPage - 1) * itemsPerPage, custPage * itemsPerPage);

  const getGradeBadge = (grade: string) => {
    switch (grade) {
      case 'Good':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            Good
          </span>
        );
      case 'Needs Improvement':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
            Needs Improvement
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
            Critical
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Summary Ribbon: 5 Key KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard
          title="Overall Operational Index"
          value={`${summary.overall_efficiency_index}/100`}
          change={summary.overall_efficiency_index >= 70 ? 'Optimal Performance' : 'Action Needed'}
          changeType={summary.overall_efficiency_index >= 70 ? 'positive' : 'negative'}
          subtitle="Composite Operational Score"
        />
        <KPICard
          title="Fleet Utilization"
          value={`${summary.fleet_utilization_pct}%`}
          change="Asset Usage"
          changeType={summary.fleet_utilization_pct >= 80 ? 'positive' : 'neutral'}
          subtitle="Dispatch Active Fleet"
        />
        <KPICard
          title="Avg Trip Turnaround"
          value={`${summary.avg_turnaround_time_mins}m`}
          change="Cycle Time"
          changeType="neutral"
          subtitle="Complete Dispatch Cycle"
        />
        <KPICard
          title="Plant Turnaround Rating"
          value={`${summary.turnaround_efficiency_pct}%`}
          change="Queue Efficiency"
          changeType={summary.turnaround_efficiency_pct >= 70 ? 'positive' : 'negative'}
          subtitle="Avg Holding: 20m SLA Target"
        />
        <KPICard
          title="Site Unloading Rating"
          value={`${summary.site_unloading_efficiency_pct}%`}
          change="Site Efficiency"
          changeType={summary.site_unloading_efficiency_pct >= 70 ? 'positive' : 'negative'}
          subtitle="Avg Retention: 10m SLA Target"
        />
      </div>

      {/* 2. Middle Grid: Plant Turnaround Efficiency & Customer CEI Authority */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Plant Turnaround Efficiency Table */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Building className="w-4 h-4 text-indigo-400" /> Plant Turnaround & Queue Efficiency
          </h3>
          <div className="space-y-2">
            {plant_efficiency.length === 0 ? (
              <div className="text-xs text-slate-500 italic py-4 text-center">Zero plant dispatch activity</div>
            ) : (
              plant_efficiency.map((p) => (
                <div key={p.plant_code} className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-200">{p.plant_name}</span>
                      {getGradeBadge(p.efficiency_grade)}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Active TMs: <strong>{p.active_vehicles}</strong> • Dispatches: <strong>{p.total_dispatches}</strong>
                    </div>
                  </div>
                  <div className="text-right font-mono">
                    <div className="font-bold text-slate-100">{p.turnaround_efficiency_pct}%</div>
                    <div className="text-[11px] text-slate-400">Avg Queue: {p.avg_holding_mins}m</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Customer Efficiency Index (CEI Authority) with Pagination */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-1">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Users className="w-4 h-4 text-indigo-400" /> Customer Efficiency Index (CEI Authority)
              </h3>
              <span className="text-[11px] font-mono text-slate-400">
                {customer_efficiency.length} Customers Total
              </span>
            </div>

            <div className="space-y-2 mt-3">
              {customer_efficiency.length === 0 ? (
                <div className="text-xs text-slate-500 italic py-4 text-center">Zero customer delivery records</div>
              ) : (
                currentCustItems.map((c) => (
                  <div key={c.customer_code} className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-200 truncate max-w-[200px]">{c.customer_name}</span>
                        {getGradeBadge(c.efficiency_grade)}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Delivered Trips: <strong>{c.total_trips}</strong>
                      </div>
                    </div>
                    <div className="text-right font-mono">
                      <div className="font-bold text-indigo-300">CEI: {c.cei_score}/100</div>
                      <div className="text-[11px] text-slate-400">Avg Retention: {c.avg_retention_mins}m</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Pagination Controls */}
          {customer_efficiency.length > itemsPerPage && (
            <div className="flex items-center justify-between pt-3 border-t border-slate-800/80 text-xs font-mono text-slate-400">
              <span>
                Page <strong>{custPage}</strong> of <strong>{totalCustPages}</strong>
              </span>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setCustPage((prev) => Math.max(1, prev - 1))}
                  disabled={custPage === 1}
                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 flex items-center gap-1 transition"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Prev</span>
                </button>
                <button
                  onClick={() => setCustPage((prev) => Math.min(totalCustPages, prev + 1))}
                  disabled={custPage === totalCustPages}
                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 flex items-center gap-1 transition"
                >
                  <span>Next</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Lineage Provenance Footer */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 text-[10px] font-mono text-slate-500">
        <span className="text-indigo-400 font-bold">PostgreSQL Lineage:</span> {data.calculation_notes}
      </div>
    </div>
  );
};
