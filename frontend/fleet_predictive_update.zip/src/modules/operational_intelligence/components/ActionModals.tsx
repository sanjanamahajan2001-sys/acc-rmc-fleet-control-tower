import React, { useState } from 'react';
import { X, CheckCircle2, AlertTriangle, ShieldAlert, FileText } from 'lucide-react';
import { ActionLogItem } from '../api/actionExecutionApi';

interface ModalProps {
  action: ActionLogItem | null;
  isOpen: boolean;
  onClose: () => void;
}

interface AcceptModalProps extends ModalProps {
  onConfirm: (notes: string, role: 'DISPATCHER' | 'SUPERVISOR' | 'ADMIN') => void;
  isSubmitting: boolean;
}

export const AcceptActionModal: React.FC<AcceptModalProps> = ({
  action,
  isOpen,
  onClose,
  onConfirm,
  isSubmitting,
}) => {
  const [notes, setNotes] = useState('');
  const [role, setRole] = useState<'DISPATCHER' | 'SUPERVISOR' | 'ADMIN'>('DISPATCHER');

  if (!isOpen || !action) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-lg w-full p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-indigo-400" />
            Approve Operational Recommendation Intent
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-xs mb-5">
          <div className="bg-indigo-950/30 border border-indigo-800/40 p-3 rounded-lg text-indigo-200">
            <strong>State Transition:</strong> PENDING ➔ ACCEPTED (Intent Approved).
            <p className="mt-1 text-slate-300">
              Approving intent confirms your plan to perform the operational action. It does NOT mark physical completion.
            </p>
          </div>

          <div className="bg-slate-800/60 p-3 rounded-lg space-y-1.5 font-mono text-slate-300">
            <div><span className="text-slate-400">Action ID:</span> {action.action_id}</div>
            <div><span className="text-slate-400">Dispatch ID:</span> {action.dispatch_code || action.dispatch_id}</div>
            <div><span className="text-slate-400">Plant Code:</span> {action.plant_code}</div>
            <div><span className="text-slate-400">Predicted Risk:</span> ₹{action.predicted_risk_exposure_inr}</div>
            <div><span className="text-slate-400">Est. Avoided Exposure:</span> ₹{action.estimated_avoided_exposure_inr || (action.predicted_risk_exposure_inr ? action.predicted_risk_exposure_inr * 0.85 : 0)}</div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Dispatcher Role:</label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as any)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white font-semibold"
            >
              <option value="DISPATCHER">DISPATCHER — Standard Operations</option>
              <option value="SUPERVISOR">SUPERVISOR — Operational Supervisor Override</option>
              <option value="ADMIN">ADMIN — Executive Administrator</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Dispatcher Notes (Optional):</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add operational context, truck driver instructions, or plant notes..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white h-20"
            />
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
          <button onClick={onClose} disabled={isSubmitting} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg">
            Cancel
          </button>
          <button
            onClick={() => onConfirm(notes, role)}
            disabled={isSubmitting}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-md"
          >
            {isSubmitting ? 'Approving...' : 'Confirm Intent Approval'}
          </button>
        </div>
      </div>
    </div>
  );
};

interface ConfirmExecutionModalProps extends ModalProps {
  onConfirm: (notes: string, role: 'DISPATCHER' | 'SUPERVISOR' | 'ADMIN') => void;
  isSubmitting: boolean;
}

export const ConfirmExecutionModal: React.FC<ConfirmExecutionModalProps> = ({
  action,
  isOpen,
  onClose,
  onConfirm,
  isSubmitting,
}) => {
  const [notes, setNotes] = useState('');
  const [role, setRole] = useState<'DISPATCHER' | 'SUPERVISOR' | 'ADMIN'>('DISPATCHER');

  if (!isOpen || !action) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-lg w-full p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            Explicit Physical Execution Confirmation
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-xs mb-5">
          <div className="bg-emerald-950/30 border border-emerald-800/40 p-3 rounded-lg text-emerald-200">
            <strong>Explicit Human Confirmation Required:</strong>
            <p className="mt-1 text-slate-300">
              Confirm that you physically verified or executed this operational offset at the plant/truck level. Zero automatic ERP write-back is performed.
            </p>
          </div>

          <div className="bg-slate-800/60 p-3 rounded-lg space-y-1.5 font-mono text-slate-300">
            <div><span className="text-slate-400">Action ID:</span> {action.action_id}</div>
            <div><span className="text-slate-400">Current Status:</span> {action.action_status}</div>
            <div><span className="text-slate-400">Target State:</span> EXECUTED</div>
            <div><span className="text-slate-400">Plant Code:</span> {action.plant_code}</div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Dispatcher Role:</label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as any)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white font-semibold"
            >
              <option value="DISPATCHER">DISPATCHER — Standard Operations</option>
              <option value="SUPERVISOR">SUPERVISOR — Operational Supervisor Override</option>
              <option value="ADMIN">ADMIN — Executive Administrator</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Execution Verification Notes:</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Verified truck gate arrival offset at plant bay 2..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white h-20"
            />
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
          <button onClick={onClose} disabled={isSubmitting} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg">
            Cancel
          </button>
          <button
            onClick={() => onConfirm(notes, role)}
            disabled={isSubmitting}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-md"
          >
            {isSubmitting ? 'Confirming...' : 'Confirm Physical Execution'}
          </button>
        </div>
      </div>
    </div>
  );
};

interface RejectDeferModalProps extends ModalProps {
  mode: 'REJECT' | 'DEFER';
  onConfirm: (reasonCode: string, notes: string, retryAt?: string) => void;
  isSubmitting: boolean;
}

export const RejectDeferModal: React.FC<RejectDeferModalProps> = ({
  action,
  isOpen,
  mode,
  onClose,
  onConfirm,
  isSubmitting,
}) => {
  const [reasonCode, setReasonCode] = useState('SITE_ACCESS_RESTRICTION');
  const [notes, setNotes] = useState('');
  const [retryAt, setRetryAt] = useState('');

  if (!isOpen || !action) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-lg w-full p-6 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            {mode === 'REJECT' ? <ShieldAlert className="w-5 h-5 text-rose-400" /> : <AlertTriangle className="w-5 h-5 text-purple-400" />}
            {mode === 'REJECT' ? 'Reject Recommendation' : 'Defer Action Recommendation'}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-xs mb-5">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Authoritative Reason Code:</label>
            <select
              value={reasonCode}
              onChange={(e) => setReasonCode(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white font-semibold"
            >
              <option value="SITE_ACCESS_RESTRICTION">SITE_ACCESS_RESTRICTION — Customer site unavailable</option>
              <option value="MIXER_CAPACITY_LIMIT">MIXER_CAPACITY_LIMIT — Plant batch capacity full</option>
              <option value="TRAFFIC_ROAD_BLOCKAGE">TRAFFIC_ROAD_BLOCKAGE — Transit corridor congestion</option>
              <option value="WEATHER_DISRUPTION">WEATHER_DISRUPTION — Heavy rainfall or site mudding</option>
              <option value="SUPERVISOR_OVERRIDE">SUPERVISOR_OVERRIDE — Operational priority shift</option>
            </select>
          </div>

          {mode === 'DEFER' && (
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Retry Timestamp (Optional):</label>
              <input
                type="datetime-local"
                value={retryAt}
                onChange={(e) => setRetryAt(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
              />
            </div>
          )}

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Dispatcher Audit Notes:</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Required operational justification for audit lineage..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white h-20"
            />
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
          <button onClick={onClose} disabled={isSubmitting} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg">
            Cancel
          </button>
          <button
            onClick={() => onConfirm(reasonCode, notes, retryAt)}
            disabled={isSubmitting}
            className={`px-4 py-2 ${mode === 'REJECT' ? 'bg-rose-600 hover:bg-rose-500' : 'bg-purple-600 hover:bg-purple-500'} text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-md`}
          >
            {isSubmitting ? 'Submitting...' : mode === 'REJECT' ? 'Confirm Rejection' : 'Confirm Deferral'}
          </button>
        </div>
      </div>
    </div>
  );
};

export const ActionAuditModal: React.FC<ModalProps> = ({ action, isOpen, onClose }) => {
  if (!isOpen || !action) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-2xl w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto z-[10000]">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-400" />
            End-to-End Decision & Lineage Traceability Audit
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs font-mono text-slate-300">
          <div className="bg-slate-800/60 p-4 rounded-lg space-y-2 border border-slate-700/60">
            <div className="text-indigo-400 font-bold uppercase text-[11px] mb-1">1. Action & Recommendation Identity</div>
            <div><span className="text-slate-400">Action ID:</span> {action.action_id}</div>
            <div><span className="text-slate-400">Recommendation ID:</span> {action.recommendation_id}</div>
            <div><span className="text-slate-400">Dispatch ID:</span> {action.dispatch_code || action.dispatch_id}</div>
            <div><span className="text-slate-400">Plant Code:</span> {action.plant_code}</div>
            <div><span className="text-slate-400">Customer Code:</span> {action.customer_code}</div>
            <div><span className="text-slate-400">Action Type:</span> {action.action_type}</div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-lg space-y-2 border border-slate-700/60">
            <div className="text-indigo-400 font-bold uppercase text-[11px] mb-1">2. Phase 6 Prediction Lineage</div>
            <div><span className="text-slate-400">Snapshot ID:</span> {action.prediction_snapshot_id}</div>
            <div><span className="text-slate-400">Model Family:</span> {action.model_family}</div>
            <div><span className="text-slate-400">Model Version:</span> {action.model_version}</div>
            <div><span className="text-slate-400">Dataset ID:</span> {action.dataset_id || 'DS-20260805-001'}</div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-lg space-y-2 border border-slate-700/60">
            <div className="text-indigo-400 font-bold uppercase text-[11px] mb-1">3. Financial Lineage Governance</div>
            <div><span className="text-slate-400">Governed Rate Lineage:</span> RATE_SPECIFICATION_GLOBAL_V1 (₹25/min)</div>
            <div><span className="text-slate-400">Predicted Risk Exposure:</span> ₹{action.predicted_risk_exposure_inr}</div>
            <div><span className="text-slate-400">Estimated Avoided Exposure:</span> ₹{action.estimated_avoided_exposure_inr}</div>
            <div><span className="text-slate-400">Actual Avoided Loss (Post-Trip):</span> {action.actual_avoided_loss_inr !== null ? `₹${action.actual_avoided_loss_inr}` : 'NULL (Pending Outcome Reconciliation)'}</div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-lg space-y-2 border border-slate-700/60">
            <div className="text-indigo-400 font-bold uppercase text-[11px] mb-1">4. Dispatcher Audit & State Audit</div>
            <div><span className="text-slate-400">Current Status:</span> {action.action_status}</div>
            <div><span className="text-slate-400">Dispatcher ID:</span> {action.dispatcher_id || 'N/A'}</div>
            <div><span className="text-slate-400">Dispatcher Role:</span> {action.dispatcher_role || 'N/A'}</div>
            <div><span className="text-slate-400">Accepted Timestamp:</span> {action.accepted_at || 'N/A'}</div>
            <div><span className="text-slate-400">Started Timestamp:</span> {action.started_at || 'N/A'}</div>
            <div><span className="text-slate-400">Execution Confirmed:</span> {action.execution_confirmed_at || 'N/A'}</div>
            <div><span className="text-slate-400">Idempotency Key:</span> {action.idempotency_key}</div>
            <div><span className="text-slate-400">Version Lock:</span> {action.version_lock}</div>
          </div>
        </div>

        <div className="flex items-center justify-end pt-4 border-t border-slate-800 mt-4">
          <button onClick={onClose} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg">
            Close Lineage Trace
          </button>
        </div>
      </div>
    </div>
  );
};
