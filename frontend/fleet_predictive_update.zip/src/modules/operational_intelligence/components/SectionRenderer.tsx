import React from 'react';
import { RefreshCw, AlertCircle, Info, Lock } from 'lucide-react';
import { OperationalIntelligenceSectionConfig } from '../registry/sectionRegistry';

interface SectionRendererProps {
  config: OperationalIntelligenceSectionConfig;
  loading?: boolean;
  error?: string | null;
  calculationStatus?: 'SUCCESS' | 'NO_RECORDS' | 'NOT_CONFIGURED' | 'ERROR';
  calculationNotes?: string;
  onRetry?: () => void;
  children?: React.ReactNode;
}

export const SectionRenderer: React.FC<SectionRendererProps> = ({
  config,
  loading = false,
  error = null,
  calculationStatus = 'SUCCESS',
  calculationNotes,
  onRetry,
  children,
}) => {
  if (!config.enabled) {
    return null; // Disabled sections are hidden cleanly from UI
  }

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
      {/* Section Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <span>{config.title}</span>
            <span className="text-[10px] font-mono font-semibold text-slate-500 uppercase px-2 py-0.5 rounded bg-slate-950 border border-slate-800">
              {config.id}
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">{config.description}</p>
        </div>

        {onRetry && (
          <button
            onClick={onRetry}
            disabled={loading}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-slate-300 hover:text-slate-100 text-xs font-semibold flex items-center gap-1.5 transition disabled:opacity-50"
            title="Refresh Section Data"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-indigo-400' : ''}`} />
            <span className="hidden sm:inline">Refresh</span>
          </button>
        )}
      </div>

      {/* State 1: Loading State */}
      {loading && (
        <div className="p-8 rounded-xl bg-slate-950/60 border border-slate-800 animate-pulse flex items-center justify-center gap-3 text-slate-400 text-xs font-semibold">
          <RefreshCw className="w-4 h-4 animate-spin text-indigo-400" />
          <span>Synchronizing Authoritative PostgreSQL Section Data...</span>
        </div>
      )}

      {/* State 2: Error State */}
      {!loading && (error || calculationStatus === 'ERROR') && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-between text-rose-300 text-xs">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{error || calculationNotes || 'Unable to calculate section metrics from database authority.'}</span>
          </div>
          {onRetry && (
            <button
              onClick={onRetry}
              className="px-3 py-1 bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 rounded-lg text-rose-200 font-semibold transition"
            >
              Retry
            </button>
          )}
        </div>
      )}

      {/* State 3: Not Configured / Unavailable State */}
      {!loading && !error && calculationStatus === 'NOT_CONFIGURED' && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2 text-amber-300 text-xs">
          <Lock className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{calculationNotes || 'Not Configured / Unavailable — Required configuration rate or database parameters missing.'}</span>
        </div>
      )}

      {/* State 4: No Records State */}
      {!loading && !error && calculationStatus === 'NO_RECORDS' && (
        <div className="p-6 rounded-xl bg-slate-950/40 border border-slate-800 text-center space-y-1 text-slate-400 text-xs">
          <div className="flex justify-center text-slate-500">
            <Info className="w-5 h-5" />
          </div>
          <p className="font-semibold text-slate-300">0 / No Operational Activity</p>
          <p className="text-[11px] text-slate-500">{calculationNotes || 'No canonical records match the current filter context.'}</p>
        </div>
      )}

      {/* State 5: Success State */}
      {!loading && !error && (calculationStatus === 'SUCCESS' || calculationStatus === undefined) && (
        <div>{children}</div>
      )}
    </div>
  );
};
