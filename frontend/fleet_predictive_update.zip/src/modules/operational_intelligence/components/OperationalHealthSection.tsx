import React from 'react';
import { CheckCircle2, AlertTriangle, XCircle, HelpCircle, ShieldCheck } from 'lucide-react';
import { KPICard } from '../../../components/common/KPICard';

export interface HealthMetric {
  key: string;
  label: string;
  current_value: number;
  unit: string;
  status: string;
  target?: number;
  threshold?: number;
  variance?: number;
  provenance_table: string;
  provenance_formula: string;
}

export interface DatasetFreshness {
  dataset_id: string;
  operational_date: string;
  import_timestamp: string;
  dataset_status: string;
  total_dispatches: number;
  total_trips: number;
}

export interface OperationalHealthData {
  overall_health_score?: number | null;
  health_status: 'HEALTHY' | 'DEGRADED' | 'CRITICAL' | 'UNAVAILABLE';
  freshness: DatasetFreshness;
  metrics: HealthMetric[];
  calculation_status: 'SUCCESS' | 'NO_RECORDS' | 'NOT_CONFIGURED' | 'ERROR';
  calculation_notes: string;
}

interface OperationalHealthSectionProps {
  data: OperationalHealthData | null;
}

export const OperationalHealthSection: React.FC<OperationalHealthSectionProps> = ({ data }) => {
  if (!data || !data.metrics) return null;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'HEALTHY':
      case 'OPTIMAL':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5" /> HEALTHY
          </span>
        );
      case 'DEGRADED':
      case 'WARNING':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
            <AlertTriangle className="w-3.5 h-3.5" /> DEGRADED
          </span>
        );
      case 'CRITICAL':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
            <XCircle className="w-3.5 h-3.5" /> CRITICAL
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-800 text-slate-400 border border-slate-700">
            <HelpCircle className="w-3.5 h-3.5" /> UNAVAILABLE
          </span>
        );
    }
  };

  const getChangeType = (status: string): 'positive' | 'negative' | 'neutral' => {
    if (status === 'OPTIMAL' || status === 'HEALTHY') return 'positive';
    if (status === 'CRITICAL' || status === 'WARNING' || status === 'DEGRADED') return 'negative';
    return 'neutral';
  };

  return (
    <div className="space-y-5">
      {/* Top Banner: Overall Health Score Index */}
      <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-2xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Overall Operational Health Index</span>
              {getStatusBadge(data.health_status)}
            </div>
            <div className="text-2xl font-extrabold text-slate-100 mt-0.5">
              {data.overall_health_score !== undefined && data.overall_health_score !== null
                ? `${data.overall_health_score}%`
                : 'N/A'}
              <span className="text-xs font-normal text-slate-400 ml-2">Primary SLA Score (Dispatch Accuracy)</span>
            </div>
          </div>
        </div>

        {/* Calculation Lineage Summary Note */}
        <div className="text-xs text-slate-400 bg-slate-900/90 px-3.5 py-2 rounded-lg border border-slate-800 max-w-md font-mono">
          <span className="text-slate-300 font-semibold">PostgreSQL Lineage:</span> {data.calculation_notes}
        </div>
      </div>

      {/* Grid of Health KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {data.metrics.map((m) => (
          <div key={m.key} className="flex flex-col h-full">
            <KPICard
              title={m.label}
              value={`${m.current_value} ${m.unit}`}
              change={m.status}
              changeType={getChangeType(m.status)}
              subtitle={m.target !== undefined ? `Target: ${m.target} ${m.unit}` : undefined}
            />
            {/* Provenance Lineage Tooltip / Footer */}
            <div className="mt-1.5 px-2 py-1 rounded bg-slate-950/60 border border-slate-800/80 text-[10px] font-mono text-slate-500 truncate" title={`PostgreSQL: ${m.provenance_table} | Formula: ${m.provenance_formula}`}>
              <span className="text-indigo-400/80 font-bold">SQL:</span> {m.provenance_table}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
