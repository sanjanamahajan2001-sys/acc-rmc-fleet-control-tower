import React, { useEffect, useState, useCallback } from 'react';
import { Brain, ShieldAlert, CheckCircle2, History, Lock, AlertTriangle, AlertCircle, Eye, X, ArrowUpRight, Coins } from 'lucide-react';
import { DashboardFilterProvider, useDashboardFilters } from '../../site_dashboard/orchestration/DashboardFilterProvider';
import { DashboardSyncProvider } from '../../site_dashboard/orchestration/DashboardSyncProvider';
import { GlobalDashboardFilterBar } from '../../site_dashboard/components/GlobalDashboardFilterBar';
import { SyncStatusHeaderBadge } from '../../site_dashboard/components/SyncStatusHeaderBadge';

export interface ModelAuthorityItem {
  model_name: string;
  target_name: string;
  model_category: string;
  prediction_authority: 'NOT_CONFIGURED' | 'AUTHORITATIVE';
  active_version: string | null;
  artifact_sha256: string | null;
  feature_set_version: string;
  last_promoted_at: string | null;
}

export interface PredictiveAuthorityOverview {
  overall_authority_status: 'NOT_CONFIGURED' | 'AUTHORITATIVE';
  total_model_families: number;
  promoted_model_count: number;
  rejected_model_count: number;
  models: ModelAuthorityItem[];
  calculation_status: string;
  calculation_notes: string;
}

export interface OperationalPredictionItem {
  id: string;
  prediction_snapshot_id: string;
  idempotency_key: string;
  prediction_timestamp: string;
  prediction_status: string;
  model_name: string;
  model_version: string;
  artifact_sha256: string;
  feature_set_version: string;
  dispatch_id: string;
  dispatch_code: string;
  plant_code: string | null;
  plant_name: string | null;
  customer_code: string | null;
  customer_name: string | null;
  vehicle_code: string | null;
  target_name: string;
  predicted_value: number | null;
  confidence_score: number | null;
  input_features: Record<string, any>;
  prediction_outputs: Record<string, any>;
  lineage_metadata?: Record<string, any> | null;
  financial_exposure_inr?: number | null;
  sla_penalty_risk_inr?: number | null;
  plant_congestion_risk_inr?: number | null;
  idle_queue_cost_inr?: number | null;
  total_financial_risk_inr?: number | null;
  currency?: string;
  calculation_lineage?: Record<string, any> | null;
}

export interface OperationalPrioritization {
  top_delayed_dispatches: OperationalPredictionItem[];
  high_sla_risk_dispatches: OperationalPredictionItem[];
  high_plant_risk_dispatches: OperationalPredictionItem[];
}

export interface OperationalPredictiveOverview {
  overall_authority_status: string;
  promoted_model_count: number;
  total_snapshots_found: number;
  prioritization: OperationalPrioritization;
  snapshots: OperationalPredictionItem[];
  calculation_status: string;
  calculation_notes: string;
}

export const PredictiveIntelligencePageContent: React.FC = () => {
  const { filters } = useDashboardFilters();

  const [authorityOverview, setAuthorityOverview] = useState<PredictiveAuthorityOverview | null>(null);
  const [authorityLoading, setAuthorityLoading] = useState<boolean>(true);
  const [authorityError, setAuthorityError] = useState<string | null>(null);

  const [operationalData, setOperationalData] = useState<OperationalPredictiveOverview | null>(null);
  const [operationalLoading, setOperationalLoading] = useState<boolean>(true);
  const [operationalError, setOperationalError] = useState<string | null>(null);

  const [selectedSnapshot, setSelectedSnapshot] = useState<OperationalPredictionItem | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generateProgress, setGenerateProgress] = useState<string | null>(null);

  const handleGenerateIntelligence = async () => {
    setIsGenerating(true);
    setGenerateProgress('Evaluating SLA breaches, ML predictions & generating recommendations...');
    try {
      const res = await fetch('/fleet-api/v1/operational-intelligence/actions/generate', { method: 'POST' });
      const body = await res.json();
      if (!res.ok) throw new Error(body.message || 'Generation failed');
      setGenerateProgress('Syncing predictive snapshots...');
      await fetchAuthorityOverview();
      await fetchOperationalData();
    } catch (err: any) {
      alert(`Generation Failed: ${err.message}`);
    } finally {
      setIsGenerating(false);
      setGenerateProgress(null);
    }
  };

  const fetchAuthorityOverview = useCallback(async () => {
    setAuthorityLoading(true);
    setAuthorityError(null);
    try {
      const res = await fetch('/fleet-api/v1/operational-intelligence/predictive/telemetry');
      const body = await res.json();
      if (!res.ok || !body.success) {
        throw new Error(body.message || (body.error && body.error.message) || 'Unable to fetch predictive telemetry overview');
      }
      const data = body.data;
      // Adapt WS6.4 GET /telemetry payload if present
      if (data && data.production_authority !== undefined) {
        const families = ['delay_regressor', 'turnaround_regressor', 'sla_breach_classifier', 'plant_risk_classifier'];
        const models = families.map((name) => {
          const status = (data.authority_status || {})[name];
          const isAuth = Boolean(status && (status.status === 'PROMOTED' || status.status === 'AUTHORITATIVE' || status.is_active === true || status.version || status.model_version));
          return {
            model_name: name,
            target_name: name === 'delay_regressor' ? 'predicted_delay_mins' : name === 'turnaround_regressor' ? 'predicted_avg_turnaround_mins' : name === 'sla_breach_classifier' ? 'predicted_sla_breach_target' : 'predicted_plant_congestion_target',
            model_category: name.includes('regressor') ? 'Regression' : 'Classification',
            prediction_authority: (isAuth ? 'AUTHORITATIVE' : 'NOT_CONFIGURED') as any,
            active_version: status ? (status.model_version || status.version || status.active_version || 'v1.1.0-promoted') : null,
            artifact_sha256: status ? (status.artifact_sha256 || null) : null,
            feature_set_version: 'FeatureSetV1',
            last_promoted_at: status ? (status.promoted_at || status.training_timestamp || status.last_promoted_at || null) : null,
          };
        });
        setAuthorityOverview({
          overall_authority_status: data.production_authority === 'AUTHORITATIVE' ? 'AUTHORITATIVE' : 'NOT_CONFIGURED',
          total_model_families: 4,
          promoted_model_count: data.authoritative_model_count || 0,
          rejected_model_count: 4 - (data.authoritative_model_count || 0),
          models,
          calculation_status: data.production_authority,
          calculation_notes: `Telemetry Authority: ${data.production_authority}. Active Snapshots: ${data.snapshot_metrics?.active_snapshots ?? 0}.`,
        });
      } else {
        setAuthorityOverview(data);
      }
    } catch (err: any) {
      setAuthorityError(err.message || 'Error fetching predictive authority overview');
    } finally {
      setAuthorityLoading(false);
    }
  }, []);

  const fetchOperationalData = useCallback(async () => {
    setOperationalLoading(true);
    setOperationalError(null);
    try {
      const qs = new URLSearchParams({
        plant_id: filters.plant_id,
        customer_id: filters.customer_id,
        dataset_type: filters.dataset_type,
        ...(filters.operation_date ? { operation_date: filters.operation_date } : {}),
        ...(filters.dataset_id ? { dataset_id: filters.dataset_id } : {}),
      }).toString();

      const res = await fetch(`/fleet-api/v1/operational-intelligence/predictive/operational-overview?${qs}`);
      const body = await res.json();
      if (!res.ok || !body.success) {
        throw new Error(body.message || 'Unable to fetch operational predictive overview');
      }
      setOperationalData(body.data);
    } catch (err: any) {
      setOperationalError(err.message || 'Error fetching operational predictive data');
    } finally {
      setOperationalLoading(false);
    }
  }, [filters.plant_id, filters.customer_id, filters.dataset_type, filters.operation_date, filters.dataset_id]);

  const masterRefresh = useCallback(() => {
    fetchAuthorityOverview();
    fetchOperationalData();
  }, [fetchAuthorityOverview, fetchOperationalData]);

  useEffect(() => {
    masterRefresh();
  }, [masterRefresh]);

  const isNotConfigured =
    (authorityOverview?.overall_authority_status || operationalData?.overall_authority_status || 'NOT_CONFIGURED') === 'NOT_CONFIGURED';
  const snapshots = operationalData?.snapshots || [];

  return (
    <DashboardSyncProvider onRefreshNeeded={masterRefresh}>
      <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-5 space-y-6">
        {/* Workspace Header Bar (Reusing Global Shell & Sync Badge) */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-600/15 text-cyan-400 border border-cyan-500/30">
              <Brain className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-100">
                Predictive Intelligence Workspace
              </h1>
              <p className="text-xs text-slate-400">
                WS-09 Phase 7.7 Authoritative Predictive Operational Integration & Decision Intelligence
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <SyncStatusHeaderBadge />
          </div>
        </div>

        {/* Global Filter Bar (Reused platform infrastructure) */}
        <GlobalDashboardFilterBar />

        {/* Section 1: Authority Banner & Status Card */}
        {authorityLoading ? (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-center text-slate-400 animate-pulse" data-testid="authority-loading">
            Loading predictive authority status...
          </div>
        ) : authorityError ? (
          <div className="bg-rose-950/40 border border-rose-800/60 rounded-2xl p-6 text-rose-300 flex items-center gap-3" data-testid="authority-error">
            <AlertTriangle className="w-6 h-6 shrink-0 text-rose-400" />
            <div>
              <h3 className="font-semibold text-sm">Authority Query Failed</h3>
              <p className="text-xs text-rose-400/90">{authorityError}</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Main Authority Status Card */}
            <div
              className={`rounded-2xl p-6 border shadow-xl relative overflow-hidden ${
                isNotConfigured
                  ? 'bg-amber-950/20 border-amber-500/40 text-amber-200'
                  : 'bg-emerald-950/20 border-emerald-500/40 text-emerald-200'
              }`}
              data-testid="predictive-authority-banner"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div
                    className={`p-3 rounded-xl ${
                      isNotConfigured
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {isNotConfigured ? <ShieldAlert className="w-8 h-8" /> : <CheckCircle2 className="w-8 h-8" />}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-full border uppercase ${
                          isNotConfigured
                            ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                            : 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                        }`}
                        data-testid="authority-status-badge"
                      >
                        PREDICTION AUTHORITY = {authorityOverview?.overall_authority_status}
                      </span>
                    </div>
                    <h2 className="text-xl font-bold tracking-tight text-slate-100">
                      {isNotConfigured
                        ? 'Predictive Intelligence Unavailable (NOT_CONFIGURED)'
                        : 'Authoritative Production Inference Operational'}
                    </h2>
                    <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
                      {authorityOverview?.calculation_notes}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={handleGenerateIntelligence}
                    disabled={isGenerating}
                    className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl border border-emerald-400 shadow-md transition disabled:opacity-50 shrink-0"
                  >
                    <Brain className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
                    {isGenerating ? 'Generating Intelligence...' : '⚡ Generate Predictive Intelligence'}
                  </button>
                  <div className="flex items-center gap-4 bg-slate-900/80 p-3 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 shrink-0">
                    <div>
                      <span className="text-slate-500 block text-[10px] uppercase">Active Models</span>
                      <span className="text-emerald-400 font-bold">{authorityOverview?.promoted_model_count}</span> / {authorityOverview?.total_model_families}
                    </div>
                    <div className="h-6 w-px bg-slate-800" />
                    <div>
                      <span className="text-slate-500 block text-[10px] uppercase">Rejected Models</span>
                      <span className="text-rose-400 font-bold">{authorityOverview?.rejected_model_count}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Generation Progress Indicator Banner */}
            {generateProgress && (
              <div className="bg-emerald-900/60 border border-emerald-500 text-emerald-100 p-4 rounded-xl text-xs flex items-center gap-3 animate-pulse shadow-lg">
                <Brain className="w-5 h-5 text-emerald-300 animate-spin flex-shrink-0" />
                <div className="font-semibold">{generateProgress}</div>
              </div>
            )}

            {/* Model Family Provenance Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {(authorityOverview?.models || []).map((model) => {
                const modelNotConfigured = model.prediction_authority === 'NOT_CONFIGURED';
                return (
                  <div
                    key={model.model_name}
                    className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 shadow-lg"
                    data-testid={`model-card-${model.model_name}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-slate-200">{model.model_name}</span>
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                          modelNotConfigured
                            ? 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                            : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                        }`}
                      >
                        {model.prediction_authority}
                      </span>
                    </div>

                    <div className="text-[11px] space-y-1.5 text-slate-400">
                      <div className="flex justify-between">
                        <span>Target:</span>
                        <span className="text-slate-200 font-mono">{model.target_name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Category:</span>
                        <span className="text-slate-300">{model.model_category}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>FeatureSet:</span>
                        <span className="text-cyan-400 font-mono">{model.feature_set_version}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Active Version:</span>
                        <span className="font-mono text-slate-200">{model.active_version || 'None'}</span>
                      </div>
                      <div className="flex justify-between truncate">
                        <span>Artifact SHA:</span>
                        <span className="font-mono text-[10px] text-slate-400 truncate max-w-[120px]" title={model.artifact_sha256 || 'None'}>
                          {model.artifact_sha256 ? `${model.artifact_sha256.slice(0, 12)}...` : 'None'}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Section 2: Phase 7.7 Operational Decision Intelligence Prioritization */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl" data-testid="operational-prioritization-section">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-400" />
              <h2 className="text-lg font-bold text-slate-100">Operational Decision Intelligence Prioritization</h2>
            </div>
            <span className="text-xs font-mono text-slate-400">
              Operational Risk Vectors
            </span>
          </div>

          {isNotConfigured ? (
            <div className="py-8 text-center space-y-2 bg-slate-950/40 rounded-xl border border-slate-800/80 p-4" data-testid="prioritization-not-configured">
              <ShieldAlert className="w-8 h-8 text-amber-400 mx-auto" />
              <h3 className="text-sm font-bold text-slate-200">Operational Risk Prioritization Disabled</h3>
              <p className="text-xs text-slate-400 max-w-lg mx-auto">
                No active promoted models exist (`NOT_CONFIGURED`). Operational dispatches cannot be ranked or prioritized by machine learning models until a candidate model passes Phase 7.3 promotion gates.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Top Predicted Delay Dispatches */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3" data-testid="prioritization-delay-list">
                <h3 className="text-xs font-mono font-bold text-rose-400 uppercase tracking-wider">Top Predicted Delay Dispatches</h3>
                {!operationalData?.prioritization?.top_delayed_dispatches || operationalData.prioritization.top_delayed_dispatches.length === 0 ? (
                  <p className="text-xs text-slate-500">No delayed dispatches prioritized.</p>
                ) : (
                  <div className="space-y-2">
                    {operationalData.prioritization.top_delayed_dispatches.map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
                        <div>
                          <span className="font-mono font-bold text-slate-200">{item.dispatch_code}</span>
                          <span className="text-slate-500 block text-[10px]">{item.plant_name || item.plant_code}</span>
                        </div>
                        <div className="text-right">
                          <span className="font-mono font-bold text-rose-400">{item.predicted_value} mins</span>
                          <button
                            onClick={() => setSelectedSnapshot(item)}
                            className="ml-3 text-[10px] text-cyan-400 hover:text-cyan-300 underline inline-flex items-center gap-0.5"
                          >
                            Drill Down <ArrowUpRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* High SLA Breach Risk Dispatches */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3" data-testid="prioritization-sla-list">
                <h3 className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">High SLA Breach Probability Dispatches</h3>
                {!operationalData?.prioritization?.high_sla_risk_dispatches || operationalData.prioritization.high_sla_risk_dispatches.length === 0 ? (
                  <p className="text-xs text-slate-500">No high SLA risk dispatches prioritized.</p>
                ) : (
                  <div className="space-y-2">
                    {operationalData.prioritization.high_sla_risk_dispatches.map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
                        <div>
                          <span className="font-mono font-bold text-slate-200">{item.dispatch_code}</span>
                          <span className="text-slate-500 block text-[10px]">{item.customer_name || item.customer_code}</span>
                        </div>
                        <div className="text-right">
                          <span className="font-mono font-bold text-amber-400">{item.confidence_score ? `${(item.confidence_score * 100).toFixed(1)}%` : 'N/A'} Risk</span>
                          <button
                            onClick={() => setSelectedSnapshot(item)}
                            className="ml-3 text-[10px] text-cyan-400 hover:text-cyan-300 underline inline-flex items-center gap-0.5"
                          >
                            Drill Down <ArrowUpRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Section 3: Authoritative Prediction Snapshots */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-indigo-400" />
              <h2 className="text-lg font-bold text-slate-100">Authoritative Prediction Snapshots</h2>
            </div>
            <span className="text-xs font-mono text-slate-400">
              Total Records: {snapshots.length}
            </span>
          </div>

          {operationalLoading ? (
            <div className="py-8 text-center text-slate-400 text-xs animate-pulse" data-testid="snapshots-loading">
              Loading prediction snapshot history...
            </div>
          ) : operationalError ? (
            <div className="py-4 text-center text-rose-400 text-xs" data-testid="snapshots-error">
              {operationalError}
            </div>
          ) : snapshots.length === 0 ? (
            <div className="py-12 text-center space-y-3" data-testid="snapshots-empty-state">
              <div className="w-12 h-12 rounded-full bg-slate-800 text-slate-500 flex items-center justify-center mx-auto">
                <Lock className="w-6 h-6" />
              </div>
              <div className="space-y-1 max-w-md mx-auto">
                <h3 className="text-sm font-semibold text-slate-300">
                  {isNotConfigured ? 'Prediction Snapshots Unavailable (NOT_CONFIGURED)' : 'No Prediction Snapshots Found (NO_DATA)'}
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {isNotConfigured
                    ? 'Production prediction authority is currently NOT_CONFIGURED (0 promoted models). No authoritative prediction snapshots exist or can be generated in this state.'
                    : 'Prediction authority is active (AUTHORITATIVE), but no historical prediction snapshots match the current global filter selection (NO_DATA).'}
                </p>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                    <th className="py-2.5 px-3">Snapshot ID</th>
                    <th className="py-2.5 px-3">Timestamp</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Model / Version</th>
                    <th className="py-2.5 px-3">Dispatch / Context</th>
                    <th className="py-2.5 px-3 text-right">Predicted Value</th>
                    <th className="py-2.5 px-3 text-right">Confidence</th>
                    <th className="py-2.5 px-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {snapshots.map((snap) => (
                    <tr key={snap.id} className="hover:bg-slate-800/40 transition" data-testid={`snapshot-row-${snap.prediction_snapshot_id}`}>
                      <td className="py-2.5 px-3 font-semibold text-indigo-300">{snap.prediction_snapshot_id}</td>
                      <td className="py-2.5 px-3 text-slate-400">{new Date(snap.prediction_timestamp).toLocaleString()}</td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                          {snap.prediction_status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-200">
                        {snap.model_name} <span className="text-slate-500">({snap.model_version})</span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-300">
                        {snap.dispatch_code}
                        {snap.plant_name && <span className="text-slate-500 block text-[10px]">{snap.plant_name}</span>}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-100">
                        {snap.predicted_value !== null ? snap.predicted_value : 'N/A'}
                      </td>
                      <td className="py-2.5 px-3 text-right text-cyan-400">
                        {snap.confidence_score !== null ? `${(snap.confidence_score * 100).toFixed(1)}%` : 'N/A'}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => setSelectedSnapshot(snap)}
                          className="px-2.5 py-1 rounded bg-indigo-600/20 text-indigo-300 hover:bg-indigo-600/40 border border-indigo-500/30 text-[11px] inline-flex items-center gap-1"
                          data-testid={`drilldown-button-${snap.prediction_snapshot_id}`}
                        >
                          <Eye className="w-3.5 h-3.5" /> Lineage
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Section 4: Interactive Snapshot Lineage & Drill-Down Modal */}
        {selectedSnapshot && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4" data-testid="snapshot-drilldown-modal">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl relative max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-cyan-400" />
                  <h3 className="text-lg font-bold text-slate-100">
                    Snapshot Lineage & Provenance: {selectedSnapshot.prediction_snapshot_id}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedSnapshot(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                  data-testid="close-modal-button"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs font-mono bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Snapshot ID</span>
                  <span className="text-indigo-400 font-bold">{selectedSnapshot.prediction_snapshot_id}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Timestamp</span>
                  <span className="text-slate-200">{new Date(selectedSnapshot.prediction_timestamp).toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Model / Version</span>
                  <span className="text-slate-200">{selectedSnapshot.model_name} ({selectedSnapshot.model_version})</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">FeatureSet Version</span>
                  <span className="text-cyan-400">{selectedSnapshot.feature_set_version}</span>
                </div>
                <div className="col-span-2 truncate">
                  <span className="text-slate-500 block text-[10px] uppercase">Artifact SHA-256</span>
                  <span className="text-slate-400 text-[11px] truncate">{selectedSnapshot.artifact_sha256}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Dispatch Context</span>
                  <span className="text-slate-200">{selectedSnapshot.dispatch_code}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Plant / Customer</span>
                  <span className="text-slate-200">{selectedSnapshot.plant_name || selectedSnapshot.plant_code || 'N/A'} / {selectedSnapshot.customer_name || selectedSnapshot.customer_code || 'N/A'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Predicted Value</span>
                  <span className="text-emerald-400 font-bold">{selectedSnapshot.predicted_value !== null ? selectedSnapshot.predicted_value : 'N/A'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Confidence Score</span>
                  <span className="text-cyan-400 font-bold">{selectedSnapshot.confidence_score !== null ? `${(selectedSnapshot.confidence_score * 100).toFixed(1)}%` : 'N/A'}</span>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-mono font-bold text-slate-300">Input Feature Snapshot (`FeatureSetV1`)</h4>
                <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-mono text-cyan-300 max-h-40 overflow-y-auto">
                  {JSON.stringify(
                    Object.fromEntries(
                      Object.entries(selectedSnapshot.input_features || {}).map(([k, v]) =>
                        k === 'dispatch_hour' ? ['Actual Departure Hour (Plant Out Time)', v] : [k, v]
                      )
                    ),
                    null,
                    2
                  )}
                </pre>
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-mono font-bold text-slate-300">Raw Model Outputs</h4>
                <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-mono text-emerald-300 max-h-32 overflow-y-auto">
                  {JSON.stringify(selectedSnapshot.prediction_outputs, null, 2)}
                </pre>
              </div>

              {/* Phase 3 Authoritative Financial Exposure & Rate Lineage Card */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono font-bold text-slate-300 flex items-center gap-1.5">
                  <Coins className="w-3.5 h-3.5 text-amber-400" />
                  Financial Risk Exposure & Rate Lineage (RATE_SPECIFICATION_GLOBAL_V1)
                </h4>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase">Delay Cost Exposure</span>
                    <span className="text-amber-400 font-bold">
                      {selectedSnapshot.financial_exposure_inr !== undefined && selectedSnapshot.financial_exposure_inr !== null
                        ? `₹${selectedSnapshot.financial_exposure_inr.toFixed(2)}`
                        : 'N/A'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase">SLA Penalty Risk</span>
                    <span className="text-rose-400 font-bold">
                      {selectedSnapshot.sla_penalty_risk_inr !== undefined && selectedSnapshot.sla_penalty_risk_inr !== null
                        ? `₹${selectedSnapshot.sla_penalty_risk_inr.toFixed(2)}`
                        : 'N/A'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase">Plant Congestion Risk</span>
                    <span className="text-purple-400 font-bold">
                      {selectedSnapshot.plant_congestion_risk_inr !== undefined && selectedSnapshot.plant_congestion_risk_inr !== null
                        ? `₹${selectedSnapshot.plant_congestion_risk_inr.toFixed(2)}`
                        : 'N/A'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase">Idle Queue Cost</span>
                    <span className="text-cyan-400 font-bold">
                      {selectedSnapshot.idle_queue_cost_inr !== undefined && selectedSnapshot.idle_queue_cost_inr !== null
                        ? `₹${selectedSnapshot.idle_queue_cost_inr.toFixed(2)}`
                        : 'N/A'}
                    </span>
                  </div>
                  <div className="col-span-2 border-t border-slate-800 pt-2">
                    <span className="text-slate-500 block text-[10px] uppercase">Total Financial Risk Exposure</span>
                    <span className="text-emerald-400 font-bold text-sm">
                      {selectedSnapshot.total_financial_risk_inr !== undefined && selectedSnapshot.total_financial_risk_inr !== null
                        ? `₹${selectedSnapshot.total_financial_risk_inr.toFixed(2)}`
                        : 'N/A'}
                    </span>
                  </div>
                </div>
                {selectedSnapshot.calculation_lineage && (
                  <pre className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[10px] font-mono text-amber-300 max-h-28 overflow-y-auto">
                    {JSON.stringify(selectedSnapshot.calculation_lineage, null, 2)}
                  </pre>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </DashboardSyncProvider>
  );
};

export const PredictiveIntelligencePage: React.FC = () => {
  return (
    <DashboardFilterProvider>
      <PredictiveIntelligencePageContent />
    </DashboardFilterProvider>
  );
};

export default PredictiveIntelligencePage;
