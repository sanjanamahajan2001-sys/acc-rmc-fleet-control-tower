import React, { useEffect, useState, useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Activity, ArrowRight, Sparkles } from 'lucide-react';
import { DashboardFilterProvider, useDashboardFilters } from '../../site_dashboard/orchestration/DashboardFilterProvider';
import { DashboardSyncProvider } from '../../site_dashboard/orchestration/DashboardSyncProvider';
import { GlobalDashboardFilterBar } from '../../site_dashboard/components/GlobalDashboardFilterBar';
import { SyncStatusHeaderBadge } from '../../site_dashboard/components/SyncStatusHeaderBadge';
import { SECTION_REGISTRY_CONFIGS } from '../registry/sectionRegistry';
import { SectionRenderer } from '../components/SectionRenderer';
import { OperationalHealthSection, OperationalHealthData } from '../components/OperationalHealthSection';
import { OperationalAlertIntelligenceSection, OperationalAlertIntelligenceData } from '../components/OperationalAlertIntelligenceSection';
import { OperationalDecisionRecommendationsSection, OperationalDecisionRecommendationData } from '../components/OperationalDecisionRecommendationsSection';
import { OperationalFinancialExposureSection, OperationalFinancialExposureData } from '../components/OperationalFinancialExposureSection';
import { OperationalFleetEfficiencySection, OperationalFleetEfficiencyData } from '../components/OperationalFleetEfficiencySection';
import { OperationalCostExposureSection, OperationalCostExposureData } from '../components/OperationalCostExposureSection';

export const OperationalIntelligencePageContent: React.FC = () => {
  const { filters, updateMetadata } = useDashboardFilters();

  // Section 01 States
  const [healthData, setHealthData] = useState<OperationalHealthData | null>(null);
  const [healthLoading, setHealthLoading] = useState<boolean>(true);
  const [healthError, setHealthError] = useState<string | null>(null);

  // Section 02 States
  const [alertsData, setAlertsData] = useState<OperationalAlertIntelligenceData | null>(null);
  const [alertsLoading, setAlertsLoading] = useState<boolean>(true);
  const [alertsError, setAlertsError] = useState<string | null>(null);

  // Section 03 States
  const [recsData, setRecsData] = useState<OperationalDecisionRecommendationData | null>(null);
  const [recsLoading, setRecsLoading] = useState<boolean>(true);
  const [recsError, setRecsError] = useState<string | null>(null);

  // Section 04 States
  const [finData, setFinData] = useState<OperationalFinancialExposureData | null>(null);
  const [finLoading, setFinLoading] = useState<boolean>(true);
  const [finError, setFinError] = useState<string | null>(null);

  // Section 05 States
  const [effData, setEffData] = useState<OperationalFleetEfficiencyData | null>(null);
  const [effLoading, setEffLoading] = useState<boolean>(true);
  const [effError, setEffError] = useState<string | null>(null);

  // Section 06 States
  const [costData, setCostData] = useState<OperationalCostExposureData | null>(null);
  const [costLoading, setCostLoading] = useState<boolean>(true);
  const [costError, setCostError] = useState<string | null>(null);
  const [, setCostPage] = useState<number>(1);

  const updateMetadataRef = useRef(updateMetadata);
  updateMetadataRef.current = updateMetadata;

  const buildQueryString = useCallback(() => {
    return new URLSearchParams({
      plant_id: filters.plant_id,
      customer_id: filters.customer_id,
      dataset_type: filters.dataset_type,
      ...(filters.operation_date ? { operation_date: filters.operation_date } : {}),
      ...(filters.dataset_id ? { dataset_id: filters.dataset_id } : {}),
    }).toString();
  }, [filters.plant_id, filters.customer_id, filters.dataset_type, filters.operation_date, filters.dataset_id]);

  const fetchHealthData = useCallback(async () => {
    setHealthLoading(true);
    setHealthError(null);
    try {
      const res = await fetch(`/fleet-api/v1/operational-intelligence/health?${buildQueryString()}`);
      const body = await res.json();

      if (!res.ok || !body.success) {
        throw new Error(body.message || 'Unable to calculate operational health metrics');
      }

      const data: OperationalHealthData = body.data;
      setHealthData(data);

      if (data.freshness) {
        updateMetadataRef.current({
          operational_date: data.freshness.operational_date,
          dataset_id: data.freshness.dataset_id,
          import_timestamp: data.freshness.import_timestamp,
          calculation_timestamp: new Date().toISOString(),
          total_dispatches: data.freshness.total_dispatches,
          total_trips: data.freshness.total_trips,
          dataset_status: data.freshness.dataset_status,
        });
      }
    } catch (err: any) {
      setHealthError(err.message || 'Error fetching operational health');
    } finally {
      setHealthLoading(false);
    }
  }, [buildQueryString]);

  const fetchAlertsData = useCallback(async () => {
    setAlertsLoading(true);
    setAlertsError(null);
    try {
      const res = await fetch(`/fleet-api/v1/operational-intelligence/alerts?${buildQueryString()}`);
      const body = await res.json();

      if (!res.ok || !body.success) {
        throw new Error(body.message || 'Unable to calculate operational alert intelligence');
      }

      setAlertsData(body.data);
    } catch (err: any) {
      setAlertsError(err.message || 'Error fetching alert intelligence');
    } finally {
      setAlertsLoading(false);
    }
  }, [buildQueryString]);

  const fetchRecsData = useCallback(async () => {
    setRecsLoading(true);
    setRecsError(null);
    try {
      const res = await fetch(`/fleet-api/v1/operational-intelligence/recommendations?${buildQueryString()}`);
      const body = await res.json();

      if (!res.ok || !body.success) {
        throw new Error(body.message || 'Unable to calculate decision recommendations');
      }

      setRecsData(body.data);
    } catch (err: any) {
      setRecsError(err.message || 'Error fetching decision recommendations');
    } finally {
      setRecsLoading(false);
    }
  }, [buildQueryString]);

  const fetchFinData = useCallback(async () => {
    setFinLoading(true);
    setFinError(null);
    try {
      const res = await fetch(`/fleet-api/v1/operational-intelligence/financial?${buildQueryString()}`);
      const body = await res.json();

      if (!res.ok || !body.success) {
        throw new Error(body.message || 'Unable to calculate financial exposure metrics');
      }

      setFinData(body.data);
    } catch (err: any) {
      setFinError(err.message || 'Error fetching financial exposure');
    } finally {
      setFinLoading(false);
    }
  }, [buildQueryString]);

  const fetchEffData = useCallback(async () => {
    setEffLoading(true);
    setEffError(null);
    try {
      const res = await fetch(`/fleet-api/v1/operational-intelligence/efficiency?${buildQueryString()}`);
      const body = await res.json();

      if (!res.ok || !body.success) {
        throw new Error(body.message || 'Unable to calculate fleet efficiency metrics');
      }

      setEffData(body.data);
    } catch (err: any) {
      setEffError(err.message || 'Error fetching fleet efficiency');
    } finally {
      setEffLoading(false);
    }
  }, [buildQueryString]);

  const latestCostRequestIdRef = useRef(0);

  const fetchCostData = useCallback(async (targetPage: number = 1) => {
    const currentRequestId = ++latestCostRequestIdRef.current;
    setCostLoading(true);
    setCostError(null);
    try {
      const qs = new URLSearchParams({
        plant_id: filters.plant_id,
        customer_id: filters.customer_id,
        dataset_type: filters.dataset_type,
        ...(filters.operation_date ? { operation_date: filters.operation_date } : {}),
        ...(filters.dataset_id ? { dataset_id: filters.dataset_id } : {}),
        page: String(targetPage),
        page_size: '10',
      }).toString();

      const res = await fetch(`/fleet-api/v1/operational-intelligence/cost-exposure?${qs}`);
      const body = await res.json();

      if (currentRequestId !== latestCostRequestIdRef.current) {
        // Discard stale out-of-order response
        return;
      }

      if (!res.ok || !body.success) {
        throw new Error(body.message || 'Unable to calculate cost & exposure intelligence');
      }

      setCostData(body.data);
    } catch (err: any) {
      if (currentRequestId === latestCostRequestIdRef.current) {
        setCostError(err.message || 'Error fetching cost & exposure intelligence');
      }
    } finally {
      if (currentRequestId === latestCostRequestIdRef.current) {
        setCostLoading(false);
      }
    }
  }, [filters.plant_id, filters.customer_id, filters.dataset_type, filters.operation_date, filters.dataset_id]);

  const handleCostPageChange = useCallback((newPage: number) => {
    setCostPage(newPage);
    fetchCostData(newPage);
  }, [fetchCostData]);

  const masterRefresh = useCallback(() => {
    fetchHealthData();
    fetchAlertsData();
    fetchRecsData();
    fetchFinData();
    fetchEffData();
    setCostPage(1);
    fetchCostData(1);
  }, [fetchHealthData, fetchAlertsData, fetchRecsData, fetchFinData, fetchEffData, fetchCostData]);

  useEffect(() => {
    masterRefresh();
  }, [masterRefresh]);

  const healthConfig = SECTION_REGISTRY_CONFIGS.SECTION_01_OPERATIONAL_HEALTH;
  const alertConfig = SECTION_REGISTRY_CONFIGS.SECTION_02_ALERTS_INTELLIGENCE;
  const recsConfig = SECTION_REGISTRY_CONFIGS.SECTION_03_DECISION_RECOMMENDATIONS;
  const finConfig = SECTION_REGISTRY_CONFIGS.SECTION_04_FINANCIAL_EXPOSURE;
  const effConfig = SECTION_REGISTRY_CONFIGS.SECTION_05_FLEET_EFFICIENCY;
  const costConfig = SECTION_REGISTRY_CONFIGS.SECTION_06_COST_EXPOSURE;

  return (
    <DashboardSyncProvider onRefreshNeeded={masterRefresh}>
      <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-5 space-y-6">
        {/* Workspace Sub-Header Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-600/15 text-indigo-400 border border-indigo-500/30">
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-100">
                Operational Intelligence Control Room
              </h1>
              <p className="text-xs text-slate-400">
                WS-09 Authoritative Control Tower Workspace & Decision Intelligence Canvas
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <SyncStatusHeaderBadge />
          </div>
        </div>

        {/* Global Filter Control Bar (Shared platform infrastructure) */}
        <GlobalDashboardFilterBar />

        {/* Predictive Intelligence CTA Navigation Banner */}
        <div className="bg-gradient-to-r from-indigo-950/80 via-slate-900/90 to-slate-950 border border-indigo-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <Sparkles className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-100">Predictive Intelligence & Decision Engine Active</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  AUTHORITATIVE
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Authoritative ML predictions, INR financial exposure forecasts, and recommendations are active.
              </p>
            </div>
          </div>
          <Link
            to="/predictive-intelligence"
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white flex items-center gap-2 transition shadow-md hover:shadow-indigo-500/25 shrink-0"
          >
            <span>View Predictive Intelligence Workspace</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {/* Section 01: Operational Health & Executive Index */}
        <SectionRenderer
          config={healthConfig}
          loading={healthLoading}
          error={healthError}
          calculationStatus={healthData?.calculation_status}
          calculationNotes={healthData?.calculation_notes}
          onRetry={fetchHealthData}
        >
          <OperationalHealthSection data={healthData} />
        </SectionRenderer>

        {/* Section 02: Operational Alert Intelligence */}
        <SectionRenderer
          config={alertConfig}
          loading={alertsLoading}
          error={alertsError}
          calculationStatus={alertsData?.calculation_status}
          calculationNotes={alertsData?.calculation_notes}
          onRetry={fetchAlertsData}
        >
          <OperationalAlertIntelligenceSection data={alertsData} />
        </SectionRenderer>

        {/* Section 03: Actionable Decision Recommendations */}
        <SectionRenderer
          config={recsConfig}
          loading={recsLoading}
          error={recsError}
          calculationStatus={recsData?.calculation_status}
          calculationNotes={recsData?.calculation_notes}
          onRetry={fetchRecsData}
        >
          <OperationalDecisionRecommendationsSection data={recsData} />
        </SectionRenderer>

        {/* Section 04: Financial Loss & SLA Risk Exposure */}
        <SectionRenderer
          config={finConfig}
          loading={finLoading}
          error={finError}
          calculationStatus={finData?.calculation_status}
          calculationNotes={finData?.calculation_notes}
          onRetry={fetchFinData}
        >
          <OperationalFinancialExposureSection data={finData} />
        </SectionRenderer>

        {/* Section 05: Fleet & Plant Operational Efficiency */}
        <SectionRenderer
          config={effConfig}
          loading={effLoading}
          error={effError}
          calculationStatus={effData?.calculation_status}
          calculationNotes={effData?.calculation_notes}
          onRetry={fetchEffData}
        >
          <OperationalFleetEfficiencySection data={effData} />
        </SectionRenderer>

        {/* Section 06: Cost & Exposure Intelligence */}
        <SectionRenderer
          config={costConfig}
          loading={costLoading}
          error={costError}
          calculationStatus={costData?.calculation_status as 'SUCCESS' | 'NO_RECORDS' | 'NOT_CONFIGURED' | 'ERROR' | undefined}
          calculationNotes={costData?.calculation_notes}
          onRetry={() => {
            setCostPage(1);
            fetchCostData(1);
          }}
        >
          <OperationalCostExposureSection
            data={costData}
            onPageChange={handleCostPageChange}
          />
        </SectionRenderer>
      </div>
    </DashboardSyncProvider>
  );
};

export const OperationalIntelligencePage: React.FC = () => {
  return (
    <DashboardFilterProvider>
      <OperationalIntelligencePageContent />
    </DashboardFilterProvider>
  );
};

export default OperationalIntelligencePage;
