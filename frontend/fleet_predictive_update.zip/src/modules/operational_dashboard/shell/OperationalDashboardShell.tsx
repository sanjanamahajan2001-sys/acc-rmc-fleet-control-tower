import React from 'react';
import { LayoutDashboard, AlertCircle, RefreshCw } from 'lucide-react';
import { DashboardSyncProvider } from '../../site_dashboard/orchestration/DashboardSyncProvider';
import { DashboardFilterProvider } from '../../site_dashboard/orchestration/DashboardFilterProvider';
import { GlobalDashboardFilterBar } from '../../site_dashboard/components/GlobalDashboardFilterBar';
import { SyncStatusHeaderBadge } from '../../site_dashboard/components/SyncStatusHeaderBadge';
import { useOperationalDashboardContext } from '../hooks/useOperationalDashboardContext';
import { ExecutiveKPIRibbon } from '../components/ExecutiveKPIRibbon';

interface OperationalDashboardShellContentProps {
  children?: React.ReactNode;
}

const OperationalDashboardShellContent: React.FC<OperationalDashboardShellContentProps> = ({ children }) => {
  const { shellData, loading, error, refetchContext } = useOperationalDashboardContext();

  return (
    <DashboardSyncProvider onRefreshNeeded={refetchContext}>
      <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-5 space-y-6">
        {/* Top Header Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-600/15 text-indigo-400 border border-indigo-500/30">
              <LayoutDashboard className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-100">
                Overall Operational Dashboard
              </h1>
              <p className="text-xs text-slate-400">
                Executive Fleet Command Tower, Operational SLAs & Customer Performance Intelligence
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <SyncStatusHeaderBadge />
          </div>
        </div>

        {/* Global Dashboard Filter Bar (Shared across all operational views) */}
        <GlobalDashboardFilterBar />

        {/* Executive Top Ribbon Row-1 KPIs */}
        <ExecutiveKPIRibbon />

        {/* Loading Shimmer State */}
        {loading && !shellData && (
          <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 animate-pulse flex items-center justify-center space-x-3 text-slate-400">
            <RefreshCw className="w-5 h-5 animate-spin text-indigo-400" />
            <span className="text-sm font-semibold">Synchronizing Operational Context...</span>
          </div>
        )}

        {/* Error Banner State */}
        {error && (
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-between text-rose-300 text-xs">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-400" />
              <span>{error}</span>
            </div>
            <button
              onClick={() => refetchContext()}
              className="px-3 py-1 bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 rounded-lg text-rose-200 font-semibold transition"
            >
              Retry
            </button>
          </div>
        )}

        {/* Zero-Data / Empty Context Banner */}
        {!loading && shellData && shellData.metadata.total_dispatches === 0 && (
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center justify-between">
            <span>No canonical operational dispatches loaded for the current filter context.</span>
            <span className="font-mono text-[11px] text-amber-400">STATUS: ABSOLUTE ZERO</span>
          </div>
        )}

        {/* Child Widgets Slot */}
        <div className="space-y-6">
          {children || (
            <div className="p-12 rounded-2xl bg-slate-900/40 border border-slate-800/80 text-center space-y-3">
              <h3 className="text-lg font-bold text-slate-300">Operational Shell Canvas Ready</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                WS-03.0 Core Shell & Synchronization Engine established. Child widget modules will mount here in subsequent workstreams.
              </p>
            </div>
          )}
        </div>
      </div>
    </DashboardSyncProvider>
  );
};

export const OperationalDashboardShell: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  return (
    <DashboardFilterProvider>
      <OperationalDashboardShellContent>{children}</OperationalDashboardShellContent>
    </DashboardFilterProvider>
  );
};

export default OperationalDashboardShell;
