/**
 * WS-07.7 Alert Center UI Workspace Content Widget
 * Production UI component for Operational Alert Center.
 * Reuses top shell & dataset context, renders alert KPI summary cards,
 * scope-aware filter bar, paginated data table, and detail/action drawer.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Bell,
  CheckCircle2,
  AlertTriangle,
  Info,
  Filter,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  X,
  UserCheck,
  ShieldCheck,
  AlertCircle,
  FileText,
  Activity,
  Layers,
  Clock,
  Database,
  Building,
  Users,
} from 'lucide-react';
import { useDashboardFilters } from '../../../site_dashboard/orchestration/DashboardFilterProvider';
import { useDashboardSync } from '../../../site_dashboard/orchestration/DashboardSyncProvider';
import {
  OperationalAlertSummary,
  OperationalAlertItem,
} from '../../types/operational_alerts_types';

export const AlertCenterWorkspaceContent: React.FC = () => {
  const { filters, metadata } = useDashboardFilters();
  const { syncStatus } = useDashboardSync();
  const lastSyncTimestamp = syncStatus?.last_sync_timestamp;
  const activeDatasetId = filters.dataset_id || metadata?.dataset_id || 'DS-20260805-001';

  // Primary API states
  const [summary, setSummary] = useState<OperationalAlertSummary | null>(null);
  const [alerts, setAlerts] = useState<OperationalAlertItem[]>([]);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [pageSize] = useState<number>(10);
  const [totalPages, setTotalPages] = useState<number>(1);

  // Widget-specific filter states
  const [severityFilter, setSeverityFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('OPEN');
  const [alertTypeFilter, setAlertTypeFilter] = useState<string>('ALL');

  // Detail drawer state
  const [selectedAlertId, setSelectedAlertId] = useState<string | null>(null);
  const [detailAlert, setDetailAlert] = useState<OperationalAlertItem | null>(null);
  const [isDetailLoading, setIsDetailLoading] = useState<boolean>(false);

  // Action form state
  const [ackNotes, setAckNotes] = useState<string>('');
  const [operatorName, setOperatorName] = useState<string>('Operator_ControlTower');
  const [resolveReason, setResolveReason] = useState<string>('Operational Queue Cleared');
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [isActionLoading, setIsActionLoading] = useState<boolean>(false);

  // General loading & error
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  // Master fetch summary & alerts callback (memoized)
  const fetchSummaryAndList = useCallback(async () => {
    setIsLoading(true);
    setFetchError(null);
    try {
      // Build query params propagating Global Filters & Local Alert Filters
      const queryParams = new URLSearchParams();
      if (filters.plant_id && filters.plant_id !== 'ALL') queryParams.set('plant_id', filters.plant_id);
      if (filters.customer_id && filters.customer_id !== 'ALL') queryParams.set('customer_id', filters.customer_id);
      if (activeDatasetId) queryParams.set('dataset_id', activeDatasetId);

      if (severityFilter !== 'ALL') queryParams.set('severity', severityFilter);
      if (statusFilter !== 'ALL') queryParams.set('status', statusFilter);
      if (alertTypeFilter !== 'ALL') queryParams.set('alert_type', alertTypeFilter);

      queryParams.set('page', page.toString());
      queryParams.set('page_size', pageSize.toString());

      // 1. Fetch Summary
      const summaryRes = await fetch(`/fleet-api/v1/alerts/summary?${queryParams.toString()}`);
      if (!summaryRes.ok) {
        throw new Error(`Summary API error: HTTP ${summaryRes.status}`);
      }
      const summaryData: OperationalAlertSummary = await summaryRes.json();
      setSummary(summaryData);

      // 2. Fetch Paginated List
      const listRes = await fetch(`/fleet-api/v1/alerts?${queryParams.toString()}`);
      if (!listRes.ok) {
        throw new Error(`Alerts List API error: HTTP ${listRes.status}`);
      }
      const listData = await listRes.json();
      setAlerts(listData.items || []);
      setTotalCount(listData.total_count || 0);
      setTotalPages(listData.total_pages || 1);
    } catch (err: any) {
      setFetchError(err.message || 'Failed to fetch alert workspace data');
    } finally {
      setIsLoading(false);
    }
  }, [filters.plant_id, filters.customer_id, activeDatasetId, severityFilter, statusFilter, alertTypeFilter, page, pageSize]);

  // Fetch summary & alerts list when filters or sync state changes
  useEffect(() => {
    fetchSummaryAndList();
  }, [fetchSummaryAndList, lastSyncTimestamp]);

  // Fetch detail alert when drawer opens (preserves action notifications if called from refresh)
  const fetchDetailAlert = useCallback(async (alertId: string, clearNotifications: boolean = true) => {
    setIsDetailLoading(true);
    if (clearNotifications) {
      setActionError(null);
      setActionSuccess(null);
    }
    try {
      const queryParams = new URLSearchParams();
      if (filters.plant_id && filters.plant_id !== 'ALL') queryParams.set('plant_id', filters.plant_id);
      if (filters.customer_id && filters.customer_id !== 'ALL') queryParams.set('customer_id', filters.customer_id);

      const res = await fetch(`/fleet-api/v1/alerts/${alertId}?${queryParams.toString()}`);
      if (!res.ok) {
        if (res.status === 404) throw new Error('Alert not found or inaccessible under active scope.');
        throw new Error(`Detail API error: HTTP ${res.status}`);
      }
      const data = await res.json();
      setDetailAlert(data);
    } catch (err: any) {
      setActionError(err.message || 'Failed to load alert detail.');
      setDetailAlert(null);
    } finally {
      setIsDetailLoading(false);
    }
  }, [filters.plant_id, filters.customer_id]);

  // Close drawer or re-fetch when selectedAlertId changes
  useEffect(() => {
    if (!selectedAlertId) {
      setDetailAlert(null);
      return;
    }
    fetchDetailAlert(selectedAlertId, true);
  }, [selectedAlertId, fetchDetailAlert]);

  // Scope Isolation Guard: Close drawer if active global scope changes while drawer is open
  useEffect(() => {
    if (selectedAlertId) {
      setSelectedAlertId(null);
      setDetailAlert(null);
    }
  }, [filters.plant_id, filters.customer_id]);

  // Coordinated Post-Action Refresh Mechanism
  const refreshAlertWorkspace = useCallback(async (alertId?: string) => {
    await fetchSummaryAndList();
    if (alertId) {
      await fetchDetailAlert(alertId, false);
    }
  }, [fetchSummaryAndList, fetchDetailAlert]);

  // Acknowledge Action Handler
  const handleAcknowledge = async () => {
    if (!selectedAlertId || isActionLoading) return;
    setIsActionLoading(true);
    setActionError(null);
    setActionSuccess(null);
    try {
      const res = await fetch(`/fleet-api/v1/alerts/${selectedAlertId}/acknowledge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ acknowledged_by: operatorName, notes: ackNotes }),
      });

      if (res.status === 409) {
        setActionError('409 CONFLICT: Alert state has been modified concurrently. Refreshing state...');
        await refreshAlertWorkspace(selectedAlertId);
        return;
      }

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to acknowledge alert.');
      }

      setActionSuccess('Alert successfully ACKNOWLEDGED.');
      setAckNotes('');
      // Await complete authoritative refresh of detail, summary, and list
      await refreshAlertWorkspace(selectedAlertId);
    } catch (err: any) {
      setActionError(err.message || 'Acknowledge operation failed.');
    } finally {
      setIsActionLoading(false);
    }
  };

  // Resolve Action Handler
  const handleResolve = async () => {
    if (!selectedAlertId || isActionLoading) return;
    setIsActionLoading(true);
    setActionError(null);
    setActionSuccess(null);
    try {
      const res = await fetch(`/fleet-api/v1/alerts/${selectedAlertId}/resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resolved_by: operatorName, resolution_reason: resolveReason }),
      });

      if (res.status === 409) {
        setActionError('409 CONFLICT: Alert state has been modified concurrently. Refreshing state...');
        await refreshAlertWorkspace(selectedAlertId);
        return;
      }

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to resolve alert.');
      }

      setActionSuccess('Alert successfully RESOLVED.');
      // Await complete authoritative refresh of detail, summary, and list
      await refreshAlertWorkspace(selectedAlertId);
    } catch (err: any) {
      setActionError(err.message || 'Resolve operation failed.');
    } finally {
      setIsActionLoading(false);
    }
  };

  return (
    <div className="space-y-6" data-testid="alert-center-workspace">
      {/* Alert KPI Summary Strip (Primary KPI Row) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3" data-testid="alert-summary-strip">
        <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium uppercase tracking-wider">Total Active</span>
            <Bell className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-100">{summary?.total_active_alerts ?? 0}</span>
            <span className="text-[10px] text-slate-500 font-mono">Active Exceptions</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex flex-col justify-between">
          <div className="flex items-center justify-between text-rose-400">
            <span className="text-xs font-medium uppercase tracking-wider">Critical</span>
            <AlertCircle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-rose-300">{summary?.critical_count ?? 0}</span>
            <span className="text-[10px] text-rose-400/70 font-mono">P1 Immediate</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 flex flex-col justify-between">
          <div className="flex items-center justify-between text-amber-400">
            <span className="text-xs font-medium uppercase tracking-wider">Warning</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-amber-300">{summary?.warning_count ?? 0}</span>
            <span className="text-[10px] text-amber-400/70 font-mono">P2 SLA At Risk</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-sky-500/10 border border-sky-500/20 flex flex-col justify-between">
          <div className="flex items-center justify-between text-sky-400">
            <span className="text-xs font-medium uppercase tracking-wider">Info</span>
            <Info className="w-4 h-4 text-sky-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-sky-300">{summary?.info_count ?? 0}</span>
            <span className="text-[10px] text-sky-400/70 font-mono">P3 Informational</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex flex-col justify-between col-span-2 md:col-span-1">
          <div className="flex items-center justify-between text-indigo-400">
            <span className="text-xs font-medium uppercase tracking-wider">Acknowledged</span>
            <UserCheck className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-indigo-300" data-testid="summary-ack-count">{summary?.acknowledged_count ?? 0}</span>
            <span className="text-[10px] text-indigo-400/70 font-mono">In Triage</span>
          </div>
        </div>
      </div>

      {/* Alert Filter Control Bar */}
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-wrap items-center justify-between gap-4" data-testid="alert-filter-controls">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 text-xs text-slate-400 font-medium">
            <Filter className="w-3.5 h-3.5 text-amber-400" />
            <span>Alert Filters:</span>
          </div>

          {/* Severity Dropdown */}
          <select
            value={severityFilter}
            onChange={(e) => { setSeverityFilter(e.target.value); setPage(1); }}
            className="bg-slate-950 text-slate-200 text-xs px-2.5 py-1.5 rounded-lg border border-slate-700 focus:outline-none focus:border-amber-500 font-mono"
            data-testid="severity-filter-select"
          >
            <option value="ALL">All Severities</option>
            <option value="CRITICAL">Critical</option>
            <option value="WARNING">Warning</option>
            <option value="INFO">Info</option>
          </select>

          {/* Status Dropdown */}
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            className="bg-slate-950 text-slate-200 text-xs px-2.5 py-1.5 rounded-lg border border-slate-700 focus:outline-none focus:border-amber-500 font-mono"
            data-testid="status-filter-select"
          >
            <option value="ALL">All Statuses</option>
            <option value="OPEN">Open</option>
            <option value="ACKNOWLEDGED">Acknowledged</option>
            <option value="RESOLVED">Resolved</option>
            <option value="ARCHIVED">Archived</option>
          </select>

          {/* Alert Type Dropdown */}
          <select
            value={alertTypeFilter}
            onChange={(e) => { setAlertTypeFilter(e.target.value); setPage(1); }}
            className="bg-slate-950 text-slate-200 text-xs px-2.5 py-1.5 rounded-lg border border-slate-700 focus:outline-none focus:border-amber-500 font-mono"
            data-testid="alert-type-filter-select"
          >
            <option value="ALL">All Exception Types</option>
            <option value="PLANT_HOLDING_BOTTLENECK">Plant Holding Bottleneck</option>
            <option value="SITE_RETENTION_EXCESSIVE">Site Retention Excessive</option>
            <option value="TRANSIT_DELAY_EXCESSIVE">Transit Delay Excessive</option>
            <option value="DEGRADED_DATA_QUALITY">Degraded Data Quality</option>
          </select>
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-400 font-mono">
          <span>{totalCount} Total Matching Alerts</span>
          <button
            onClick={() => fetchSummaryAndList()}
            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
            title="Refresh Alert Stream"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="p-12 rounded-2xl bg-slate-900/60 border border-slate-800 animate-pulse flex items-center justify-center space-x-3 text-slate-400" data-testid="alert-loading-state">
          <RefreshCw className="w-5 h-5 animate-spin text-amber-400" />
          <span className="text-sm font-mono">Fetching active operational alerts...</span>
        </div>
      )}

      {/* Error State */}
      {fetchError && !isLoading && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between" data-testid="alert-error-state">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-rose-400" />
            <span>{fetchError}</span>
          </div>
          <button
            onClick={() => fetchSummaryAndList()}
            className="px-2.5 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 font-mono text-[11px]"
          >
            Retry
          </button>
        </div>
      )}

      {/* Empty State */}
      {!isLoading && !fetchError && alerts.length === 0 && (
        <div className="p-12 rounded-2xl bg-slate-900/40 border border-slate-800/80 text-center space-y-3" data-testid="alert-empty-state">
          <ShieldCheck className="w-10 h-10 text-emerald-400 mx-auto" />
          <h3 className="text-base font-semibold text-slate-200">No Active Exception Alerts Found</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            All business rules are evaluated cleanly for the selected plant, customer, and filter parameters.
          </p>
        </div>
      )}

      {/* Paginated Data Table */}
      {!isLoading && !fetchError && alerts.length > 0 && (
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden" data-testid="alert-list-table">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase font-mono tracking-wider">
                <tr>
                  <th className="px-4 py-3">Severity</th>
                  <th className="px-4 py-3">Alert Type</th>
                  <th className="px-4 py-3">Scope Context</th>
                  <th className="px-4 py-3">Metric Variance</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Detected At</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {alerts.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition">
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                          item.severity === 'CRITICAL'
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : item.severity === 'WARNING'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                        }`}
                      >
                        {item.severity}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-semibold font-mono text-slate-100">{item.alert_type}</td>
                    <td className="px-4 py-3 font-mono text-slate-400">
                      <div>Plant: {item.plant_id || 'N/A'}</div>
                      <div className="text-[10px] text-slate-500">Cust: {item.customer_id || 'N/A'}</div>
                    </td>
                    <td className="px-4 py-3 font-mono">
                      <div>
                        {item.metric_name}: <span className="text-amber-400 font-bold">{item.actual_value}</span> {item.unit}
                      </div>
                      <div className="text-[10px] text-slate-500">Threshold: {item.threshold_value} {item.unit}</div>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold ${
                          item.status === 'OPEN'
                            ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            : item.status === 'ACKNOWLEDGED'
                            ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        }`}
                      >
                        {item.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-400">{new Date(item.detected_at).toLocaleTimeString()}</td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => setSelectedAlertId(item.id)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-[11px] border border-slate-700 transition"
                        data-testid={`inspect-alert-btn-${item.id}`}
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          <div className="p-3 bg-slate-950/90 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400" data-testid="alert-pagination-bar">
            <span>
              Page <strong className="text-slate-200 font-mono">{page}</strong> of <strong className="text-slate-200 font-mono">{totalPages}</strong>
            </span>
            <div className="flex items-center space-x-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300"
                data-testid="pagination-prev-btn"
              >
                <ChevronLeft size={16} />
              </button>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300"
                data-testid="pagination-next-btn"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Alert Detail & Lifecycle Action Drawer */}
      {selectedAlertId && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex justify-end" data-testid="alert-detail-drawer">
          <div className="w-full max-w-lg bg-slate-900 border-l border-slate-800 h-full p-6 overflow-y-auto space-y-6 flex flex-col justify-between">
            <div className="space-y-6">
              {/* Drawer Header */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div>
                  <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2" data-testid="drawer-title">
                    <Bell className="w-5 h-5 text-amber-400" /> Operational Alert Details
                  </h3>
                  <p className="text-xs text-slate-400 font-mono mt-0.5" data-testid="drawer-alert-id">ID: {selectedAlertId}</p>
                </div>
                <button
                  onClick={() => setSelectedAlertId(null)}
                  className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-200 transition"
                  data-testid="close-drawer-btn"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Action Error / Success Notifications */}
              {actionError && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded text-xs" data-testid="drawer-action-error">
                  {actionError}
                </div>
              )}
              {actionSuccess && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 rounded text-xs" data-testid="drawer-action-success">
                  {actionSuccess}
                </div>
              )}

              {/* Drawer Content */}
              {isDetailLoading && (
                <div className="p-8 text-center text-slate-400 flex items-center justify-center space-x-2" data-testid="drawer-loading-state">
                  <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                  <span>Loading alert evidence payload...</span>
                </div>
              )}

              {detailAlert && !isDetailLoading && (
                <div className="space-y-5 text-xs text-slate-300" data-testid="drawer-alert-detail-content">
                  {/* Alert Core Info Grid */}
                  <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-slate-400 flex items-center gap-1.5"><Layers className="w-3.5 h-3.5 text-amber-400" /> Alert Type</span>
                      <span className="font-bold text-amber-400 font-mono" data-testid="drawer-alert-type">{detailAlert.alert_type}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-slate-400 flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5 text-slate-400" /> Severity</span>
                      <span className="font-bold text-slate-200 font-mono" data-testid="drawer-severity">{detailAlert.severity}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-slate-400 flex items-center gap-1.5"><Activity className="w-3.5 h-3.5 text-indigo-400" /> Lifecycle Status</span>
                      <span className="font-bold text-indigo-400 font-mono" data-testid="drawer-status">{detailAlert.status}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-slate-400 flex items-center gap-1.5"><Building className="w-3.5 h-3.5 text-slate-400" /> Plant Scope</span>
                      <span className="text-slate-200 font-mono" data-testid="drawer-plant-id">{detailAlert.plant_id || 'Global Scope'}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-slate-400 flex items-center gap-1.5"><Users className="w-3.5 h-3.5 text-slate-400" /> Customer Scope</span>
                      <span className="text-slate-200 font-mono" data-testid="drawer-customer-id">{detailAlert.customer_id || 'All Customers'}</span>
                    </div>
                    {detailAlert.dispatch_id && (
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-slate-400 flex items-center gap-1.5"><FileText className="w-3.5 h-3.5 text-sky-400" /> Dispatch Ref</span>
                        <span className="text-sky-300 font-mono text-[11px]" data-testid="drawer-dispatch-id">{detailAlert.dispatch_id}</span>
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-slate-400 flex items-center gap-1.5"><Clock className="w-3.5 h-3.5 text-slate-400" /> Detected At</span>
                      <span className="text-slate-300 font-mono" data-testid="drawer-detected-at">{new Date(detailAlert.detected_at).toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-slate-400 flex items-center gap-1.5"><Database className="w-3.5 h-3.5 text-slate-400" /> Rule Version</span>
                      <span className="text-slate-400 font-mono">{detailAlert.rule_version}</span>
                    </div>
                  </div>

                  {/* Observed Metric & Threshold Variance Card */}
                  <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 space-y-2" data-testid="drawer-metric-variance-card">
                    <h4 className="font-semibold text-amber-300 flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-amber-400" /> Observed SLA Metric Variance
                    </h4>
                    <div className="grid grid-cols-3 gap-2 text-center pt-1 font-mono">
                      <div className="p-2 rounded bg-slate-950/60 border border-slate-800">
                        <div className="text-[10px] text-slate-400">Observed</div>
                        <div className="text-sm font-bold text-amber-300" data-testid="drawer-actual-value">{detailAlert.actual_value} <span className="text-[10px] font-normal">{detailAlert.unit}</span></div>
                      </div>
                      <div className="p-2 rounded bg-slate-950/60 border border-slate-800">
                        <div className="text-[10px] text-slate-400">SLA Threshold</div>
                        <div className="text-sm font-bold text-slate-300" data-testid="drawer-threshold-value">{detailAlert.threshold_value} <span className="text-[10px] font-normal">{detailAlert.unit}</span></div>
                      </div>
                      <div className="p-2 rounded bg-slate-950/60 border border-slate-800">
                        <div className="text-[10px] text-slate-400">Exceeded By</div>
                        <div className="text-sm font-bold text-rose-400" data-testid="drawer-variance-value">
                          +{(detailAlert.actual_value - detailAlert.threshold_value).toFixed(1)} <span className="text-[10px] font-normal">{detailAlert.unit}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Business Impact & Action */}
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-slate-200 mb-1 flex items-center gap-1.5">
                        <Activity className="w-3.5 h-3.5 text-rose-400" /> Business Impact Analysis
                      </h4>
                      <p className="p-3 rounded-lg bg-slate-950/40 border border-slate-800/80 text-slate-300" data-testid="drawer-business-impact">
                        {detailAlert.business_impact}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-200 mb-1 flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Recommended Mitigation Action
                      </h4>
                      <p className="p-3 rounded-lg bg-slate-950/40 border border-slate-800/80 text-slate-300" data-testid="drawer-recommended-action">
                        {detailAlert.recommended_action}
                      </p>
                    </div>
                  </div>

                  {/* Evidence Payload */}
                  <div data-testid="drawer-evidence-section">
                    <h4 className="font-semibold text-slate-200 mb-1 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-sky-400" /> Forensic Evidence Payload (JSON)
                    </h4>
                    {detailAlert.evidence_json && Object.keys(detailAlert.evidence_json).length > 0 ? (
                      <pre className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-[11px] text-sky-300 overflow-x-auto" data-testid="drawer-evidence-json">
                        {JSON.stringify(detailAlert.evidence_json, null, 2)}
                      </pre>
                    ) : (
                      <div className="p-3 rounded-lg bg-slate-950 border border-slate-800/80 text-slate-500 italic text-[11px]" data-testid="drawer-no-evidence-banner">
                        No evidence available
                      </div>
                    )}
                  </div>

                  {/* Audit Trail */}
                  {(detailAlert.acknowledged_by || detailAlert.resolved_by) && (
                    <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800 space-y-1 font-mono text-[11px]" data-testid="drawer-audit-log">
                      <h4 className="font-sans font-semibold text-slate-300 mb-1">Audit Trail Log</h4>
                      {detailAlert.acknowledged_by && (
                        <div className="text-indigo-300">
                          ACK: {detailAlert.acknowledged_by} @ {detailAlert.acknowledged_at ? new Date(detailAlert.acknowledged_at).toLocaleString() : ''}
                        </div>
                      )}
                      {detailAlert.resolved_by && (
                        <div className="text-emerald-300">
                          RES: {detailAlert.resolved_by} ({detailAlert.resolution_reason}) @ {detailAlert.resolved_at ? new Date(detailAlert.resolved_at).toLocaleString() : ''}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Lifecycle Action Panel */}
                  <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-4 pt-4" data-testid="drawer-lifecycle-panel">
                    <h4 className="font-semibold text-slate-200 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-amber-400" /> Operator Lifecycle Actions
                    </h4>

                    {/* Operator Digital Signature Input */}
                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-400 font-mono">Operator Digital Signature</label>
                      <input
                        type="text"
                        value={operatorName}
                        onChange={(e) => setOperatorName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 text-xs font-mono focus:border-amber-500 focus:outline-none"
                        data-testid="operator-signature-input"
                      />
                    </div>

                    {/* ACK Action Form */}
                    {detailAlert.status === 'OPEN' && (
                      <div className="space-y-2 pt-2 border-t border-slate-800">
                        <label className="text-[11px] text-slate-400 font-mono">Triage Notes (Optional)</label>
                        <input
                          type="text"
                          placeholder="e.g. Contacted site supervisor..."
                          value={ackNotes}
                          onChange={(e) => setAckNotes(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 text-xs focus:border-amber-500 focus:outline-none"
                          data-testid="ack-notes-input"
                        />
                        <button
                          onClick={handleAcknowledge}
                          disabled={isActionLoading}
                          className="w-full py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 font-bold text-white transition disabled:opacity-50 flex items-center justify-center space-x-2"
                          data-testid="ack-alert-btn"
                        >
                          {isActionLoading && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                          <span>Acknowledge Alert Exception</span>
                        </button>
                      </div>
                    )}

                    {/* RESOLVE Action Form */}
                    {(detailAlert.status === 'OPEN' || detailAlert.status === 'ACKNOWLEDGED') && (
                      <div className="space-y-2 pt-2 border-t border-slate-800">
                        <label className="text-[11px] text-slate-400 font-mono">Resolution Reason</label>
                        <select
                          value={resolveReason}
                          onChange={(e) => setResolveReason(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 text-xs font-mono focus:border-amber-500 focus:outline-none"
                          data-testid="resolve-reason-select"
                        >
                          <option value="Operational Queue Cleared">Operational Queue Cleared</option>
                          <option value="Customer Site SLA Met">Customer Site SLA Met</option>
                          <option value="Speed Normalised">Speed Normalised</option>
                          <option value="Manual Override Approved">Manual Override Approved</option>
                        </select>
                        <button
                          onClick={handleResolve}
                          disabled={isActionLoading}
                          className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 font-bold text-white transition disabled:opacity-50 flex items-center justify-center space-x-2"
                          data-testid="resolve-alert-btn"
                        >
                          {isActionLoading && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                          <span>Resolve & Close Alert</span>
                        </button>
                      </div>
                    )}

                    {detailAlert.status === 'RESOLVED' && (
                      <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 rounded text-center text-xs font-mono">
                        Alert is RESOLVED and closed. No further lifecycle actions available.
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800 text-center">
              <button
                onClick={() => setSelectedAlertId(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs transition"
              >
                Close Drawer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
