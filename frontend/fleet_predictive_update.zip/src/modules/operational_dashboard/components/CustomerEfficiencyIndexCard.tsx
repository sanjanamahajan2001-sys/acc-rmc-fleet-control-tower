import React from 'react';
import { useCustomerEfficiency } from '../hooks/useCustomerEfficiency';
import { OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';

export const CustomerEfficiencyIndexCard: React.FC = () => {
  const { data, loading, error, status } = useCustomerEfficiency();

  const isNoObs = status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || !data?.data || data.data.length === 0;
  const customers = data?.data || [];

  return (
    <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between h-full min-h-[340px] transition-all duration-200 hover:border-slate-700/80">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 tracking-tight flex items-center gap-2">
              <span>CUSTOMER EFFICIENCY INDEX (CEI)</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Ranked customer site efficiency score &amp; operational grade
            </p>
          </div>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-medium tracking-wide uppercase text-sky-400 bg-sky-500/10 border border-sky-500/20">
            WS-03.6
          </span>
        </div>

        {/* Content Body */}
        {loading ? (
          <div className="py-12 flex flex-col items-center justify-center space-y-2">
            <div className="w-6 h-6 border-2 border-sky-500 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-xs text-slate-400 font-mono">Loading customer efficiency...</span>
          </div>
        ) : error ? (
          <div className="py-10 text-center space-y-2">
            <div className="text-xs text-rose-400 font-medium">Failed to load customer efficiency</div>
            <div className="text-[11px] text-slate-500 max-w-xs mx-auto">{error}</div>
          </div>
        ) : isNoObs ? (
          <div className="py-12 text-center space-y-2">
            <div className="text-xs font-semibold text-slate-400">NO OBSERVATIONS</div>
            <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
              No customer efficiency observations available for active filters.
            </p>
          </div>
        ) : (
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/40 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800/80">
                <tr>
                  <th scope="col" className="pb-2 pl-1 font-mono w-8 text-center">#</th>
                  <th scope="col" className="pb-2">CUSTOMER</th>
                  <th scope="col" className="pb-2 text-right">CEI SCORE</th>
                  <th scope="col" className="pb-2 text-center">GRADE</th>
                  <th scope="col" className="pb-2 text-center">TREND</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50 font-mono">
                {customers.slice(0, 5).map((c) => (
                  <tr key={c.customer_id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 pl-1 text-center font-bold text-slate-400 text-[11px]">
                      {c.rank}
                    </td>
                    <td className="py-2.5 font-sans font-medium text-slate-200 truncate max-w-[150px]" title={c.customer_name}>
                      {c.customer_name}
                    </td>
                    <td className="py-2.5 text-right font-bold text-slate-100">
                      {c.cei_score.toFixed(1)}
                    </td>
                    <td className="py-2.5 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        c.grade === 'Good' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                        c.grade === 'Needs Improvement' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                        'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      }`}>
                        {c.grade}
                      </span>
                    </td>
                    <td className="py-2.5 text-center text-slate-400 font-semibold text-[11px]">
                      {c.trend === 'UP' ? '▲ UP' : c.trend === 'DOWN' ? '▼ DOWN' : '▬ FLAT'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Footer / Caption */}
      <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-medium text-slate-400">
        <span>Showing {Math.min(5, customers.length)} of {customers.length} Customers</span>
        <span className="font-mono text-slate-400">WS-03.6 PHASE 3F</span>
      </div>
    </div>
  );
};
