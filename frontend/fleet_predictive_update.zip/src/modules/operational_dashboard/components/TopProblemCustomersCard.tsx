import React, { useState } from 'react';
import { useTopProblemCustomers, OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';
import { TopProblemCustomersDrawer } from './TopProblemCustomersDrawer';

export const TopProblemCustomersCard: React.FC = () => {
  const { data, loading, error } = useTopProblemCustomers();
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const customers = data?.data || [];
  const top3 = customers.slice(0, 3);
  const totalCount = data?.total_count || customers.length;
  const isNoObs = data?.status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || customers.length === 0;

  return (
    <>
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between hover:border-slate-700/80 transition-all duration-200">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/60">
            <div>
              <h3 className="text-sm font-bold tracking-tight text-white flex items-center gap-2">
                Top 10 Problem Customers
              </h3>
              <p className="text-[11px] text-slate-400">By Total Lost Hours</p>
            </div>
            <span className="text-[11px] font-semibold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
              Ranked Top 10
            </span>
          </div>

          {/* Body Content */}
          <div className="mt-4 min-h-[160px]">
            {loading ? (
              <div className="space-y-3 animate-pulse py-2">
                <div className="h-4 bg-slate-800 rounded w-full"></div>
                <div className="h-8 bg-slate-800/60 rounded w-full"></div>
                <div className="h-8 bg-slate-800/60 rounded w-full"></div>
                <div className="h-8 bg-slate-800/60 rounded w-full"></div>
              </div>
            ) : error ? (
              <div className="py-6 text-center text-xs text-rose-400 bg-rose-500/5 rounded-lg border border-rose-500/10 p-3">
                <p className="font-semibold">{error}</p>
              </div>
            ) : isNoObs ? (
              <div className="py-10 text-center text-xs text-slate-400 bg-slate-950/30 rounded-lg border border-slate-800/40 p-4">
                No customer observations available for this scope.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800/60">
                    <tr>
                      <th scope="col" className="pb-2">Customer</th>
                      <th scope="col" className="pb-2 text-right">Holding</th>
                      <th scope="col" className="pb-2 text-right">Retention</th>
                      <th scope="col" className="pb-2 text-right text-rose-400 font-bold">Total Lost</th>
                      <th scope="col" className="pb-2 text-right">CEI</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/40 font-mono">
                    {top3.map((c) => (
                      <tr key={c.customer_id} className="hover:bg-slate-800/30 transition-colors">
                        <td className="py-2.5 font-sans font-medium text-slate-200 truncate max-w-[120px]" title={c.customer_name}>
                          {c.customer_name}
                        </td>
                        <td className="py-2.5 text-right text-amber-400">{c.holding_hours.toFixed(1)}h</td>
                        <td className="py-2.5 text-right text-orange-400">{c.retention_hours.toFixed(1)}h</td>
                        <td className="py-2.5 text-right text-rose-400 font-bold">{c.total_lost_hours.toFixed(1)}h</td>
                        <td className="py-2.5 text-right">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            c.cei >= 70 ? 'text-emerald-400 bg-emerald-500/10' :
                            c.cei >= 40 ? 'text-amber-400 bg-amber-500/10' :
                            'text-rose-400 bg-rose-500/10'
                          }`}>
                            {c.cei.toFixed(1)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Footer Action Link */}
        <div className="pt-3 mt-2 border-t border-slate-800/60 flex items-center justify-between">
          <button
            onClick={() => setIsDrawerOpen(true)}
            disabled={loading || !!error || isNoObs}
            className="text-xs font-semibold text-sky-400 hover:text-sky-300 transition-colors flex items-center gap-1 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed"
          >
            View all customers &rarr;
          </button>
          <span className="text-[10px] text-slate-500 font-mono">Top 3 Preview</span>
        </div>
      </div>

      {/* Detail Drawer Overlay */}
      <TopProblemCustomersDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        customers={customers}
        totalCount={totalCount}
      />
    </>
  );
};
