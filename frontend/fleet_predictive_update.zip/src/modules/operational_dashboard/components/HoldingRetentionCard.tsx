import React from 'react';
import ReactECharts from 'echarts-for-react';
import { useHoldingRetention } from '../hooks/useHoldingRetention';
import { OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';

export const HoldingRetentionCard: React.FC = () => {
  const { data, loading, error } = useHoldingRetention();

  const summary = data?.summary;
  const trendPoints = data?.data || [];
  const isNoObs = data?.status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || summary?.total_dispatches === 0;

  // Chart configuration for ECharts 2-series smooth line/area chart
  const getChartOption = () => {
    const hours = trendPoints.map((p) => p.hour_label);
    const holdingMins = trendPoints.map((p) => p.holding_penalty_mins);
    const retentionMins = trendPoints.map((p) => p.retention_penalty_mins);

    return {
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#090d16',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 11, fontFamily: 'monospace' },
        formatter: (params: any[]) => {
          let res = `<div style="font-family:sans-serif;font-weight:bold;margin-bottom:4px;color:#fff;">${params[0]?.name || ''}</div>`;
          params.forEach((item) => {
            const color = item.seriesName === 'Holding Penalty' ? '#fbbf24' : '#fb7185';
            res += `<div style="display:flex;justify-content:space-between;gap:12px;color:${color}; font-size:11px;">
              <span>${item.seriesName}:</span>
              <strong>${item.value}m</strong>
            </div>`;
          });
          return res;
        },
      },
      grid: {
        top: '12%',
        left: '3%',
        right: '4%',
        bottom: '10%',
        containLabel: true,
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: hours,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#64748b', fontSize: 9, fontFamily: 'monospace', interval: 4 },
      },
      yAxis: {
        type: 'value',
        splitLine: { lineStyle: { color: '#1e293b', type: 'dashed' } },
        axisLabel: { color: '#64748b', fontSize: 9, fontFamily: 'monospace', formatter: '{value}m' },
      },
      series: [
        {
          name: 'Holding Penalty',
          type: 'line',
          smooth: true,
          showSymbol: false,
          data: holdingMins,
          lineStyle: { width: 2, color: '#f59e0b' },
          areaStyle: {
            color: {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                { offset: 0, color: 'rgba(245, 158, 11, 0.25)' },
                { offset: 1, color: 'rgba(245, 158, 11, 0.0)' },
              ],
            },
          },
        },
        {
          name: 'Retention Penalty',
          type: 'line',
          smooth: true,
          showSymbol: false,
          data: retentionMins,
          lineStyle: { width: 2, color: '#f43f5e' },
          areaStyle: {
            color: {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                { offset: 0, color: 'rgba(244, 63, 94, 0.25)' },
                { offset: 1, color: 'rgba(244, 63, 94, 0.0)' },
              ],
            },
          },
        },
      ],
    };
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between hover:border-slate-700/80 transition-all duration-200">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800/60">
          <div>
            <h3 className="text-sm font-bold tracking-tight text-white flex items-center gap-2">
              Holding & Retention Overview
            </h3>
            <p className="text-[11px] text-slate-400">24-Hour Delay Distribution / Penalty Ratios</p>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-medium text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
              Holding SLA: 20m
            </span>
            <span className="text-[10px] font-medium text-rose-400 bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/20">
              Retention SLA: 10m
            </span>
          </div>
        </div>

        {/* Body Content */}
        <div className="mt-3">
          {loading ? (
            <div className="space-y-3 animate-pulse py-4">
              <div className="h-4 bg-slate-800 rounded w-full"></div>
              <div className="h-28 bg-slate-800/60 rounded w-full"></div>
            </div>
          ) : error ? (
            <div className="py-6 text-center text-xs text-rose-400 bg-rose-500/5 rounded-lg border border-rose-500/10 p-3">
              <p className="font-semibold">{error}</p>
            </div>
          ) : isNoObs ? (
            <div className="py-6 text-center text-xs text-slate-400 bg-slate-950/30 rounded-lg border border-slate-800/40 p-4">
              No holding & retention observations available for this scope.
            </div>
          ) : (
            <div className="space-y-2">
              {/* Compact Chart Container (Height 120px) */}
              <div className="h-30 w-full" style={{ height: '120px' }}>
                <ReactECharts option={getChartOption()} style={{ height: '100%', width: '100%' }} />
              </div>

              {/* Compact Summary Metrics Footer Bar */}
              <div className="flex items-center justify-between text-[11px] bg-slate-950/50 p-2 rounded-lg border border-slate-800/50 font-mono text-slate-400">
                <div className="flex items-center gap-1">
                  <span>Trips:</span>
                  <strong className="text-white">{summary?.total_dispatches.toLocaleString()}</strong>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-amber-400/80">Holding Pen:</span>
                  <strong className="text-amber-400">{summary?.total_holding_penalty_mins.toLocaleString()}m</strong>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-rose-400/80">Retention Pen:</span>
                  <strong className="text-rose-400">{summary?.total_retention_penalty_mins.toLocaleString()}m</strong>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-emerald-400/80">Lost:</span>
                  <strong className="text-emerald-400">{summary?.total_lost_hours.toFixed(1)}h</strong>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="pt-2 mt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-500">
        <span className="font-medium text-slate-400 flex items-center gap-1">
          Holding vs. Retention Friction Analysis
        </span>
        <span className="text-[10px] text-slate-500 font-mono">24 Hourly Buckets</span>
      </div>
    </div>
  );
};
