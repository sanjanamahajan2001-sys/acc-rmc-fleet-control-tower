import React from 'react';
import { useSiteReadiness, OperationalGradeEnum } from '../hooks/useSiteReadiness';
import { OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';

export const SiteReadinessCard: React.FC = () => {
  const { data, loading, error } = useSiteReadiness();

  const sites = data?.data || [];
  const top3 = sites.slice(0, 3);
  const isNoObs = data?.status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || sites.length === 0;

  const getGradeBadge = (grade: OperationalGradeEnum) => {
    switch (grade) {
      case OperationalGradeEnum.GRADE_A:
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20">A • Optimal</span>;
      case OperationalGradeEnum.GRADE_B:
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-bold text-sky-400 bg-sky-500/10 border border-sky-500/20">B • Good</span>;
      case OperationalGradeEnum.GRADE_C:
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20">C • Warning</span>;
      case OperationalGradeEnum.GRADE_D:
      default:
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-bold text-rose-400 bg-rose-500/10 border border-rose-500/20">D • Critical</span>;
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between hover:border-slate-700/80 transition-all duration-200">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800/60">
          <div>
            <h3 className="text-sm font-bold tracking-tight text-white flex items-center gap-2">
              Site Readiness Index
            </h3>
            <p className="text-[11px] text-slate-400">Composite Operational Grade</p>
          </div>
          <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
            SRI Evaluated
          </span>
        </div>

        {/* Body Content */}
        <div className="mt-4 min-h-[160px]">
          {loading ? (
            <div className="space-y-3 animate-pulse py-2">
              <div className="h-4 bg-slate-800 rounded w-full"></div>
              <div className="h-8 bg-slate-800/60 rounded w-full"></div>
              <div className="h-8 bg-slate-800/60 rounded w-full"></div>
              <div className="h-8 bg-slate-800/60 rounded w-full"></div>
            </div>
          ) : error ? (
            <div className="py-6 text-center text-xs text-rose-400 bg-rose-500/5 rounded-lg border border-rose-500/10 p-3">
              <p className="font-semibold">{error}</p>
            </div>
          ) : isNoObs ? (
            <div className="py-10 text-center text-xs text-slate-400 bg-slate-950/30 rounded-lg border border-slate-800/40 p-4">
              No site readiness observations available for this scope.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800/60">
                  <tr>
                    <th scope="col" className="pb-2">Site / Customer</th>
                    <th scope="col" className="pb-2 text-right">Trips</th>
                    <th scope="col" className="pb-2 text-right">SWI / DPI / FUI</th>
                    <th scope="col" className="pb-2 text-right text-emerald-400 font-bold">SRI Score</th>
                    <th scope="col" className="pb-2 text-right">Grade</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40 font-mono">
                  {top3.map((s) => (
                    <tr key={s.site_id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-2.5 font-sans font-medium text-slate-200 truncate max-w-[110px]" title={s.site_name}>
                        {s.site_name}
                      </td>
                      <td className="py-2.5 text-right text-slate-400">{s.total_trips.toLocaleString()}</td>
                      <td className="py-2.5 text-right text-slate-400 text-[10px]">
                        {s.swi_site.toFixed(1)} / {s.dpi_site.toFixed(1)} / {s.fui_site.toFixed(1)}
                      </td>
                      <td className="py-2.5 text-right text-emerald-400 font-bold">
                        <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/10 border border-emerald-500/20">
                          {s.sri_score.toFixed(1)}
                        </span>
                      </td>
                      <td className="py-2.5 text-right">
                        {getGradeBadge(s.grade)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Footer Action Link */}
      <div className="pt-3 mt-2 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-500">
        <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
          Ranked by Lowest SRI (Intervention First)
        </span>
        <span className="text-[10px] text-slate-500 font-mono">Top 3 Preview</span>
      </div>
    </div>
  );
};
