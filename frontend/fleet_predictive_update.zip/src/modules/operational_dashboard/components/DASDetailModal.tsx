import React, { useEffect } from 'react';
import { DASSummaryDTO, DASBucketBreakdownDTO } from '../hooks/useDASOverview';
import { DASDetailRowDTO } from '../hooks/useDASDetails';

interface DASDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary?: DASSummaryDTO | null;
  buckets?: DASBucketBreakdownDTO | null;
  detailRows?: DASDetailRowDTO[];
  hasDetailApi?: boolean;
  isLoading?: boolean;
}

export const DASDetailModal: React.FC<DASDetailModalProps> = ({
  isOpen,
  onClose,
  summary,
  buckets,
  detailRows = [],
  hasDetailApi = true,
  isLoading = false,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const isNoObs = !summary || summary.total_dispatches === 0 || summary.das_score === null;

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden bg-slate-950/70 backdrop-blur-sm flex justify-end transition-opacity duration-300"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-4xl bg-slate-900 border-l border-slate-800 text-slate-100 flex flex-col h-full shadow-2xl animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="p-6 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/50">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight text-white">DISPATCH ACCURACY DETAILS</h2>
              {summary?.operational_status && !isNoObs && (
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase tracking-wider ${
                    summary.operational_status === 'OPTIMAL'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : summary.operational_status === 'WARNING'
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                  }`}
                >
                  {summary.operational_status}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Site Holding Compliance &amp; Delay Classification (SLA: &le;20.0m)
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors focus:outline-none focus:ring-2 focus:ring-slate-700"
            aria-label="Close Modal"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Section A: Summary KPI Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-3.5 flex flex-col">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">DAS Score</span>
              <span className="text-xl font-extrabold text-white font-mono mt-1">
                {summary?.das_score !== null && summary?.das_score !== undefined ? `${summary.das_score.toFixed(1)}%` : '--'}
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5">Target: {summary?.target_sla.toFixed(0)}%</span>
            </div>

            <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-3.5 flex flex-col">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Total Dispatches</span>
              <span className="text-xl font-extrabold text-slate-200 font-mono mt-1">
                {summary?.total_dispatches ? summary.total_dispatches.toLocaleString() : '0'}
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5">All Completed Trips</span>
            </div>

            <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-3.5 flex flex-col">
              <span className="text-[10px] text-emerald-400 uppercase tracking-wider font-semibold">Within 20m</span>
              <span className="text-xl font-extrabold text-emerald-400 font-mono mt-1">
                {buckets?.within_20m_pct !== undefined ? `${buckets.within_20m_pct.toFixed(1)}%` : '0.0%'}
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5">({buckets?.within_20m_count ? buckets.within_20m_count.toLocaleString() : 0} trips)</span>
            </div>

            <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-3.5 flex flex-col">
              <span className="text-[10px] text-amber-400 uppercase tracking-wider font-semibold">20&ndash;40m</span>
              <span className="text-xl font-extrabold text-amber-400 font-mono mt-1">
                {buckets?.moderate_20_40m_pct !== undefined ? `${buckets.moderate_20_40m_pct.toFixed(1)}%` : '0.0%'}
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5">({buckets?.moderate_20_40m_count ? buckets.moderate_20_40m_count.toLocaleString() : 0} trips)</span>
            </div>

            <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-3.5 flex flex-col">
              <span className="text-[10px] text-rose-400 uppercase tracking-wider font-semibold">&gt;40m</span>
              <span className="text-xl font-extrabold text-rose-400 font-mono mt-1">
                {buckets?.critical_above_40m_pct !== undefined ? `${buckets.critical_above_40m_pct.toFixed(1)}%` : '0.0%'}
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5">({buckets?.critical_above_40m_count ? buckets.critical_above_40m_count.toLocaleString() : 0} trips)</span>
            </div>
          </div>

          {/* Section B: Detail Breakdown Table */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>Customer DAS Breakdown</span>
              {detailRows.length > 0 && (
                <span className="text-[11px] font-mono text-slate-500 font-normal">
                  Showing {detailRows.length} customer records
                </span>
              )}
            </h3>

            {isNoObs ? (
              <div className="py-12 text-center text-slate-400 text-sm bg-slate-950/40 border border-slate-800 rounded-xl">
                No dispatch accuracy observations available for this filter scope.
              </div>
            ) : isLoading ? (
              <div className="py-12 text-center text-slate-400 text-sm bg-slate-950/40 border border-slate-800 rounded-xl">
                Loading customer DAS breakdown...
              </div>
            ) : !hasDetailApi ? (
              <div className="p-5 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 text-xs space-y-2">
                <div className="flex items-center gap-2 font-bold text-amber-400">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  <span>Backend Detail API Contract Required</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  Summary DAS metrics are rendered above directly from the backend <code className="font-mono text-slate-200">GET /fleet-api/v1/operational-dashboard/das-overview</code> DTO contract.
                </p>
              </div>
            ) : detailRows.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-sm bg-slate-950/40 border border-slate-800 rounded-xl">
                No customer records found for this scope.
              </div>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/40">
                <table className="w-full text-left text-xs text-slate-300 min-w-[700px]">
                  <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                    <tr>
                      <th scope="col" className="px-3 py-3 w-12 text-center">Rank</th>
                      <th scope="col" className="px-3 py-3">Customer</th>
                      <th scope="col" className="px-3 py-3 text-right">Trips</th>
                      <th scope="col" className="px-3 py-3 text-right text-emerald-400">&le;20m</th>
                      <th scope="col" className="px-3 py-3 text-right text-amber-400">20&ndash;40m</th>
                      <th scope="col" className="px-3 py-3 text-right text-rose-400">&gt;40m</th>
                      <th scope="col" className="px-3 py-3 text-right font-bold text-sky-400">DAS Score</th>
                      <th scope="col" className="px-3 py-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {detailRows.map((row) => (
                      <tr key={row.customer_id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="px-3 py-3 text-center text-slate-500 font-mono text-[11px]">{row.rank}</td>
                        <td className="px-3 py-3 font-sans font-medium text-slate-200">{row.customer_name}</td>
                        <td className="px-3 py-3 text-right text-slate-400">{row.total_dispatches.toLocaleString()}</td>
                        <td className="px-3 py-3 text-right text-emerald-400">{row.accurate_count.toLocaleString()}</td>
                        <td className="px-3 py-3 text-right text-amber-400">{row.moderate_count.toLocaleString()}</td>
                        <td className="px-3 py-3 text-right text-rose-400">{row.critical_count.toLocaleString()}</td>
                        <td className="px-3 py-3 text-right font-bold text-sky-400">{row.das_score.toFixed(1)}%</td>
                        <td className="px-3 py-3 text-center">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              row.operational_status === 'OPTIMAL'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : row.operational_status === 'WARNING'
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            }`}
                          >
                            {row.operational_status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800/80 bg-slate-900/50 flex justify-between items-center">
          <span className="text-[11px] text-slate-500 font-mono">WS-03.4 Dispatch Accuracy Score (DAS)</span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
