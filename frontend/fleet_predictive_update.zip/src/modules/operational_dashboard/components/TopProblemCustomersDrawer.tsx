import React from 'react';
import { ProblemCustomerDTO } from '../hooks/useTopProblemCustomers';

interface TopProblemCustomersDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  customers: ProblemCustomerDTO[];
  totalCount: number;
}

export const TopProblemCustomersDrawer: React.FC<TopProblemCustomersDrawerProps> = ({
  isOpen,
  onClose,
  customers,
  totalCount,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/70 backdrop-blur-sm flex justify-end transition-opacity duration-300">
      <div className="w-full max-w-4xl bg-slate-900 border-l border-slate-800 text-slate-100 flex flex-col h-full shadow-2xl animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="p-6 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/50">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight text-white">Top 10 Problem Customers</h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                {totalCount} Total
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Ranked by Total Lost Hours (Holding &gt; 20m + Retention &gt; 10m)
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors focus:outline-none focus:ring-2 focus:ring-slate-700"
            aria-label="Close Drawer"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content Table */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {customers.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm">
              No customer observations available for this scope.
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/40">
              <table className="w-full text-left text-xs text-slate-300 min-w-[700px]">
                <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                  <tr>
                    <th scope="col" className="px-3 py-3 text-center w-12">Rank</th>
                    <th scope="col" className="px-3 py-3">Customer</th>
                    <th scope="col" className="px-3 py-3 text-right">Trips</th>
                    <th scope="col" className="px-3 py-3 text-right">Holding (h)</th>
                    <th scope="col" className="px-3 py-3 text-right">Retention (h)</th>
                    <th scope="col" className="px-3 py-3 text-right text-rose-400 font-bold">Total Lost (h)</th>
                    <th scope="col" className="px-3 py-3 text-right font-bold text-sky-400">CEI</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {customers.map((c) => (
                    <tr key={c.customer_id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="px-3 py-3.5 text-center font-bold text-slate-400">#{c.rank}</td>
                      <td className="px-3 py-3.5 font-sans font-medium text-slate-200 truncate max-w-[180px]" title={c.customer_name}>
                        {c.customer_name}
                      </td>
                      <td className="px-3 py-3.5 text-right text-slate-400">{c.total_trips.toLocaleString()}</td>
                      <td className="px-3 py-3.5 text-right text-amber-400 font-medium">{c.holding_hours.toFixed(1)}h</td>
                      <td className="px-3 py-3.5 text-right text-orange-400 font-medium">{c.retention_hours.toFixed(1)}h</td>
                      <td className="px-3 py-3.5 text-right text-rose-400 font-bold text-sm">
                        {c.total_lost_hours.toFixed(1)}h
                      </td>
                      <td className="px-3 py-3.5 text-right">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          c.cei >= 70 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                          c.cei >= 40 ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                          'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}>
                          {c.cei.toFixed(1)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800/80 bg-slate-900/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
