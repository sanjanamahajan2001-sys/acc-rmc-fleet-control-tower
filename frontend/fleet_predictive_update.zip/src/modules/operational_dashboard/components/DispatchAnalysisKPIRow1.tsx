import React from 'react';
import { useDispatchAnalysisKPIs } from '../hooks/useDispatchAnalysisKPIs';
import { OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';
import { CheckCircle2, Clock, Activity, Target, ShieldCheck, AlertTriangle } from 'lucide-react';

export const DispatchAnalysisKPIRow1: React.FC = () => {
  const { data, loading, error, status } = useDispatchAnalysisKPIs();

  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {[1, 2, 3, 4, 5].map((idx) => (
          <div
            key={idx}
            className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 animate-pulse h-32 flex flex-col justify-between"
          >
            <div className="h-4 bg-slate-800 rounded w-2/3"></div>
            <div className="h-8 bg-slate-800 rounded w-1/2 mt-2"></div>
            <div className="h-3 bg-slate-800 rounded w-1/3"></div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-3">
        <AlertTriangle className="w-5 h-5 shrink-0 text-rose-400" />
        <span>Failed to load KPI Ribbon data: {error}</span>
      </div>
    );
  }

  if (status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || !data) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">TOTAL DISPATCHES</span>
          <div className="text-2xl font-bold text-slate-100 mt-2">0 <span className="text-xs text-slate-500 font-normal">Trips</span></div>
          <span className="text-[10px] text-slate-500 block mt-1">NO OBSERVATIONS</span>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">ON-SCHEDULE DISPATCHES</span>
          <div className="text-2xl font-bold text-slate-100 mt-2">0 / 0</div>
          <span className="text-[10px] text-slate-500 block mt-1">NO OBSERVATIONS</span>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">SLA COMPLIANCE</span>
          <div className="text-2xl font-bold text-slate-100 mt-2">— %</div>
          <span className="text-[10px] text-slate-500 block mt-1">NO OBSERVATIONS</span>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">AVG INTERVAL / VARIANCE</span>
          <div className="text-2xl font-bold text-slate-100 mt-2">— / —</div>
          <span className="text-[10px] text-slate-500 block mt-1">NO OBSERVATIONS</span>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">DISPATCH ACCURACY</span>
          <div className="text-2xl font-bold text-slate-100 mt-2">— %</div>
          <span className="text-[10px] text-slate-500 block mt-1">NO OBSERVATIONS</span>
        </div>
      </div>
    );
  }

  const getStatusBadge = (cadenceStatus: string) => {
    switch (cadenceStatus) {
      case 'Optimal':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase">OPTIMAL</span>;
      case 'Good':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 uppercase">GOOD</span>;
      case 'Warning':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 uppercase">WARNING</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 uppercase">CRITICAL</span>;
    }
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
      {/* KPI #1: TOTAL DISPATCHES */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-slate-700 transition">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">TOTAL DISPATCHES</span>
          <Activity className="w-4 h-4 text-indigo-400 shrink-0" />
        </div>
        <div className="mt-3">
          <div className="text-2xl font-bold text-slate-100">
            {data.total_dispatches.toLocaleString()}{' '}
            <span className="text-xs font-normal text-slate-400">Trips</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">PostgreSQL Canonical Aggregate</p>
        </div>
      </div>

      {/* KPI #2: ON-SCHEDULE DISPATCHES */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-slate-700 transition">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">ON-SCHEDULE DISPATCHES</span>
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
        </div>
        <div className="mt-3">
          <div className="text-2xl font-bold text-slate-100">
            {data.on_schedule_dispatches.toLocaleString()}{' '}
            <span className="text-xs font-normal text-slate-500">/ {data.total_dispatches.toLocaleString()}</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Holding &le; 20m &amp; Retention &le; 10m</p>
        </div>
      </div>

      {/* KPI #3: SLA COMPLIANCE */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-slate-700 transition">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">SLA COMPLIANCE</span>
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
        </div>
        <div className="mt-3">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-100">{data.sla_compliance_pct.toFixed(1)}%</span>
            {getStatusBadge(data.cadence_status)}
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Certified SLA Target: 80%</p>
        </div>
      </div>

      {/* KPI #4: AVG INTERVAL / VARIANCE */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-slate-700 transition">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">AVG INTERVAL / VARIANCE</span>
          <Clock className="w-4 h-4 text-amber-400 shrink-0" />
        </div>
        <div className="mt-3">
          <div className="text-2xl font-bold text-slate-100">
            {data.avg_interval_mins.toFixed(1)}{' '}
            <span className="text-xs font-normal text-slate-400">min / {data.interval_variance_mins.toFixed(1)} min</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Mean Cadence &amp; StdDev Spacing</p>
        </div>
      </div>

      {/* KPI #5: DISPATCH ACCURACY */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-slate-700 transition">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">DISPATCH ACCURACY</span>
          <Target className="w-4 h-4 text-indigo-400 shrink-0" />
        </div>
        <div className="mt-3">
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-100">{data.das_score_pct.toFixed(1)}%</span>
            <span className="text-[10px] text-indigo-400 font-mono">WS-03.4 DAS</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Certified DAS Engine Weighted Metric</p>
        </div>
      </div>
    </div>
  );
};
