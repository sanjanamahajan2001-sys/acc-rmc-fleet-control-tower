import React, { useMemo, useRef, useState, useEffect } from 'react';
import { Info } from 'lucide-react';

export interface MetricDeltaDTO {
  metric_name: string;
  observed_baseline: number;
  optimized_value: number;
  net_delta: number;
  percentage_change: number;
  unit: string;
}

export interface BeforeAfterImpactMatrixDTO {
  sla_compliance: MetricDeltaDTO;
  dispatch_accuracy_das: MetricDeltaDTO;
  cumulative_delay_hours: MetricDeltaDTO;
  plant_holding_delay_hours: MetricDeltaDTO;
  site_retention_delay_hours: MetricDeltaDTO;
  sequence_variance_delay_hours: MetricDeltaDTO;
}

export interface RecommendationReasonDTO {
  recommendation_reason_code: string;
  explanation: string;
  baseline_departure_iso: string;
  recommended_departure_iso: string;
  shift_minutes: number;
  objective_type: string;
  constraints_satisfied: boolean;
  expected_sla_delta: number;
  expected_delay_delta_hours: number;
  solver_policy_version: string;
}

export interface DispatchGanttItemDTO {
  dispatch_id: string;
  dispatch_number: string;
  vehicle_id: string;
  plant_id: string;
  customer_id: string;
  raw_time_out: string;
  raw_time_in: string;
  baseline_time_out_iso: string;
  baseline_time_in_iso: string;
  recommended_time_out_iso: string;
  recommended_time_in_iso: string;
  time_shift_mins: number;
  t1_transit_mins: number;
  t2a_holding_mins: number;
  t2c_retention_mins: number;
  sequence_order: number;
  recommendation_reason?: RecommendationReasonDTO;
}

export interface CandidateScenarioDTO {
  scenario_id: string;
  scenario_name: string;
  objective_type: string;
  pareto_score: number;
  is_recommended: boolean;
  impact_matrix: BeforeAfterImpactMatrixDTO;
  constraint_violations_count: number;
  constraint_notes: string[];
  gantt_items?: DispatchGanttItemDTO[];
}

export interface DispatchOptimizationGanttProps {
  readiness: any;
  scenarios: CandidateScenarioDTO[];
  selectedScenarioId?: string;
  ganttData?: {
    optimization_run_id: string;
    scenario_id: string;
    items: DispatchGanttItemDTO[];
  } | null;
  isLoading?: boolean;
  isStale?: boolean;
  onScenarioSelect?: (scenarioId: string) => void;
}

// Operator-facing reason code dictionary map
const OPERATOR_REASON_CODE_MAP: Record<string, string> = {
  OPTIMAL_HISTORICAL_SPACING: 'Historical spacing already satisfies operational constraints.',
  PLANT_HOLDING_BOTTLENECK_REDUCTION: 'Plant holding bottleneck reduction.',
  DEPARTURE_GAP_SPACING_ENFORCED: 'Minimum departure spacing gap enforced.',
};

export const DispatchOptimizationGantt: React.FC<DispatchOptimizationGanttProps> = ({
  readiness,
  scenarios,
  selectedScenarioId,
  ganttData,
  isLoading = false,
  isStale = false,
  onScenarioSelect,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [visibleCount, setVisibleCount] = useState<number>(50);
  const [activeReasonItem, setActiveReasonItem] = useState<DispatchGanttItemDTO | null>(null);

  // Reset visible window count when scenario or dataset items change
  useEffect(() => {
    setVisibleCount(50);
    setActiveReasonItem(null);
  }, [selectedScenarioId, ganttData?.items]);

  const activeScenario = useMemo(() => {
    if (!scenarios || scenarios.length === 0) return null;
    if (!selectedScenarioId) return scenarios.find((s) => s.is_recommended) || scenarios[0];
    return scenarios.find((s) => s.scenario_id === selectedScenarioId) || scenarios[0];
  }, [scenarios, selectedScenarioId]);

  const items = useMemo(() => {
    return ganttData?.items || activeScenario?.gantt_items || [];
  }, [ganttData, activeScenario]);

  // Group real dispatches by plant location
  const plantGroups = useMemo(() => {
    const groups: Record<string, DispatchGanttItemDTO[]> = {};
    items.forEach((item) => {
      const p = item.plant_id || 'UNKNOWN';
      if (!groups[p]) groups[p] = [];
      groups[p].push(item);
    });
    return groups;
  }, [items]);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    if (scrollHeight - scrollTop - clientHeight < 200 && visibleCount < items.length) {
      setVisibleCount((prev) => Math.min(prev + 50, items.length));
    }
  };

  if (isLoading) {
    return (
      <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-lg text-slate-400" data-testid="gantt-loading">
        <div className="animate-spin inline-block w-6 h-6 border-2 border-current border-t-transparent text-cyan-400 rounded-full mb-2" />
        <p>Loading Optimization Scenarios &amp; Cadence Timeline...</p>
      </div>
    );
  }

  if (readiness?.status === 'NO_OBSERVATIONS' || (!items.length && !isLoading)) {
    return (
      <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-lg text-slate-400" data-testid="gantt-no-observations">
        <h3 className="text-lg font-semibold text-slate-200 mb-1">NO OPTIMIZATION OBSERVATIONS</h3>
        <p className="text-sm">No operational dispatches found for the selected filter scope.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 bg-slate-950 p-6 rounded-xl border border-slate-800" data-testid="gantt-container">
      {/* Header & Badges */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-xl font-bold text-slate-100">Dispatch Cadence &amp; Optimization Timeline</h2>
            
            {isStale && (
              <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/30" data-testid="gantt-stale-badge">
                Optimization plan is out of date — ERP refresh required
              </span>
            )}
            
            {readiness?.status === 'DEGRADED' && (
              <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-orange-500/20 text-orange-400 border border-orange-500/30" data-testid="gantt-degraded-badge">
                Input data quality degraded
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Comparing Baseline Historical Dispatches vs. Recommended Optimized Schedule
          </p>
        </div>

        {scenarios.length > 0 && (
          <div className="flex items-center gap-2">
            <label className="text-xs font-medium text-slate-400">Selected Scenario:</label>
            <select
              value={activeScenario?.scenario_id || ''}
              onChange={(e) => onScenarioSelect && onScenarioSelect(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded px-3 py-1.5 focus:outline-none focus:border-cyan-500 font-semibold"
              data-testid="scenario-selector"
            >
              {scenarios.map((s) => (
                <option key={s.scenario_id} value={s.scenario_id}>
                  {s.scenario_name} - Score: {s.pareto_score}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Impact Summary Ribbon */}
      {activeScenario?.impact_matrix && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3" data-testid="impact-matrix-ribbon">
          <div className="bg-slate-900 p-3 rounded border border-slate-800">
            <div className="text-[10px] uppercase font-semibold text-slate-500">SLA Compliance</div>
            <div className="text-lg font-bold text-emerald-400">
              {activeScenario.impact_matrix.sla_compliance.optimized_value}%
            </div>
            <div className="text-[11px] text-emerald-500/90 font-medium">
              +{activeScenario.impact_matrix.sla_compliance.net_delta}% vs Baseline
            </div>
          </div>
          <div className="bg-slate-900 p-3 rounded border border-slate-800">
            <div className="text-[10px] uppercase font-semibold text-slate-500">DAS Score</div>
            <div className="text-lg font-bold text-cyan-400">
              {activeScenario.impact_matrix.dispatch_accuracy_das.optimized_value}%
            </div>
            <div className="text-[11px] text-cyan-500/90 font-medium">
              +{activeScenario.impact_matrix.dispatch_accuracy_das.net_delta}% vs Baseline
            </div>
          </div>
          <div className="bg-slate-900 p-3 rounded border border-slate-800">
            <div className="text-[10px] uppercase font-semibold text-slate-500">Total Delay</div>
            <div className="text-lg font-bold text-indigo-400">
              {activeScenario.impact_matrix.cumulative_delay_hours.optimized_value} hrs
            </div>
            <div className="text-[11px] text-indigo-400/90 font-medium">
              {activeScenario.impact_matrix.cumulative_delay_hours.net_delta} hrs vs Baseline
            </div>
          </div>
          <div className="bg-slate-900 p-3 rounded border border-slate-800">
            <div className="text-[10px] uppercase font-semibold text-slate-500">Holding Delay</div>
            <div className="text-lg font-bold text-amber-400">
              {activeScenario.impact_matrix.plant_holding_delay_hours.optimized_value} hrs
            </div>
            <div className="text-[11px] text-amber-500/90 font-medium">
              {activeScenario.impact_matrix.plant_holding_delay_hours.net_delta} hrs vs Baseline
            </div>
          </div>
          <div className="bg-slate-900 p-3 rounded border border-slate-800">
            <div className="text-[10px] uppercase font-semibold text-slate-500">Retention Delay</div>
            <div className="text-lg font-bold text-rose-400">
              {activeScenario.impact_matrix.site_retention_delay_hours.optimized_value} hrs
            </div>
            <div className="text-[11px] text-rose-500/90 font-medium">
              {activeScenario.impact_matrix.site_retention_delay_hours.net_delta} hrs vs Baseline
            </div>
          </div>
          <div className="bg-slate-900 p-3 rounded border border-slate-800">
            <div className="text-[10px] uppercase font-semibold text-slate-500">Seq Variance</div>
            <div className="text-lg font-bold text-purple-400">
              {activeScenario.impact_matrix.sequence_variance_delay_hours.optimized_value} hrs
            </div>
            <div className="text-[11px] text-purple-400/90 font-medium">
              {activeScenario.impact_matrix.sequence_variance_delay_hours.net_delta} hrs vs Baseline
            </div>
          </div>
        </div>
      )}

      {/* Operator-Facing Optimization Reason Popover Card */}
      {activeReasonItem && activeReasonItem.recommendation_reason && (
        <div className="p-4 bg-slate-900 border border-cyan-500/30 rounded-xl space-y-2 text-xs" data-testid="recommendation-explanation-card">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-cyan-400 font-bold">
              <Info size={16} />
              <span>Optimization Reason ({activeReasonItem.dispatch_number})</span>
            </div>
            <button onClick={() => setActiveReasonItem(null)} className="text-slate-400 hover:text-slate-200">Dismiss</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 text-slate-300">
            <div>
              <span className="text-slate-500 block">Reason Summary:</span>
              <span className="font-semibold text-emerald-400">
                {OPERATOR_REASON_CODE_MAP[activeReasonItem.recommendation_reason.recommendation_reason_code] ||
                  activeReasonItem.recommendation_reason.recommendation_reason_code}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Expected Delay Impact:</span>
              <span className="font-mono text-amber-300">{activeReasonItem.recommendation_reason.expected_delay_delta_hours} hrs</span>
            </div>
          </div>
          <p className="text-slate-400 italic pt-1">&ldquo;{activeReasonItem.recommendation_reason.explanation}&rdquo;</p>
        </div>
      )}

      {/* Windowed Timeline Container */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="h-[500px] overflow-auto space-y-6"
        data-testid="virtualized-gantt-scroll-container"
      >
        {Object.entries(plantGroups).map(([plantId, plantItems]) => (
          <div key={plantId} className="bg-slate-900/60 rounded-lg p-4 border border-slate-800" data-testid={`plant-group-${plantId}`}>
            <h3 className="text-sm font-semibold text-cyan-400 uppercase tracking-wider mb-3">
              Plant Location: {plantId} ({plantItems.length} Dispatches {plantItems.length > visibleCount ? `— Showing first ${visibleCount}` : ''})
            </h3>
            <div className="space-y-3">
              {plantItems.slice(0, visibleCount).map((item) => (
                <div
                  key={item.dispatch_id}
                  className="bg-slate-900 p-3 rounded border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                  data-testid={`dispatch-item-${item.dispatch_id}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-slate-300 font-semibold">{item.dispatch_number}</span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">Vehicle: {item.vehicle_id}</span>
                    <span className="text-slate-400">Customer: {item.customer_id}</span>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="text-right font-mono">
                      <div className="text-[10px] text-slate-500 uppercase">Baseline Dep / Ret</div>
                      <div className="text-slate-300">{item.raw_time_out} &rarr; {item.raw_time_in}</div>
                    </div>
                    <div className="text-right font-mono">
                      <div className="text-[10px] text-cyan-400 uppercase">Recommended Dep</div>
                      <div className="text-cyan-300 font-bold">{item.recommended_time_out_iso.split('T')[1]?.replace('Z', '') || '08:15:00'}</div>
                    </div>
                    <div className="px-2.5 py-1 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-semibold text-[11px]">
                      Shift: +{item.time_shift_mins}m
                    </div>
                    {item.recommendation_reason && (
                      <button
                        onClick={() => setActiveReasonItem(item)}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded text-[10px] font-semibold border border-slate-700 flex items-center gap-1"
                        title="View Optimization Explanation"
                        data-testid={`why-btn-${item.dispatch_id}`}
                      >
                        <Info size={12} />
                        <span>WHY?</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
