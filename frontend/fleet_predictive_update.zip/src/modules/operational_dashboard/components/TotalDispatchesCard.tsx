import React from 'react';
import { Package, HelpCircle } from 'lucide-react';
import { KPICardItemDTO, AvailabilityEnum } from '../hooks/useExecutiveKPIs';

interface TotalDispatchesCardProps {
  data: KPICardItemDTO;
  loading?: boolean;
}

export const TotalDispatchesCard: React.FC<TotalDispatchesCardProps> = ({ data, loading }) => {
  if (loading) {
    return (
      <div
        data-testid="total-dispatches-card-loading"
        className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl animate-pulse space-y-4"
      >
        <div className="flex items-center justify-between">
          <div className="h-4 w-32 bg-slate-800 rounded" />
          <div className="h-5 w-16 bg-slate-800 rounded-full" />
        </div>
        <div className="h-8 w-24 bg-slate-800 rounded" />
        <div className="h-4 w-40 bg-slate-800 rounded" />
      </div>
    );
  }

  const isAvailable = data.availability === AvailabilityEnum.AVAILABLE && data.current_value !== null;

  return (
    <div
      data-testid="total-dispatches-card"
      className="bg-slate-900/90 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-5 shadow-xl transition space-y-3 flex flex-col justify-between"
    >
      {/* Header Row: Label & Status Badge (NEUTRAL per Phase 6 Contract) */}
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <Package className="w-3.5 h-3.5 text-blue-400" />
          {data.label}
        </span>
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold border tracking-wider bg-slate-800 text-slate-400 border-slate-700">
          NEUTRAL
        </span>
      </div>

      {/* Main Value Row: Formatted Integer Dispatches Count */}
      <div className="flex items-baseline justify-between gap-2">
        {isAvailable ? (
          <div className="flex items-baseline space-x-1">
            <span className="text-3xl font-extrabold text-slate-100 tracking-tight">
              {Number(data.current_value).toLocaleString('en-US')}
            </span>
            <span className="text-sm font-semibold text-slate-400">{data.unit || 'Trips'}</span>
          </div>
        ) : (
          <div className="flex items-center space-x-2 text-slate-400">
            <span className="text-2xl font-bold">N/A</span>
            <span className="text-xs bg-slate-800 px-2 py-0.5 rounded text-slate-400 font-mono">
              NO OBSERVATIONS
            </span>
          </div>
        )}
      </div>

      {/* Footer Metadata Row: Volume Contract (SOURCE_UNAVAILABLE per Section 2.5) & Target/Variance N/A */}
      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-medium text-slate-400">
        <div className="flex items-center space-x-1.5">
          <span>Volume: </span>
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-800/90 text-amber-400/90 font-mono text-[10px] border border-amber-500/20">
            <HelpCircle className="w-3 h-3 text-amber-400" />
            N/A (Source Unavailable)
          </span>
        </div>
        <div className="text-slate-400 text-[11px]">
          Target: <span className="text-slate-400">N/A</span>
        </div>
      </div>
    </div>
  );
};
