import React from 'react';
import { TopProblemCustomersCard } from './TopProblemCustomersCard';
import { OverlapHeatMapCard } from './OverlapHeatMapCard';
import { SiteReadinessCard } from './SiteReadinessCard';
import { HoldingRetentionCard } from './HoldingRetentionCard';
import { DASOverviewCard } from './DASOverviewCard';
import { PotentialImpactPlanningCard } from './PotentialImpactPlanningCard';
import { CustomerEfficiencyIndexCard } from './CustomerEfficiencyIndexCard';

interface OperationalIntelligenceGridProps {
  onOpenDASDetailModal?: () => void;
}

export const OperationalIntelligenceGrid: React.FC<OperationalIntelligenceGridProps> = ({
  onOpenDASDetailModal,
}) => {
  return (
    <div className="space-y-5">
      {/* 3-Column Grid for Row A & Row B & Row C */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Column 1: Top 10 Problem Customers (Row A) & Holding Retention Overview (Row B) */}
        <div className="flex flex-col gap-5">
          <TopProblemCustomersCard />
          <HoldingRetentionCard />
          {/* Row C Column 1: Recent Alerts [DEFERRED] */}
          <div className="hidden lg:block"></div>
        </div>

        {/* Column 2: Overlap Heat Map (Row A), DAS Overview (Row B), CEI Card (Row C) */}
        <div className="flex flex-col gap-5">
          <OverlapHeatMapCard />
          <DASOverviewCard onOpenDetailModal={onOpenDASDetailModal} />
          <CustomerEfficiencyIndexCard />
        </div>

        {/* Column 3: Site Readiness Index (Row A) & Potential Impact of Better Planning (Row B) */}
        <div className="flex flex-col gap-5">
          <SiteReadinessCard />
          <PotentialImpactPlanningCard />
          {/* Row C Column 3: Today's Summary [FUTURE] */}
          <div className="hidden lg:block"></div>
        </div>
      </div>
    </div>
  );
};




