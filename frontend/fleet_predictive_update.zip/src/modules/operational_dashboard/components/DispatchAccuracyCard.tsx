import React from 'react';
import { Target, TrendingUp, TrendingDown } from 'lucide-react';
import { KPICardItemDTO, KPIStatusEnum, AvailabilityEnum } from '../hooks/useExecutiveKPIs';

interface DispatchAccuracyCardProps {
  data: KPICardItemDTO;
  loading?: boolean;
}

export const DispatchAccuracyCard: React.FC<DispatchAccuracyCardProps> = ({ data, loading }) => {
  if (loading) {
    return (
      <div
        data-testid="dispatch-accuracy-card-loading"
        className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl animate-pulse space-y-4"
      >
        <div className="flex items-center justify-between">
          <div className="h-4 w-32 bg-slate-800 rounded" />
          <div className="h-5 w-16 bg-slate-800 rounded-full" />
        </div>
        <div className="h-8 w-24 bg-slate-800 rounded" />
        <div className="h-4 w-40 bg-slate-800 rounded" />
      </div>
    );
  }

  const isAvailable = data.availability === AvailabilityEnum.AVAILABLE && data.current_value !== null;

  // Status Badge styling based on backend status enum
  const getStatusBadge = () => {
    switch (data.status) {
      case KPIStatusEnum.OPTIMAL:
        return {
          label: 'OPTIMAL',
          className: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
        };
      case KPIStatusEnum.WARNING:
        return {
          label: 'WARNING',
          className: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
        };
      case KPIStatusEnum.CRITICAL:
        return {
          label: 'CRITICAL',
          className: 'bg-rose-500/15 text-rose-400 border-rose-500/30',
        };
      case KPIStatusEnum.NEUTRAL:
      default:
        return {
          label: 'NEUTRAL',
          className: 'bg-slate-800 text-slate-400 border-slate-700',
        };
    }
  };

  const statusBadge = getStatusBadge();

  return (
    <div
      data-testid="dispatch-accuracy-card"
      className="bg-slate-900/90 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-5 shadow-xl transition space-y-3 flex flex-col justify-between"
    >
      {/* Header Row: Label & Backend Status Badge */}
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <Target className="w-3.5 h-3.5 text-indigo-400" />
          {data.label}
        </span>
        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border tracking-wider ${statusBadge.className}`}>
          {statusBadge.label}
        </span>
      </div>

      {/* Main KPI Value Row */}
      <div className="flex items-baseline justify-between gap-2">
        {isAvailable ? (
          <div className="flex items-baseline space-x-1">
            <span className="text-3xl font-extrabold text-slate-100 tracking-tight">
              {data.current_value}
            </span>
            <span className="text-sm font-semibold text-slate-400">{data.unit}</span>
          </div>
        ) : (
          <div className="flex items-center space-x-2 text-slate-400">
            <span className="text-2xl font-bold">N/A</span>
            <span className="text-xs bg-slate-800 px-2 py-0.5 rounded text-slate-400 font-mono">
              NO OBSERVATIONS
            </span>
          </div>
        )}
      </div>

      {/* Footer Metadata Row: Backend Target & Variance */}
      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-medium text-slate-400">
        <div>
          <span>Target: </span>
          <strong className="text-slate-200">{data.target ?? 90.0}%</strong>
        </div>

        {isAvailable && data.variance !== undefined && data.variance !== null && (
          <div className="flex items-center space-x-1">
            <span>Variance: </span>
            <span
              className={`font-bold flex items-center gap-0.5 ${
                data.variance >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {data.variance >= 0 ? (
                <TrendingUp className="w-3 h-3" />
              ) : (
                <TrendingDown className="w-3 h-3" />
              )}
              {data.variance > 0 ? `+${data.variance}` : data.variance}%
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
