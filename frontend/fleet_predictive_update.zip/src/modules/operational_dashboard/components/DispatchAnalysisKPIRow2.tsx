import React from 'react';
import { useDispatchAnalysisKPIs } from '../hooks/useDispatchAnalysisKPIs';
import { OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';
import { CheckCircle, Clock, Zap, Activity, TrendingDown, AlertTriangle } from 'lucide-react';

export const DispatchAnalysisKPIRow2: React.FC = () => {
  const { data, loading, error, status } = useDispatchAnalysisKPIs();

  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80 animate-pulse">
            <div className="h-4 bg-slate-800 rounded w-2/3"></div>
            <div className="h-8 bg-slate-800 rounded w-1/2 mt-2"></div>
            <div className="h-3 bg-slate-800 rounded w-1/3"></div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-3">
        <AlertTriangle className="w-5 h-5 shrink-0 text-rose-400" />
        <span>Failed to load KPI Ribbon Row 2 data: {error}</span>
      </div>
    );
  }

  if (status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || !data) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">COMPLETED DISPATCHES</span>
          <div className="text-2xl font-bold text-slate-100 mt-2">0</div>
          <span className="text-[10px] text-slate-500 block mt-1">NO OBSERVATIONS</span>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">AVG LOADING / TRANSIT</span>
          <div className="text-2xl font-bold text-slate-100 mt-2">— / —</div>
          <span className="text-[10px] text-slate-500 block mt-1">NO OBSERVATIONS</span>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">OPTIMIZED INTERVAL</span>
          <div className="text-2xl font-bold text-slate-100 mt-2">— min</div>
          <span className="text-[10px] text-slate-500 block mt-1">NO OBSERVATIONS</span>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">CADENCE STATUS</span>
          <div className="text-2xl font-bold text-slate-100 mt-2">—</div>
          <span className="text-[10px] text-slate-500 block mt-1">NO OBSERVATIONS</span>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">OPTIMIZATION IMPACT</span>
          <div className="text-2xl font-bold text-slate-100 mt-2">— hrs</div>
          <span className="text-[10px] text-slate-500 block mt-1">NO OBSERVATIONS</span>
        </div>
      </div>
    );
  }

  const getStatusBadge = (cadenceStatus: string) => {
    switch (cadenceStatus) {
      case 'Optimal':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase">OPTIMAL</span>;
      case 'Good':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 uppercase">GOOD</span>;
      case 'Warning':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 uppercase">WARNING</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 uppercase">CRITICAL</span>;
    }
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
      {/* KPI #1: COMPLETED DISPATCHES */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-slate-700 transition">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">COMPLETED DISPATCHES</span>
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
        </div>
        <div className="mt-3">
          <div className="text-2xl font-bold text-slate-100">
            {data.completed_dispatches.toLocaleString()}{' '}
            <span className="text-xs font-normal text-slate-500">/ {data.total_dispatches.toLocaleString()}</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Dispatches with Confirmed Return Timestamp</p>
        </div>
      </div>

      {/* KPI #2: AVG LOADING / TRANSIT */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-slate-700 transition">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">AVG LOADING / TRANSIT</span>
          <Clock className="w-4 h-4 text-amber-400 shrink-0" />
        </div>
        <div className="mt-3">
          <div className="text-2xl font-bold text-slate-100">
            {data.avg_loading_mins.toFixed(1)}{' '}
            <span className="text-xs font-normal text-slate-400">min / {data.avg_transit_mins.toFixed(1)} min</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Plant Holding (T2a) &amp; Site Transit (T1)</p>
        </div>
      </div>

      {/* KPI #3: OPTIMIZED INTERVAL */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-slate-700 transition">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">OPTIMIZED INTERVAL</span>
          <Zap className="w-4 h-4 text-indigo-400 shrink-0" />
        </div>
        <div className="mt-3">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-100">{data.recommended_interval_mins.toFixed(1)} min</span>
            <span className="text-[10px] text-indigo-400 font-mono">CADENCE TARGET</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Calculated Optimal Departure Gap</p>
        </div>
      </div>

      {/* KPI #4: CADENCE STATUS */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-slate-700 transition">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">CADENCE STATUS</span>
          <Activity className="w-4 h-4 text-blue-400 shrink-0" />
        </div>
        <div className="mt-3">
          <div className="flex items-center gap-2">
            {getStatusBadge(data.cadence_status)}
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Pacing &amp; SLA Compliance Evaluation</p>
        </div>
      </div>

      {/* KPI #5: OPTIMIZATION IMPACT */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-slate-700 transition">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">OPTIMIZATION IMPACT</span>
          <TrendingDown className="w-4 h-4 text-emerald-400 shrink-0" />
        </div>
        <div className="mt-3">
          <div className="text-2xl font-bold text-slate-100">
            {data.potential_delay_reduction_hrs.toFixed(1)}{' '}
            <span className="text-xs font-normal text-emerald-400">hrs saved</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Recoverable Holding Delay Hours</p>
        </div>
      </div>
    </div>
  );
};
