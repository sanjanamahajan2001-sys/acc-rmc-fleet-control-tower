import React, { useState } from 'react';
import { useDispatchCadence, DispatchCadenceItemDTO } from '../hooks/useDispatchCadence';
import { OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';
import { AlertTriangle, Clock, ArrowUpDown, ChevronLeft, ChevronRight } from 'lucide-react';

export const DispatchCadenceTable: React.FC = () => {
  const { data, loading, error, status } = useDispatchCadence();
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [sortField, setSortField] = useState<keyof DispatchCadenceItemDTO>('dispatch_date');
  const [sortAsc, setSortAsc] = useState<boolean>(false);
  const pageSize = 10;

  const isNoObs = status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || !data || data.length === 0;

  // Sorting
  const sortedData = React.useMemo(() => {
    if (!data) return [];
    return [...data].sort((a, b) => {
      const valA = a[sortField] ?? '';
      const valB = b[sortField] ?? '';
      if (valA < valB) return sortAsc ? -1 : 1;
      if (valA > valB) return sortAsc ? 1 : -1;
      return 0;
    });
  }, [data, sortField, sortAsc]);

  // Pagination
  const totalPages = Math.ceil(sortedData.length / pageSize) || 1;
  const paginatedData = React.useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedData.slice(start, start + pageSize);
  }, [sortedData, currentPage]);

  const handleSort = (field: keyof DispatchCadenceItemDTO) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  return (
    <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between h-full min-h-[420px]">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 tracking-tight flex items-center gap-2">
              <Clock className="w-4 h-4 text-indigo-400" />
              <span>DISPATCH CADENCE &amp; INTERVAL VARIANCE TABLE</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Chronological trip sequence with departure gap deltas, variance, and pacing SLA recommendations
            </p>
          </div>
        </div>

        {/* Body Content */}
        {loading ? (
          <div className="py-16 flex flex-col items-center justify-center space-y-2">
            <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-xs text-slate-400 font-mono">Loading dispatch cadence records...</span>
          </div>
        ) : error ? (
          <div className="py-12 text-center space-y-2">
            <div className="text-xs text-rose-400 font-medium flex items-center justify-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              <span>Failed to load cadence table</span>
            </div>
            <div className="text-[11px] text-slate-500 max-w-xs mx-auto">{error}</div>
          </div>
        ) : isNoObs ? (
          <div className="py-16 text-center space-y-2">
            <div className="text-xs font-semibold text-slate-400">NO OBSERVATIONS</div>
            <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
              No dispatch cadence observations available for active filters.
            </p>
          </div>
        ) : (
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/40 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800/80">
                <tr>
                  <th scope="col" className="pb-2 pl-1 cursor-pointer hover:text-slate-200" onClick={() => handleSort('dispatch_number')}>
                    <div className="flex items-center gap-1">
                      <span>DISPATCH #</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-500" />
                    </div>
                  </th>
                  <th scope="col" className="pb-2 cursor-pointer hover:text-slate-200" onClick={() => handleSort('dispatch_date')}>
                    <div className="flex items-center gap-1">
                      <span>DATE / OUT</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-500" />
                    </div>
                  </th>
                  <th scope="col" className="pb-2">PLANT / CUSTOMER</th>
                  <th scope="col" className="pb-2">VEHICLE / DRIVER</th>
                  <th scope="col" className="pb-2 text-right">GAP (M)</th>
                  <th scope="col" className="pb-2 text-right">VAR (M)</th>
                  <th scope="col" className="pb-2 text-right">HOLD (M)</th>
                  <th scope="col" className="pb-2 text-right">RET (M)</th>
                  <th scope="col" className="pb-2 text-center">SLA STATUS</th>
                  <th scope="col" className="pb-2 text-left pl-3">RECOMMENDATION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50 font-mono">
                {paginatedData.map((d) => (
                  <tr key={d.dispatch_id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 pl-1 font-bold text-indigo-400 text-[11px]">
                      {d.dispatch_number}
                    </td>
                    <td className="py-2.5 font-sans text-slate-300 text-[11px]">
                      <div className="font-semibold text-slate-200">{d.dispatch_date}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{d.time_out || '—'}</div>
                    </td>
                    <td className="py-2.5 font-sans">
                      <div className="font-bold text-slate-200 text-[11px]">{d.plant_code}</div>
                      <div className="text-[10px] text-slate-400 truncate max-w-[150px]" title={d.customer_name}>
                        {d.customer_name}
                      </div>
                    </td>
                    <td className="py-2.5 font-sans">
                      <div className="font-bold text-slate-200 text-[11px]">{d.vehicle_id}</div>
                      <div className="text-[10px] text-slate-400 truncate max-w-[130px]" title={d.driver_name}>
                        {d.driver_name}
                      </div>
                    </td>
                    <td className="py-2.5 text-right font-bold text-slate-100">
                      {d.interval_mins > 0 ? `${d.interval_mins.toFixed(1)}m` : '—'}
                    </td>
                    <td className="py-2.5 text-right text-slate-300">
                      {d.variance_mins > 0 ? `±${d.variance_mins.toFixed(1)}m` : '0.0m'}
                    </td>
                    <td className="py-2.5 text-right text-slate-300">
                      {d.holding_mins.toFixed(1)}m
                    </td>
                    <td className="py-2.5 text-right text-slate-300">
                      {d.retention_mins.toFixed(1)}m
                    </td>
                    <td className="py-2.5 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        d.sla_status === 'ON_SCHEDULE'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      }`}>
                        {d.sla_status}
                      </span>
                    </td>
                    <td className="py-2.5 pl-3 font-sans text-[11px] text-slate-400">
                      {d.cadence_recommendation}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pagination Footer */}
      {!isNoObs && !loading && !error && (
        <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-medium text-slate-400">
          <span>
            Showing <strong className="text-slate-200">{paginatedData.length}</strong> of{' '}
            <strong className="text-slate-200">{sortedData.length.toLocaleString()}</strong> dispatches
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-mono">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
