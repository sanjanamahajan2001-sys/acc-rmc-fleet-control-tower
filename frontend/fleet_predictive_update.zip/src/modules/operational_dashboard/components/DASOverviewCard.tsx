import React from 'react';
import ReactECharts from 'echarts-for-react';
import { useDASOverview } from '../hooks/useDASOverview';
import { OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';

interface DASOverviewCardProps {
  onOpenDetailModal?: () => void;
}

export const DASOverviewCard: React.FC<DASOverviewCardProps> = ({ onOpenDetailModal }) => {
  const { data, loading, error } = useDASOverview();

  const summary = data?.summary;
  const buckets = data?.buckets;
  const isNoObs = data?.status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || summary?.total_dispatches === 0;

  const statusColor = summary?.operational_status === 'OPTIMAL'
    ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
    : summary?.operational_status === 'WARNING'
    ? 'text-amber-400 bg-amber-500/10 border-amber-500/20'
    : summary?.operational_status === 'CRITICAL'
    ? 'text-rose-400 bg-rose-500/10 border-rose-500/20'
    : 'text-slate-400 bg-slate-500/10 border-slate-500/20';

  const getChartOption = () => {
    if (!buckets) return {};

    return {
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'item',
        backgroundColor: '#090d16',
        borderColor: '#334155',
        textStyle: { color: '#f8fafc', fontSize: 11, fontFamily: 'monospace' },
        formatter: (params: any) => {
          return `<div style="font-family:sans-serif;font-weight:bold;margin-bottom:4px;color:#fff;">${params.name}</div>
            <div style="display:flex;justify-content:space-between;gap:12px;color:${params.color}; font-size:11px;">
              <span>Count: <strong>${params.value.toLocaleString()}</strong></span>
              <span>(${params.percent}%)</span>
            </div>`;
        },
      },
      legend: {
        show: false,
      },
      series: [
        {
          name: 'Dispatch Accuracy',
          type: 'pie',
          radius: ['60%', '85%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 3,
            borderColor: '#0f172a',
            borderWidth: 2,
          },
          label: {
            show: false,
          },
          emphasis: {
            label: {
              show: false,
            },
          },
          labelLine: {
            show: false,
          },
          data: [
            {
              value: buckets.within_20m_count,
              name: 'Within 20m',
              itemStyle: { color: '#10b981' }, // emerald-500
            },
            {
              value: buckets.moderate_20_40m_count,
              name: '20–40m',
              itemStyle: { color: '#f59e0b' }, // amber-500
            },
            {
              value: buckets.critical_above_40m_count,
              name: '>40m',
              itemStyle: { color: '#f43f5e' }, // rose-500
            },
          ],
        },
      ],
    };
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between hover:border-slate-700/80 transition-all duration-200">
      <div>
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800/60">
          <div>
            <h3 className="text-sm font-bold tracking-tight text-white flex items-center gap-2">
              DISPATCH ACCURACY (DAS)
            </h3>
            <p className="text-[11px] text-slate-400">Site Holding Compliance & Delay Classification</p>
          </div>
          {summary?.operational_status && !isNoObs && (
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${statusColor}`}>
              {summary.operational_status}
            </span>
          )}
        </div>

        {/* Body Content */}
        <div className="mt-3">
          {loading ? (
            <div className="space-y-3 animate-pulse py-4">
              <div className="h-4 bg-slate-800 rounded w-full"></div>
              <div className="h-28 bg-slate-800/60 rounded w-full"></div>
            </div>
          ) : error ? (
            <div className="py-6 text-center text-xs text-rose-400 bg-rose-500/5 rounded-lg border border-rose-500/10 p-3">
              <p className="font-semibold">{error}</p>
            </div>
          ) : isNoObs ? (
            <div className="py-6 text-center text-xs text-slate-400 bg-slate-950/30 rounded-lg border border-slate-800/40 p-4">
              No dispatch accuracy observations available for this scope.
            </div>
          ) : (
            <div className="space-y-2">
              {/* Donut Chart with Center Score Overlay */}
              <div className="relative flex items-center justify-center" style={{ height: '120px' }}>
                <div className="h-full w-full">
                  <ReactECharts option={getChartOption()} style={{ height: '100%', width: '100%' }} />
                </div>
                {/* Center Badge displaying DAS score directly from DTO */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-xl font-extrabold tracking-tight text-white font-mono leading-none">
                    {summary?.das_score !== null && summary?.das_score !== undefined ? `${summary.das_score.toFixed(1)}%` : '--'}
                  </span>
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-0.5">
                    Accuracy
                  </span>
                </div>
              </div>

              {/* Bucket Legend Footer */}
              <div className="grid grid-cols-3 gap-1 pt-1 text-[11px] font-mono border-t border-slate-800/40">
                <div className="flex flex-col items-center p-1.5 rounded bg-slate-950/40 border border-slate-800/30">
                  <span className="text-emerald-400 font-semibold text-[10px]">Within 20m</span>
                  <span className="text-white font-bold">{buckets?.within_20m_pct.toFixed(1)}%</span>
                  <span className="text-[9px] text-slate-500">({buckets?.within_20m_count.toLocaleString()})</span>
                </div>
                <div className="flex flex-col items-center p-1.5 rounded bg-slate-950/40 border border-slate-800/30">
                  <span className="text-amber-400 font-semibold text-[10px]">20–40m</span>
                  <span className="text-white font-bold">{buckets?.moderate_20_40m_pct.toFixed(1)}%</span>
                  <span className="text-[9px] text-slate-500">({buckets?.moderate_20_40m_count.toLocaleString()})</span>
                </div>
                <div className="flex flex-col items-center p-1.5 rounded bg-slate-950/40 border border-slate-800/30">
                  <span className="text-rose-400 font-semibold text-[10px]">&gt;40m</span>
                  <span className="text-white font-bold">{buckets?.critical_above_40m_pct.toFixed(1)}%</span>
                  <span className="text-[9px] text-slate-500">({buckets?.critical_above_40m_count.toLocaleString()})</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer Link / Modal Trigger Callback */}
      <div className="pt-2 mt-2 border-t border-slate-800/60 flex items-center justify-between">
        <button
          onClick={onOpenDetailModal}
          className="text-[11px] font-semibold text-sky-400 hover:text-sky-300 transition-colors flex items-center gap-1 group focus:outline-none focus:ring-1 focus:ring-sky-500/50 rounded"
        >
          <span>View dispatch accuracy details</span>
          <span className="group-hover:translate-x-0.5 transition-transform">→</span>
        </button>
        <span className="text-[10px] text-slate-500 font-mono">Target: {summary?.target_sla.toFixed(0)}%</span>
      </div>
    </div>
  );
};
