import React, { useState, useMemo } from 'react';
import { useDispatchCustomerReport, CustomerVehicleReportDTO } from '../hooks/useDispatchCustomerReport';
import { OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';
import { AlertTriangle, Users, Truck, ChevronDown, ChevronUp, UserCheck, MapPin, ChevronLeft, ChevronRight } from 'lucide-react';

export const CustomerVehicleReportWidget: React.FC = () => {
  const { data: customerReports, loading, error, status } = useDispatchCustomerReport();
  const [expandedCustomer, setExpandedCustomer] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 10;

  const isNoObs = status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || !customerReports || customerReports.length === 0;

  const totalRecords = customerReports?.length || 0;
  const totalPages = Math.ceil(totalRecords / pageSize) || 1;

  // Ensure active page is within bounds when customerReports changes
  const activePage = Math.min(currentPage, totalPages);

  const paginatedReports = useMemo(() => {
    if (!customerReports) return [];
    const startIdx = (activePage - 1) * pageSize;
    return customerReports.slice(startIdx, startIdx + pageSize);
  }, [customerReports, activePage, pageSize]);

  const toggleCustomer = (custCode: string) => {
    setExpandedCustomer(expandedCustomer === custCode ? null : custCode);
  };

  return (
    <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between h-full min-h-[420px]">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 tracking-tight flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" />
              <span>CUSTOMER REPORT &amp; VEHICLE MATRIX</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Relational lineage across Customer &rarr; Dispatches &rarr; Vehicles &rarr; Drivers &rarr; Plants derived from PostgreSQL
            </p>
          </div>
        </div>

        {/* Content Body */}
        {loading ? (
          <div className="py-16 flex flex-col items-center justify-center space-y-2">
            <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-xs text-slate-400 font-mono">Loading customer vehicle reports...</span>
          </div>
        ) : error ? (
          <div className="py-12 text-center space-y-2">
            <div className="text-xs text-rose-400 font-medium flex items-center justify-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              <span>Failed to load customer report</span>
            </div>
            <div className="text-[11px] text-slate-500 max-w-xs mx-auto">{error}</div>
          </div>
        ) : isNoObs ? (
          <div className="py-16 text-center space-y-2">
            <div className="text-xs font-semibold text-slate-400">NO OBSERVATIONS</div>
            <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
              No customer operational performance observations available for active filters.
            </p>
          </div>
        ) : (
          <div className="mt-4 space-y-3">
            {paginatedReports.map((c: CustomerVehicleReportDTO) => {
              const isExpanded = expandedCustomer === c.customer_code || paginatedReports.length === 1;

              return (
                <div
                  key={c.customer_code}
                  className="rounded-xl bg-slate-950/60 border border-slate-800/80 overflow-hidden transition-all"
                >
                  {/* Customer Summary Bar */}
                  <div
                    onClick={() => toggleCustomer(c.customer_code)}
                    className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-800/40 transition-colors select-none"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold text-xs">
                        {c.customer_code.substring(5, 7) || 'CU'}
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-100 flex items-center gap-2">
                          <span>{c.customer_name}</span>
                          <span className="text-[10px] text-slate-500 font-mono font-normal">({c.customer_code})</span>
                        </h4>
                        <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-0.5">
                          <span>Dispatches: <strong className="text-slate-200">{c.total_dispatches.toLocaleString()}</strong></span>
                          <span>Volume: <strong className="text-slate-200">{c.total_volume_m3.toLocaleString()} m³</strong></span>
                          <span>DAS Score: <strong className="text-emerald-400">{c.das_score_pct.toFixed(1)}%</strong></span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right text-[11px] hidden sm:block">
                        <span className="text-slate-400 block">Avg Hold / Ret</span>
                        <strong className="text-slate-200 font-mono">{c.avg_holding_mins.toFixed(1)}m / {c.avg_retention_mins.toFixed(1)}m</strong>
                      </div>
                      <div className="text-slate-400">
                        {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </div>
                    </div>
                  </div>

                  {/* Vehicle Matrix (Expandable) */}
                  {isExpanded && (
                    <div className="p-4 pt-0 border-t border-slate-800/60 bg-slate-900/40">
                      <div className="py-2 text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                        <span className="flex items-center gap-1.5">
                          <Truck className="w-3.5 h-3.5 text-indigo-400" />
                          <span>VEHICLES VISITING CUSTOMER ({c.vehicles.length})</span>
                        </span>
                        <span className="font-mono text-[10px] text-slate-500">Relational Dispatch Lineage</span>
                      </div>

                      <div className="overflow-x-auto mt-2">
                        <table className="w-full text-left text-xs text-slate-300">
                          <thead className="bg-slate-950/60 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800/80">
                            <tr>
                              <th scope="col" className="pb-2 pl-2">VEHICLE ID</th>
                              <th scope="col" className="pb-2">DRIVER NAME</th>
                              <th scope="col" className="pb-2">PLANT SITE</th>
                              <th scope="col" className="pb-2 text-right">TRIPS</th>
                              <th scope="col" className="pb-2 text-right">VOLUME (M³)</th>
                              <th scope="col" className="pb-2 text-right">HOLD (M)</th>
                              <th scope="col" className="pb-2 text-right">RET (M)</th>
                              <th scope="col" className="pb-2 text-right">DAS %</th>
                              <th scope="col" className="pb-2 text-center">STATUS</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/40 font-mono">
                            {c.vehicles.map((v) => (
                              <tr key={v.vehicle_id} className="hover:bg-slate-800/30 transition-colors">
                                <td className="py-2.5 pl-2 font-bold text-indigo-400 text-[11px] flex items-center gap-1.5">
                                  <Truck className="w-3.5 h-3.5 text-slate-500" />
                                  <span>{v.vehicle_id}</span>
                                </td>
                                <td className="py-2.5 font-sans text-slate-200">
                                  <div className="flex items-center gap-1">
                                    <UserCheck className="w-3 h-3 text-slate-500" />
                                    <span>{v.driver_name}</span>
                                  </div>
                                </td>
                                <td className="py-2.5 font-sans text-slate-300">
                                  <div className="flex items-center gap-1">
                                    <MapPin className="w-3 h-3 text-slate-500" />
                                    <span>{v.plant_code}</span>
                                  </div>
                                </td>
                                <td className="py-2.5 text-right font-bold text-slate-100">
                                  {v.trips_count}
                                </td>
                                <td className="py-2.5 text-right text-slate-300">
                                  {v.volume_m3.toFixed(1)}
                                </td>
                                <td className="py-2.5 text-right text-slate-300">
                                  {v.avg_holding_mins.toFixed(1)}m
                                </td>
                                <td className="py-2.5 text-right text-slate-300">
                                  {v.avg_retention_mins.toFixed(1)}m
                                </td>
                                <td className="py-2.5 text-right font-bold text-slate-100">
                                  {v.das_score_pct.toFixed(1)}%
                                </td>
                                <td className="py-2.5 text-center">
                                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    v.status === 'Optimal' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                                    v.status === 'Warning' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                                    'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                  }`}>
                                    {v.status}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Pagination Footer */}
      {!isNoObs && !loading && !error && (
        <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-medium text-slate-400">
          <span>
            Showing <strong className="text-slate-200">{paginatedReports.length}</strong> of{' '}
            <strong className="text-slate-200">{totalRecords.toLocaleString()}</strong> Customer Reports
          </span>

          <div className="flex items-center gap-3">
            <span className="font-mono text-slate-300 bg-slate-800/80 px-2.5 py-1 rounded border border-slate-700/60">
              {activePage} of {totalPages}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={activePage === 1}
                className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 text-slate-200 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-xs font-semibold"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={activePage === totalPages}
                className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 text-slate-200 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-xs font-semibold"
              >
                <span>Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
