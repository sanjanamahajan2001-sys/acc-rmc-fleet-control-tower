import React from 'react';
import { usePotentialImpact } from '../hooks/usePotentialImpact';
import { OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';

export const PotentialImpactPlanningCard: React.FC = () => {
  const { data, loading, error, status } = usePotentialImpact();

  const isNoObs = status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || !data?.data;
  const impactData = data?.data;

  return (
    <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between h-full min-h-[340px] transition-all duration-200 hover:border-slate-700/80">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 tracking-tight flex items-center gap-2">
              <span>POTENTIAL IMPACT OF BETTER PLANNING</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Efficiency gains from operational delay reduction
            </p>
          </div>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-medium tracking-wide uppercase text-indigo-400 bg-indigo-500/10 border border-indigo-500/20">
            WS-03.5
          </span>
        </div>

        {/* Content Body */}
        {loading ? (
          <div className="py-12 flex flex-col items-center justify-center space-y-2">
            <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-xs text-slate-400 font-mono">Loading planning impact...</span>
          </div>
        ) : error ? (
          <div className="py-10 text-center space-y-2">
            <div className="text-xs text-rose-400 font-medium">Failed to load planning impact</div>
            <div className="text-[11px] text-slate-500 max-w-xs mx-auto">{error}</div>
          </div>
        ) : isNoObs || !impactData ? (
          <div className="py-12 text-center space-y-2">
            <div className="text-xs font-semibold text-slate-400">NO OBSERVATIONS</div>
            <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
              No dispatch holding or retention data available for active filters.
            </p>
          </div>
        ) : (
          <div className="mt-4 space-y-4">
            {/* Section 1: Holding Impact */}
            <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800/60 flex items-center justify-between gap-4">
              <div>
                <div className="text-xs text-slate-400 font-medium">
                  If holding time reduced by <span className="text-indigo-400 font-semibold">{impactData.holding_impact.reduction_pct}%</span>
                </div>
                <div className="text-lg font-bold font-mono text-slate-100 mt-0.5">
                  {impactData.holding_impact.saved_hours_total.toFixed(1)} <span className="text-xs font-normal text-slate-400">hrs</span>
                </div>
              </div>
              <div className="text-right">
                <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono font-bold text-sm">
                  +{impactData.holding_impact.trips_unlocked} 🚚
                </span>
              </div>
            </div>

            {/* Section 2: Retention Impact */}
            <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800/60 flex items-center justify-between gap-4">
              <div>
                <div className="text-xs text-slate-400 font-medium">
                  If retention time reduced by <span className="text-indigo-400 font-semibold">{impactData.retention_impact.reduction_pct}%</span>
                </div>
                <div className="text-lg font-bold font-mono text-slate-100 mt-0.5">
                  {impactData.retention_impact.saved_hours_total.toFixed(1)} <span className="text-xs font-normal text-slate-400">hrs</span>
                </div>
              </div>
              <div className="text-right">
                <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono font-bold text-sm">
                  +{impactData.retention_impact.trips_unlocked} 🚚
                </span>
              </div>
            </div>

            {/* Section 3: Total Potential Saving */}
            <div className="p-3.5 rounded-xl bg-indigo-950/30 border border-indigo-500/30 flex items-center justify-between gap-4">
              <div>
                <div className="text-xs text-indigo-300 font-semibold tracking-wide uppercase">
                  Total Potential Saving
                </div>
                <div className="text-xl font-extrabold font-mono text-indigo-100 mt-0.5">
                  {impactData.total_impact.saved_hours_total.toFixed(1)} <span className="text-xs font-normal text-indigo-300">hrs</span>
                </div>
              </div>
              <div className="text-right">
                <span className="px-3 py-1.5 rounded-xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 font-mono font-extrabold text-base shadow-sm">
                  +{impactData.total_impact.total_trips_unlocked} Trips
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer / Caption */}
      <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-medium text-slate-400">
        <span>Capacity Factor: 0.8 trips/hr</span>
        <span className="font-mono text-slate-400">WS-03.5 CERTIFIED</span>
      </div>
    </div>
  );
};
