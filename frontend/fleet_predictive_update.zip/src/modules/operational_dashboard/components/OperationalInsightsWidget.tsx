import React from 'react';
import { useDispatchOperationalInsights, OperationalInsightItemDTO } from '../hooks/useDispatchOperationalInsights';
import { OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';
import { AlertTriangle, Zap, Lightbulb } from 'lucide-react';

export const OperationalInsightsWidget: React.FC = () => {
  const { data, loading, error, status } = useDispatchOperationalInsights();

  if (loading) {
    return (
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl min-h-[380px] flex flex-col justify-between animate-pulse">
        <div className="h-6 bg-slate-800 rounded w-1/3"></div>
        <div className="space-y-3 my-4">
          <div className="h-16 bg-slate-800 rounded"></div>
          <div className="h-16 bg-slate-800 rounded"></div>
        </div>
        <div className="h-4 bg-slate-800 rounded w-1/4"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl min-h-[380px] flex flex-col justify-center items-center text-center">
        <AlertTriangle className="w-8 h-8 text-rose-400 mb-2" />
        <h4 className="text-xs font-semibold text-rose-300">Failed to load operational insights</h4>
        <p className="text-[11px] text-slate-500 max-w-xs mt-1">{error}</p>
      </div>
    );
  }

  const isNoObs = status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || !data || data.insights.length === 0;

  return (
    <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between h-full min-h-[380px]">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 tracking-tight flex items-center gap-2">
              <Zap className="w-4 h-4 text-indigo-400" />
              <span>OPERATIONAL INSIGHTS &amp; CADENCE OPTIMIZATION</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Automated cadence optimization strategy, pacing recommendations, and delay recovery impact
            </p>
          </div>
        </div>

        {/* Content */}
        {isNoObs ? (
          <div className="py-16 text-center space-y-2">
            <div className="text-xs font-semibold text-slate-400">NO OBSERVATIONS</div>
            <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
              No operational optimization insights available for active filters.
            </p>
          </div>
        ) : (
          <div className="mt-4 space-y-4">
            {/* Optimization Overview Banner */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">RECOMMENDED PACING STRATEGY</span>
                <div className="text-sm font-bold text-indigo-400 mt-0.5 flex items-center gap-1.5">
                  <Lightbulb className="w-4 h-4 text-indigo-400" />
                  <span>{data.primary_pacing_strategy.replace('_', ' ')}</span>
                </div>
              </div>
              <div className="text-right text-[11px] text-slate-400 space-y-0.5 font-mono">
                <div>Target Gap: <strong className="text-slate-200">{data.target_departure_interval_mins.toFixed(1)}m</strong></div>
                <div>Recoverable: <strong className="text-emerald-400">{data.potential_recoverable_delay_hrs.toFixed(1)}h</strong></div>
              </div>
            </div>

            {/* Insights Cards */}
            <div className="space-y-3">
              {data.insights.map((insight: OperationalInsightItemDTO) => (
                <div key={insight.id} className="p-4 rounded-xl bg-slate-950/40 border border-slate-800/60 hover:border-slate-700/80 transition space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="text-xs font-bold text-slate-200 flex items-center gap-2">
                      <span>{insight.title}</span>
                    </h4>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      insight.impact_level === 'HIGH' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                      'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                    }`}>
                      {insight.impact_level} IMPACT
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">{insight.description}</p>
                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-800/40 font-mono">
                    <span className="text-indigo-400">{insight.primary_metric}</span>
                    <span className="text-emerald-400 font-bold">-{insight.estimated_delay_reduction_hrs.toFixed(1)}h delay</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-medium text-slate-400">
        <span>PostgreSQL-Backed Operational Strategy Engine</span>
        <span className="font-mono text-slate-500">INSIGHTS</span>
      </div>
    </div>
  );
};
