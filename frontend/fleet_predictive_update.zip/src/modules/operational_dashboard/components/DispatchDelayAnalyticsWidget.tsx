import React from 'react';
import { useDispatchDelayAnalytics } from '../hooks/useDispatchDelayAnalytics';
import { OperationalIntelligenceStatusEnum } from '../hooks/useTopProblemCustomers';
import { AlertTriangle, Clock } from 'lucide-react';

export const DispatchDelayAnalyticsWidget: React.FC = () => {
  const { data, loading, error, status } = useDispatchDelayAnalytics();

  if (loading) {
    return (
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl min-h-[380px] flex flex-col justify-between animate-pulse">
        <div className="h-6 bg-slate-800 rounded w-1/3"></div>
        <div className="space-y-3 my-4">
          <div className="h-12 bg-slate-800 rounded"></div>
          <div className="h-12 bg-slate-800 rounded"></div>
        </div>
        <div className="h-4 bg-slate-800 rounded w-1/4"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl min-h-[380px] flex flex-col justify-center items-center text-center">
        <AlertTriangle className="w-8 h-8 text-rose-400 mb-2" />
        <h4 className="text-xs font-semibold text-rose-300">Failed to load delay analytics</h4>
        <p className="text-[11px] text-slate-500 max-w-xs mt-1">{error}</p>
      </div>
    );
  }

  const isNoObs = status === OperationalIntelligenceStatusEnum.NO_OBSERVATIONS || !data || data.categories.length === 0;

  return (
    <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-xl flex flex-col justify-between h-full min-h-[380px]">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 tracking-tight flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>DISPATCH DELAY ANALYTICS</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Root-cause delay categorization across site queues, customer unloading, and interval variance
            </p>
          </div>
        </div>

        {/* Content */}
        {isNoObs ? (
          <div className="py-16 text-center space-y-2">
            <div className="text-xs font-semibold text-slate-400">NO OBSERVATIONS</div>
            <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
              No delay analytics observations available for active filters.
            </p>
          </div>
        ) : (
          <div className="mt-4 space-y-4">
            {/* Total Delay Banner */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">CUMULATIVE DELAY IMPACT</span>
                <div className="text-2xl font-bold text-slate-100 mt-0.5">
                  {data.total_delay_hours.toFixed(1)} <span className="text-xs font-normal text-slate-400">Hours Lost</span>
                </div>
              </div>
              <div className="text-right text-[11px] text-slate-400 space-y-0.5 font-mono">
                <div>Buildup: <strong className="text-amber-400">{data.buildup_delay_hours.toFixed(1)}h</strong></div>
                <div>Unload: <strong className="text-rose-400">{data.unload_delay_hours.toFixed(1)}h</strong></div>
                <div>Variance: <strong className="text-indigo-400">{data.sequence_variance_delay_hours.toFixed(1)}h</strong></div>
              </div>
            </div>

            {/* Delay Categories */}
            <div className="space-y-3">
              {data.categories.map((cat, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800/60 flex items-start justify-between gap-3 hover:border-slate-700/80 transition">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-200">{cat.category_name}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        cat.severity === 'HIGH' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                        cat.severity === 'MEDIUM' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                        'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                      }`}>
                        {cat.severity}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-tight">{cat.recommendation}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-sm font-bold text-slate-100 font-mono">{cat.delay_hours.toFixed(1)}h</div>
                    <div className="text-[10px] text-slate-500 font-mono">{cat.percentage_contribution.toFixed(1)}% ({cat.affected_trips_count} trips)</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-medium text-slate-400">
        <span>Calculated from Real PostgreSQL Dispatches</span>
        <span className="font-mono text-slate-500">DELAY ANALYTICS</span>
      </div>
    </div>
  );
};
