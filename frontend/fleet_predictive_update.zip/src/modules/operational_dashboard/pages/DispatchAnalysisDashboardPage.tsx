import React from 'react';
import { Clock } from 'lucide-react';
import { DashboardSyncProvider } from '../../site_dashboard/orchestration/DashboardSyncProvider';
import { DashboardFilterProvider } from '../../site_dashboard/orchestration/DashboardFilterProvider';
import { GlobalDashboardFilterBar } from '../../site_dashboard/components/GlobalDashboardFilterBar';
import { SyncStatusHeaderBadge } from '../../site_dashboard/components/SyncStatusHeaderBadge';
import { useOperationalDashboardContext } from '../hooks/useOperationalDashboardContext';

import { DispatchAnalysisKPIRow1 } from '../components/DispatchAnalysisKPIRow1';
import { DispatchAnalysisKPIRow2 } from '../components/DispatchAnalysisKPIRow2';
import { DispatchCadenceTable } from '../components/DispatchCadenceTable';
import { DispatchDelayAnalyticsWidget } from '../components/DispatchDelayAnalyticsWidget';
import { OperationalInsightsWidget } from '../components/OperationalInsightsWidget';
import { CustomerVehicleReportWidget } from '../components/CustomerVehicleReportWidget';

const DispatchAnalysisDashboardContent: React.FC = () => {
  const { refetchContext } = useOperationalDashboardContext();

  return (
    <DashboardSyncProvider onRefreshNeeded={refetchContext}>
      <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-5 space-y-6">
        {/* Top Header Bar for Standalone Dispatch Analysis & Cadence Optimization Workspace */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-600/15 text-indigo-400 border border-indigo-500/30">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-100">
                Dispatch Analysis &amp; Cadence Optimization
              </h1>
              <p className="text-xs text-slate-400">
                Fleet dispatch pacing, interval variance, queue delay analytics &amp; customer-vehicle matrix
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <SyncStatusHeaderBadge />
          </div>
        </div>

        {/* Global Dashboard Filter Bar (Shared filter provider contract) */}
        <GlobalDashboardFilterBar />

        {/* Primary Workspace Content Area: All Certified WS-05 Widgets */}
        <div className="space-y-6">
          {/* Row 1 KPIs (5 KPIs) */}
          <DispatchAnalysisKPIRow1 />

          {/* Row 2 KPIs (5 KPIs) */}
          <DispatchAnalysisKPIRow2 />

          {/* Dispatch Cadence & Variance Table */}
          <DispatchCadenceTable />

          {/* Dispatch Delay Analytics Widget & Operational Insights Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <DispatchDelayAnalyticsWidget />
            <OperationalInsightsWidget />
          </div>

          {/* Customer Report & Vehicle Performance Matrix */}
          <CustomerVehicleReportWidget />
        </div>
      </div>
    </DashboardSyncProvider>
  );
};

export const DispatchAnalysisDashboardPage: React.FC = () => {
  return (
    <DashboardFilterProvider>
      <DispatchAnalysisDashboardContent />
    </DashboardFilterProvider>
  );
};

export default DispatchAnalysisDashboardPage;
