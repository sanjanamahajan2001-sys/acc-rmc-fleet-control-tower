import React from 'react';
import { Bell } from 'lucide-react';
import { DashboardSyncProvider } from '../../site_dashboard/orchestration/DashboardSyncProvider';
import { DashboardFilterProvider } from '../../site_dashboard/orchestration/DashboardFilterProvider';
import { GlobalDashboardFilterBar } from '../../site_dashboard/components/GlobalDashboardFilterBar';
import { SyncStatusHeaderBadge } from '../../site_dashboard/components/SyncStatusHeaderBadge';
import { useOperationalDashboardContext } from '../hooks/useOperationalDashboardContext';
import { AlertCenterWorkspaceContent } from '../widgets/alerts/AlertCenterWorkspaceContent';

const AlertCenterDashboardContent: React.FC = () => {
  const { refetchContext } = useOperationalDashboardContext();

  return (
    <DashboardSyncProvider onRefreshNeeded={refetchContext}>
      <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-5 space-y-6">
        {/* Top Header Bar for Operational Alert Center */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-600/15 text-amber-400 border border-amber-500/30">
              <Bell className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-100">
                Operational Alert Center
              </h1>
              <p className="text-xs text-slate-400">
                Real-Time Business Rule Exceptions &amp; SLA Management
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <SyncStatusHeaderBadge />
          </div>
        </div>

        {/* Global Dashboard Filter Bar (Shared filter provider contract) */}
        <GlobalDashboardFilterBar />

        {/* Primary Workspace Content Area: Alert Center Content ONLY */}
        <div className="w-full">
          <AlertCenterWorkspaceContent />
        </div>
      </div>
    </DashboardSyncProvider>
  );
};

export const AlertCenterDashboardPage: React.FC = () => {
  return (
    <DashboardFilterProvider>
      <AlertCenterDashboardContent />
    </DashboardFilterProvider>
  );
};

export default AlertCenterDashboardPage;
