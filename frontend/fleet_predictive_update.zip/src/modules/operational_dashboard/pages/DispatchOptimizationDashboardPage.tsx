import React, { useState, useEffect } from 'react';
import { Clock, CheckCircle, XCircle } from 'lucide-react';
import { DashboardSyncProvider } from '../../site_dashboard/orchestration/DashboardSyncProvider';
import { DashboardFilterProvider, useDashboardFilters } from '../../site_dashboard/orchestration/DashboardFilterProvider';
import { GlobalDashboardFilterBar } from '../../site_dashboard/components/GlobalDashboardFilterBar';
import { SyncStatusHeaderBadge } from '../../site_dashboard/components/SyncStatusHeaderBadge';
import { DispatchOptimizationGantt } from '../components/DispatchOptimization/DispatchOptimizationGantt';

const DispatchOptimizationDashboardContent: React.FC = () => {
  const { filters } = useDashboardFilters();

  const [readiness, setReadiness] = useState<any>(null);
  const [scenarios, setScenarios] = useState<any[]>([]);
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('');
  const [ganttData, setGanttData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isStale, setIsStale] = useState<boolean>(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Re-fetch readiness, optimization run, and Gantt data when global filters change
  useEffect(() => {
    let isMounted = true;

    const fetchOptimizationState = async () => {
      setIsLoading(true);
      setActionSuccess(null);
      setActionError(null);
      setGanttData(null);
      setScenarios([]);

      try {
        // 1. Fetch Readiness (WS-06.3) using /fleet-api/v1 prefix
        const queryParams = new URLSearchParams();
        if (filters.plant_id) queryParams.set('plant_id', filters.plant_id);
        if (filters.customer_id) queryParams.set('customer_id', filters.customer_id);
        if (filters.dataset_type) queryParams.set('dataset_type', filters.dataset_type);

        const readinessRes = await fetch(`/fleet-api/v1/dispatch-optimization/readiness?${queryParams.toString()}`);
        const readinessData = await readinessRes.json();

        if (!isMounted) return;
        setReadiness(readinessData);

        if (readinessData.status === 'NO_OBSERVATIONS') {
          setScenarios([]);
          setGanttData(null);
          setIsLoading(false);
          return;
        }

        // 2. Trigger Optimization Run (WS-06.4 + WS-06.5) returning authoritative solver-derived scenarios and real gantt_items
        const runRes = await fetch('/fleet-api/v1/dispatch-optimization/runs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            filters: {
              plant_id: filters.plant_id || 'ALL',
              customer_id: filters.customer_id || 'ALL',
              dataset_type: filters.dataset_type || 'REAL_ONLY',
            },
            objective_config: { objective_type: 'BALANCED_OPERATIONS' },
          }),
        });

        const runData = await runRes.json();
        if (!isMounted) return;

        if (runData.scenarios && runData.scenarios.length > 0) {
          setScenarios(runData.scenarios);
          const recId = runData.recommended_scenario_id || runData.scenarios[0].scenario_id;
          setSelectedScenarioId(recId);

          const activeScenarioObj = runData.scenarios.find((s: any) => s.scenario_id === recId) || runData.scenarios[0];

          setGanttData({
            optimization_run_id: runData.optimization_run_id,
            scenario_id: recId,
            items: activeScenarioObj?.gantt_items || [],
          });
        }
        setIsStale(false);
      } catch (err: any) {
        if (isMounted) setActionError(err.message || 'Failed to load optimization workspace state.');
      } finally {
        if (isMounted) setIsLoading(false);
      }
    };

    fetchOptimizationState();

    return () => {
      isMounted = false;
    };
  }, [filters.plant_id, filters.customer_id, filters.dataset_type]);

  // Handle Planner Action Submission (ACCEPT, MODIFY, REJECT via WS-06.7 -> Phase 5.7 API)
  const handlePlannerAction = async (actionType: 'ACCEPTED' | 'MODIFIED' | 'REJECTED') => {
    setActionSuccess(null);
    setActionError(null);

    if (isStale) {
      setActionError('Optimization plan is out of date — refresh optimization context.');
      return;
    }

    try {
      const activeScen = scenarios.find((s) => s.scenario_id === selectedScenarioId) || scenarios[0];
      const payload: any = {
        optimization_run_id: ganttData?.optimization_run_id || 'RUN-1001',
        scenario_id: selectedScenarioId,
        objective_type: activeScen?.objective_type || 'BALANCED_OPERATIONS',
        snapshot_hash: '01a068076c072bc5f4defbe5f1917e6ead8251421dda8f413aadba1f660d6c24',
        action_type: actionType,
      };

      if (actionType === 'MODIFIED') {
        payload.modified_parameters = { time_shift_mins: 15, note: 'Operator shift modification' };
      } else if (actionType === 'REJECTED') {
        payload.rejection_reason = 'PLANT_CAPACITY_LIMIT';
      }

      const res = await fetch('/fleet-api/v1/dispatch-optimization/actions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.status === 409) {
        setIsStale(true);
        setActionError('Optimization plan is out of date due to ERP dataset update.');
        return;
      }

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || 'Planner action submission failed.');
      }

      const data = await res.json();
      setActionSuccess(`Decision ${data.record.action_id} successfully recorded! Decision: ${actionType}`);
    } catch (err: any) {
      setActionError(err.message || 'Action submission error.');
    }
  };

  const isActionsDisabled = isStale || isLoading || readiness?.status === 'NO_OBSERVATIONS' || !scenarios.length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-5 space-y-6" data-testid="workspace-container">
      {/* Top Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-600/15 text-indigo-400 border border-indigo-500/30">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-100">
              Dispatch Optimization Control Center
            </h1>
            <p className="text-xs text-slate-400">
              Real-Time Operational Readiness, Scenario Planning &amp; Cadence Optimization
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <SyncStatusHeaderBadge />
        </div>
      </div>

      {/* Reused Shared Global Dashboard Filter Bar */}
      <GlobalDashboardFilterBar />

      {/* Audit Confirmation / Error Messages */}
      {actionSuccess && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded text-xs flex items-center gap-2" data-testid="action-success-banner">
          <CheckCircle size={16} />
          <span>{actionSuccess}</span>
        </div>
      )}
      {actionError && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-400 rounded text-xs flex items-center gap-2" data-testid="action-error-banner">
          <XCircle size={16} />
          <span>{actionError}</span>
        </div>
      )}

      {/* Operator Decision Controls Bar */}
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4" data-testid="planner-action-controls">
        <div className="text-xs font-semibold text-slate-300">
          Optimization Decision
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => handlePlannerAction('ACCEPTED')}
            disabled={isActionsDisabled}
            className="px-4 py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
            data-testid="accept-action-btn"
          >
            ACCEPT SCENARIO
          </button>
          <button
            onClick={() => handlePlannerAction('MODIFIED')}
            disabled={isActionsDisabled}
            className="px-4 py-2 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
            data-testid="modify-action-btn"
          >
            MODIFY CADENCE
          </button>
          <button
            onClick={() => handlePlannerAction('REJECTED')}
            disabled={isActionsDisabled}
            className="px-4 py-2 rounded bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs disabled:opacity-50 disabled:cursor-not-allowed"
            data-testid="reject-action-btn"
          >
            REJECT PLAN
          </button>
        </div>
      </div>

      {/* Main Gantt Timeline Composition Component */}
      <DispatchOptimizationGantt
        readiness={readiness}
        scenarios={scenarios}
        selectedScenarioId={selectedScenarioId}
        ganttData={ganttData}
        isLoading={isLoading}
        isStale={isStale}
        onScenarioSelect={(id) => setSelectedScenarioId(id)}
      />
    </div>
  );
};

export const DispatchOptimizationDashboardPage: React.FC = () => {
  return (
    <DashboardSyncProvider onRefreshNeeded={async () => {}}>
      <DashboardFilterProvider>
        <DispatchOptimizationDashboardContent />
      </DashboardFilterProvider>
    </DashboardSyncProvider>
  );
};

export default DispatchOptimizationDashboardPage;
