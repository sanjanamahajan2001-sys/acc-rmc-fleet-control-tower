import React, { useEffect } from 'react';
import { RefreshCw, FileSearch } from 'lucide-react';
import { IntegrityDashboard } from '../components/IntegrityDashboard';
import { ExplorerGrid } from '../components/ExplorerGrid';
import { EntityDetailDrawer } from '../components/EntityDetailDrawer';
import { useERPExplorerStore } from '../stores';
import { useERPStatisticsStore } from '../../stores';

export const ERPExplorerPage: React.FC = () => {
  const { fetchEntityData, fetchImportHistory, fetchAuditLogs } = useERPExplorerStore();
  const fetchStatistics = useERPStatisticsStore((s) => s.fetchStatistics);

  useEffect(() => {
    fetchEntityData();
    fetchImportHistory();
    fetchAuditLogs();
    fetchStatistics();
  }, [fetchEntityData, fetchImportHistory, fetchAuditLogs, fetchStatistics]);

  const handleRefresh = () => {
    fetchEntityData();
    fetchImportHistory();
    fetchAuditLogs();
    fetchStatistics();
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6 md:p-8 space-y-8">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-emerald-500 text-white shadow-lg shadow-indigo-500/20">
            <FileSearch className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-100 tracking-tight">
              Imported Data Explorer & Audit Center
            </h1>
            <p className="text-xs text-slate-400">
              Operational Inspection Workspace • Lineage Tracing • Database Integrity Verification
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleRefresh}
            className="px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 hover:bg-slate-800 text-xs font-semibold text-slate-300 flex items-center gap-2 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh Explorer Data
          </button>
        </div>
      </div>

      {/* Feature 6 — Database Integrity Dashboard */}
      <IntegrityDashboard />

      {/* Feature 1 — Enterprise Explorer Grid */}
      <ExplorerGrid />

      {/* Feature 2 — Right-side Entity Inspection Drawer */}
      <EntityDetailDrawer />
    </div>
  );
};

export default ERPExplorerPage;
