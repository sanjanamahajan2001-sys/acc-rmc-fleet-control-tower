import React from 'react';
import { Eye, Download, Search, Filter } from 'lucide-react';
import { useERPExplorerStore, ExplorerEntityType, SyntheticFilterOption } from '../stores';

export const ExplorerGrid: React.FC = () => {
  const {
    activeEntity,
    setActiveEntity,
    items,
    totalRecords,
    currentPage,
    pageSize,
    loading,
    searchQuery,
    setSearchQuery,
    syntheticFilter,
    setSyntheticFilter,
    fetchEntityData,
    selectItemForInspection,
  } = useERPExplorerStore();

  const entities: { id: ExplorerEntityType; label: string }[] = [
    { id: 'dispatches', label: 'Dispatches' },
    { id: 'tickets', label: 'Tickets' },
    { id: 'plants', label: 'Plants' },
    { id: 'vehicles', label: 'Vehicles' },
    { id: 'customers', label: 'Customers' },
    { id: 'drivers', label: 'Drivers' },
    { id: 'orders', label: 'Orders' },
    { id: 'sites', label: 'Sites' },
    { id: 'trips', label: 'Trips' },
    { id: 'invoices', label: 'Invoices' },
    { id: 'telemetry' as any, label: 'Telemetry Stream' },
  ];

  const [showTechnicalCols, setShowTechnicalCols] = React.useState(false);

  // Technical UUID columns to hide when showTechnicalCols is false
  const techUuidCols = new Set([
    'id',
    'ticket_id',
    'vehicle_id',
    'driver_id',
    'plant_id',
    'customer_id',
    'order_id',
    'dispatch_id',
    'created_at',
    'updated_at',
    'deleted_at',
    'is_deleted',
    'version_id',
    'created_by',
    'updated_by',
    'import_batch_id',
    'checksum',
    'parser_version',
    'source_system',
    'excel_row',
    'telemetry_matched',
    'telemetry_match_score',
    'source_lineage',
  ]);

  // Filtering logic for search and synthetic records
  const filteredItems = items.filter((item) => {
    // Synthetic filter
    const isSynthetic =
      item.ticket_number?.startsWith('SYNTH-') ||
      item.dispatch_number?.startsWith('SYNTH-') ||
      item.is_synthetic;

    if (syntheticFilter === 'REAL_ONLY' && isSynthetic) return false;
    if (syntheticFilter === 'SYNTHETIC_ONLY' && !isSynthetic) return false;

    // Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const stringified = JSON.stringify(item).toLowerCase();
      return stringified.includes(q);
    }
    return true;
  });

  const getVisibleColumns = (sampleItem: Record<string, any>) => {
    const keys = Object.keys(sampleItem);
    if (showTechnicalCols) return keys;
    return keys.filter((k) => !techUuidCols.has(k));
  };

  const exportToCSV = () => {
    if (filteredItems.length === 0) return;
    const cols = getVisibleColumns(filteredItems[0]);
    const headers = cols.join(',');
    const rows = filteredItems.map((row) =>
      cols
        .map((v) => `"${String(row[v] ?? '').replace(/"/g, '""')}"`)
        .join(',')
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `erp_explorer_${activeEntity}_export.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6 rounded-xl bg-slate-900/60 border border-slate-800 space-y-6">
      {/* Entity Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-800">
        {entities.map((ent) => (
          <button
            key={ent.id}
            type="button"
            onClick={() => setActiveEntity(ent.id)}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition whitespace-nowrap ${
              activeEntity === ent.id
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                : 'bg-slate-950/60 text-slate-400 hover:bg-slate-800 hover:text-slate-200 border border-slate-800/80'
            }`}
          >
            {ent.label}
          </button>
        ))}
      </div>

      {/* Control Bar: Search, Synthetic Filter, Technical Toggle, CSV Export */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
        {/* Global Search Input */}
        <div className="relative w-full lg:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Search ${activeEntity} (Ticket, Dispatch, Plant)...`}
            className="w-full pl-9 pr-4 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition min-h-[44px] sm:min-h-[36px]"
          />
        </div>

        {/* Feature 8 & Column Toggle Controls */}
        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 flex-1 sm:flex-none justify-center">
            <input
              type="checkbox"
              checked={showTechnicalCols}
              onChange={(e) => setShowTechnicalCols(e.target.checked)}
              className="rounded bg-slate-900 border-slate-700 text-indigo-600 focus:ring-0"
            />
            <span>Show Technical UUIDs</span>
          </label>

          <div className="flex items-center gap-2 bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 text-xs flex-1 sm:flex-none justify-center">
            <Filter className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-slate-400">Data Type:</span>
            <select
              value={syntheticFilter}
              onChange={(e) => setSyntheticFilter(e.target.value as SyntheticFilterOption)}
              className="bg-transparent text-slate-200 font-semibold focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-slate-200">All Records</option>
              <option value="REAL_ONLY" className="bg-slate-900 text-emerald-400">Real ERP Data Only</option>
              <option value="SYNTHETIC_ONLY" className="bg-slate-900 text-amber-400">Synthetic Records Only</option>
            </select>
          </div>

          <button
            type="button"
            onClick={exportToCSV}
            className="px-4 py-2 rounded-lg bg-slate-950 border border-slate-800 hover:bg-slate-800 text-xs font-semibold text-slate-300 flex items-center justify-center gap-2 transition flex-1 sm:flex-none min-h-[44px] sm:min-h-[36px]"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            Export CSV
          </button>
        </div>
      </div>

      {/* Enterprise Data Table Grid */}
      <div className="overflow-x-auto border border-slate-800/80 rounded-xl bg-slate-950/40">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-xs text-slate-400 bg-slate-950">
              {filteredItems.length > 0 ? (
                getVisibleColumns(filteredItems[0]).map((col) => (
                  <th key={col} className="py-3 px-4 uppercase font-semibold tracking-wider text-[11px] whitespace-nowrap">
                    {col.replace(/_/g, ' ')}
                  </th>
                ))
              ) : (
                <th className="py-3 px-4">Entity Attribute</th>
              )}
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-xs font-mono">
            {loading ? (
              <tr>
                <td colSpan={15} className="py-8 text-center text-slate-500">
                  Loading canonical explorer records...
                </td>
              </tr>
            ) : filteredItems.length === 0 ? (
              <tr>
                <td colSpan={15} className="py-8 text-center text-slate-500">
                  No records found matching current query or filters.
                </td>
              </tr>
            ) : (
              filteredItems.map((row, idx) => (
                <tr key={row.id || idx} className="hover:bg-slate-800/40 transition">
                  {getVisibleColumns(row).map((key) => {
                    const val = row[key];
                    return (
                      <td key={key} className="py-3 px-4 whitespace-nowrap text-slate-300">
                        {key === 'is_generated' ? (
                          val ? (
                            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[10px] font-bold inline-flex items-center gap-1" title={row.generation_reason || 'System Generated'}>
                              GENERATED
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold inline-flex items-center gap-1">
                              IMPORTED ERP
                            </span>
                          )
                        ) : key === 'correlation_status' ? (
                          val === 'CORRELATED' ? (
                            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                              CORRELATED
                            </span>
                          ) : val === 'MANUAL_REVIEW' ? (
                            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[10px] font-bold">
                              MANUAL REVIEW
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] font-bold">
                              {String(val ?? 'PENDING')}
                            </span>
                          )
                        ) : key === 'correlation_score' ? (
                          val && val !== 'Pending' ? (
                            <span className="font-bold text-emerald-400">{val}</span>
                          ) : (
                            <span className="text-slate-500 italic">Pending</span>
                          )
                        ) : key === 'generation_reason' ? (
                          <span className="text-slate-400 italic text-[11px]">{String(val ?? 'N/A')}</span>
                        ) : key.includes('number') || key.includes('code') || key.includes('name') ? (
                          <span className="font-semibold text-indigo-300">{String(val ?? '')}</span>
                        ) : key.startsWith('is_synthetic') && val ? (
                          <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 text-[10px] font-bold">SYNTHETIC</span>
                        ) : (
                          String(val ?? '')
                        )}
                      </td>
                    );
                  })}
                  <td className="py-3 px-4 text-right">
                    <button
                      type="button"
                      onClick={() => selectItemForInspection(row)}
                      className="p-1.5 rounded text-slate-400 hover:text-indigo-300 hover:bg-slate-800 transition"
                      title="Inspect Entity Lineage & Payload"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Bar */}
      <div className="flex items-center justify-between text-xs text-slate-400 pt-2">
        <span>
          Showing Page <strong className="text-slate-200">{currentPage}</strong> of{' '}
          <strong className="text-slate-200">{Math.ceil(totalRecords / pageSize) || 1}</strong> ({totalRecords} total records)
        </span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={currentPage <= 1}
            onClick={() => fetchEntityData(activeEntity, currentPage - 1)}
            className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 disabled:opacity-40 hover:bg-slate-800 transition font-medium"
          >
            Previous
          </button>
          <button
            type="button"
            disabled={currentPage * pageSize >= totalRecords}
            onClick={() => fetchEntityData(activeEntity, currentPage + 1)}
            className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 disabled:opacity-40 hover:bg-slate-800 transition font-medium"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};
