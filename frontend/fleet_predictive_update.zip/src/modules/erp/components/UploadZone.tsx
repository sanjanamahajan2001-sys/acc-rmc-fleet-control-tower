import React, { useRef, useState } from 'react';
import { UploadCloud, FileCheck, AlertCircle, RefreshCw, XCircle } from 'lucide-react';
import { useERPUploadStore, useERPNotificationStore, useERPProgressStore } from '../stores';

export const UploadZone: React.FC = () => {
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { uploading, uploadFile, error, activeJob, resetUpload } = useERPUploadStore();
  const addNotification = useERPNotificationStore((s) => s.addNotification);
  const connectSSE = useERPProgressStore((s) => s.connectSSE);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];

    // File validation
    const validExtensions = ['.xlsx', '.xlsm', '.xls', '.csv'];
    const hasValidExt = validExtensions.some((ext) => file.name.toLowerCase().endsWith(ext));
    if (!hasValidExt) {
      addNotification('error', `Invalid file type. Accepted formats: ${validExtensions.join(', ')}`);
      return;
    }

    if (file.size > 524288000) { // 500 MB
      addNotification('error', 'File size exceeds maximum limit of 500MB');
      return;
    }

    const job = await uploadFile(file);
    if (job) {
      addNotification('success', `Workbook '${file.name}' uploaded successfully. Job ID: ${job.job_number}`);
      connectSSE(job.job_number);
    } else {
      addNotification('error', 'Workbook upload failed.');
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  return (
    <div
      aria-label="Workbook Upload Zone"
      tabIndex={0}
      onDragEnter={handleDrag}
      onDragOver={handleDrag}
      onDragLeave={handleDrag}
      onDrop={handleDrop}
      className={`relative p-6 rounded-xl border-2 border-dashed transition-all duration-200 ${
        dragActive
          ? 'border-indigo-500 bg-indigo-500/10 scale-[1.01]'
          : 'border-slate-700 bg-slate-900/60 hover:border-slate-600'
      }`}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept=".xlsx,.xlsm,.xls,.csv"
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />

      <div className="flex flex-col items-center justify-center text-center space-y-4">
        <div className="p-4 rounded-full bg-indigo-500/10 text-indigo-400">
          <UploadCloud className="w-10 h-10 animate-pulse" />
        </div>

        <div>
          <h3 className="text-lg font-semibold text-slate-100">
            Upload ERP Workbook
          </h3>
          <p className="text-sm text-slate-400 mt-1">
            Drag & drop your Excel or CSV file here, or{' '}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="text-indigo-400 hover:text-indigo-300 font-medium underline"
            >
              browse
            </button>
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs text-slate-500">
          <span>Supported: .xlsx, .xlsm, .xls, .csv</span>
          <span>•</span>
          <span>Max Size: 500MB</span>
          <span>•</span>
          <span>SHA-256 Verified</span>
        </div>

        {uploading && (
          <div className="flex items-center gap-2 text-indigo-400 text-sm font-medium">
            <RefreshCw className="w-4 h-4 animate-spin" />
            Uploading & verifying checksum...
          </div>
        )}

        {error && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-rose-500/10 text-rose-400 text-sm">
            <AlertCircle className="w-4 h-4" />
            {error}
          </div>
        )}

        {activeJob && (
          <div className="flex items-center justify-between w-full p-3 rounded-lg bg-emerald-500/10 text-emerald-400 text-sm">
            <div className="flex items-center gap-2">
              <FileCheck className="w-4 h-4" />
              <span>Job Created: {activeJob.job_number} ({activeJob.file_name})</span>
            </div>
            <button
              type="button"
              onClick={resetUpload}
              className="p-1 hover:bg-emerald-500/20 rounded"
            >
              <XCircle className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
