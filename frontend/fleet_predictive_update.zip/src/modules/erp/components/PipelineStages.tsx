import React from 'react';
import { CheckCircle2, Loader2, AlertTriangle, Circle } from 'lucide-react';
import { useERPProgressStore } from '../stores';
import { ImportPipelineStage } from '../types';

interface StageConfig {
  id: string;
  label: string;
  matchingStages: ImportPipelineStage[];
}

const STAGES: StageConfig[] = [
  { id: 'upload', label: 'Workbook Upload & Storage', matchingStages: ['ACQUIRING'] },
  { id: 'parsing', label: 'Streaming Batch Parsing', matchingStages: ['PARSING'] },
  { id: 'validation', label: 'Layer 1 & 2 Canonical Validation', matchingStages: ['VALIDATING'] },
  { id: 'persistence', label: 'PostgreSQL UnitOfWork Persistence', matchingStages: ['PERSISTING'] },
  { id: 'digital_twin', label: 'Digital Twin State Synchronization', matchingStages: ['COMPLETED'] },
  { id: 'kpi_engine', label: 'Real-time Fleet KPI Engine', matchingStages: ['COMPLETED'] },
];

export const PipelineStages: React.FC = () => {
  const currentStage = useERPProgressStore((s) => s.snapshot?.stage);

  const getStageStatus = (stageConfig: StageConfig) => {
    if (!currentStage) return 'pending';
    if (currentStage === 'FAILED') return 'failed';
    if (currentStage === 'COMPLETED') return 'completed';

    if (stageConfig.matchingStages.includes(currentStage)) {
      return 'running';
    }

    const currentIndex = STAGES.findIndex((s) => s.matchingStages.includes(currentStage));
    const stageIndex = STAGES.findIndex((s) => s.id === stageConfig.id);

    if (stageIndex < currentIndex) return 'completed';
    return 'pending';
  };

  return (
    <div className="p-6 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4">
      <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
        Full Pipeline Progression
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {STAGES.map((stage) => {
          const status = getStageStatus(stage);
          return (
            <div
              key={stage.id}
              className={`p-3 rounded-lg border flex items-center gap-3 transition-all ${
                status === 'running'
                  ? 'bg-indigo-500/10 border-indigo-500/50 text-indigo-300'
                  : status === 'completed'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  : status === 'failed'
                  ? 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                  : 'bg-slate-800/40 border-slate-700/40 text-slate-500'
              }`}
            >
              {status === 'running' && <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />}
              {status === 'completed' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
              {status === 'failed' && <AlertTriangle className="w-4 h-4 text-rose-400" />}
              {status === 'pending' && <Circle className="w-4 h-4 text-slate-600" />}

              <span className="text-xs font-medium">{stage.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
