import React from 'react';
import { Activity, Clock, Cpu, HardDrive, Gauge } from 'lucide-react';
import { useERPProgressStore } from '../stores';

export const LivePipelineVisualization: React.FC = () => {
  const snapshot = useERPProgressStore((s) => s.snapshot);
  const isStreaming = useERPProgressStore((s) => s.isStreaming);

  if (!isStreaming && !snapshot) {
    return (
      <div className="p-6 rounded-xl bg-slate-900/60 border border-slate-800 text-center text-slate-500">
        <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">No active import pipeline. Upload a workbook to stream live metrics.</p>
      </div>
    );
  }

  return (
    <div className="p-6 rounded-xl bg-slate-900/90 border border-slate-800 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100">Live Ingestion Telemetry</h3>
            <p className="text-xs text-slate-400">
              Job: {snapshot?.job_id || 'Connecting...'} • Worker: {snapshot?.worker_id || 'worker-01'}
            </p>
          </div>
        </div>

        <span className="px-3 py-1 text-xs font-semibold rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
          {snapshot?.stage || 'STREAMING'}
        </span>
      </div>

      {/* Progress Bar */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-slate-400">Ingestion Progress</span>
          <span className="font-semibold text-indigo-400">{snapshot?.percentage || 0}%</span>
        </div>
        <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 transition-all duration-300 ease-out"
            style={{ width: `${snapshot?.percentage || 0}%` }}
          />
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <Gauge className="w-3.5 h-3.5 text-indigo-400" />
            Throughput
          </div>
          <p className="text-lg font-bold text-slate-100">
            {snapshot?.throughput_rows_per_sec || 0} <span className="text-xs text-slate-400 font-normal">rows/sec</span>
          </p>
        </div>

        <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <Clock className="w-3.5 h-3.5 text-purple-400" />
            Elapsed / ETA
          </div>
          <p className="text-lg font-bold text-slate-100">
            {snapshot?.elapsed_seconds || 0}s <span className="text-xs text-slate-400 font-normal">/ {snapshot?.eta_seconds || 0}s</span>
          </p>
        </div>

        <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            Memory Usage
          </div>
          <p className="text-lg font-bold text-slate-100">
            {snapshot?.memory_mb || 0} <span className="text-xs text-slate-400 font-normal">MB</span>
          </p>
        </div>

        <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <HardDrive className="w-3.5 h-3.5 text-amber-400" />
            Rows Ingested
          </div>
          <p className="text-lg font-bold text-slate-100">
            {snapshot?.rows_processed || 0} <span className="text-xs text-slate-400 font-normal">/ {snapshot?.rows_total || 0}</span>
          </p>
        </div>
      </div>
    </div>
  );
};
