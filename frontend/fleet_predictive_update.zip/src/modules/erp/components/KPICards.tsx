import React from 'react';
import { Database, CheckCircle, AlertTriangle, Gauge, Layers, ShieldCheck } from 'lucide-react';
import { useERPStatisticsStore, useERPJobsStore } from '../stores';

export const KPICards: React.FC = () => {
  const stats = useERPStatisticsStore((s) => s.statistics);
  const totalJobs = useERPJobsStore((s) => s.totalRecords);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
        <div className="flex items-center justify-between text-slate-400">
          <span className="text-xs">Total Imports</span>
          <Database className="w-4 h-4 text-indigo-400" />
        </div>
        <p className="text-2xl font-bold text-slate-100">{totalJobs || stats?.total_imports || 0}</p>
      </div>

      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
        <div className="flex items-center justify-between text-slate-400">
          <span className="text-xs">Completed</span>
          <CheckCircle className="w-4 h-4 text-emerald-400" />
        </div>
        <p className="text-2xl font-bold text-emerald-400">{stats?.completed_imports || 0}</p>
      </div>

      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
        <div className="flex items-center justify-between text-slate-400">
          <span className="text-xs">Failed</span>
          <AlertTriangle className="w-4 h-4 text-rose-400" />
        </div>
        <p className="text-2xl font-bold text-rose-400">{stats?.failed_imports || 0}</p>
      </div>

      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
        <div className="flex items-center justify-between text-slate-400">
          <span className="text-xs">Rows Ingested</span>
          <Layers className="w-4 h-4 text-purple-400" />
        </div>
        <p className="text-2xl font-bold text-slate-100">{stats?.total_rows_imported || 0}</p>
      </div>

      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
        <div className="flex items-center justify-between text-slate-400">
          <span className="text-xs">Avg Throughput</span>
          <Gauge className="w-4 h-4 text-amber-400" />
        </div>
        <p className="text-2xl font-bold text-slate-100">
          {stats?.average_throughput_rows_per_sec || 2400} <span className="text-xs text-slate-500 font-normal">r/s</span>
        </p>
      </div>

      <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
        <div className="flex items-center justify-between text-slate-400">
          <span className="text-xs">Data Confidence</span>
          <ShieldCheck className="w-4 h-4 text-teal-400" />
        </div>
        <p className="text-2xl font-bold text-teal-400">100%</p>
      </div>
    </div>
  );
};
