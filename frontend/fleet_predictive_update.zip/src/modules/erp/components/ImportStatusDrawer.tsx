import React from 'react';
import { X, RefreshCw } from 'lucide-react';
import { ImportJobResponse } from '../types';
import { useERPJobsStore } from '../stores';

interface Props {
  job: ImportJobResponse | null;
  onClose: () => void;
}

export const ImportStatusDrawer: React.FC<Props> = ({ job, onClose }) => {
  const { cancelJob, retryJob } = useERPJobsStore();

  if (!job) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-full max-w-md bg-slate-900 border-l border-slate-800 shadow-2xl p-6 z-50 flex flex-col justify-between overflow-y-auto">
      <div className="space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-lg font-bold text-slate-100">{job.job_number}</h2>
            <p className="text-xs text-slate-400">Import Job Details & Status</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-200 rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50">
            <span className="text-xs text-slate-400">Status</span>
            <span className="px-2.5 py-1 text-xs font-semibold rounded-full bg-indigo-500/20 text-indigo-300">
              {job.status}
            </span>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">Workbook File</span>
              <span className="text-slate-200 font-mono text-xs">{job.file_name}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">SHA-256 Checksum</span>
              <span className="text-slate-400 font-mono text-xs truncate max-w-[180px]">
                {job.file_hash}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">Total Rows</span>
              <span className="text-slate-200 font-semibold">{job.total_rows}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">Processed Rows</span>
              <span className="text-emerald-400 font-semibold">{job.processed_rows}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">Validation Errors</span>
              <span className="text-rose-400 font-semibold">{job.error_count}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800">
              <span className="text-slate-400">Created At</span>
              <span className="text-slate-300 text-xs">{new Date(job.created_at).toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3 pt-6 border-t border-slate-800">
        <button
          type="button"
          onClick={() => cancelJob(job.job_number)}
          className="flex-1 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-semibold transition"
        >
          Cancel Job
        </button>
        <button
          type="button"
          onClick={() => retryJob(job.job_number)}
          className="flex-1 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-500 text-xs font-semibold transition flex items-center justify-center gap-1"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Retry Job
        </button>
      </div>
    </div>
  );
};
