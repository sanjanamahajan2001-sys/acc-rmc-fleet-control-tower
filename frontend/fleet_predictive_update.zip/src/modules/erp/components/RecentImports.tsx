import React from 'react';
import { FileText, Eye, RotateCcw, XCircle } from 'lucide-react';
import { useERPJobsStore } from '../stores';
import { ImportJobResponse } from '../types';

interface Props {
  onSelectJob: (job: ImportJobResponse) => void;
}

export const RecentImports: React.FC<Props> = ({ onSelectJob }) => {
  const { jobs, loading, cancelJob, retryJob } = useERPJobsStore();

  return (
    <div className="p-6 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <FileText className="w-4 h-4 text-indigo-400" />
          Recent Import Jobs
        </h3>
        <span className="text-xs text-slate-500">Live Ingestion History</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-xs text-slate-400">
              <th className="py-3 px-4">Job Number</th>
              <th className="py-3 px-4">Workbook</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4">Processed / Total</th>
              <th className="py-3 px-4">Errors</th>
              <th className="py-3 px-4">Created At</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-xs">
            {loading ? (
              <tr>
                <td colSpan={7} className="py-6 text-center text-slate-500">
                  Loading import jobs...
                </td>
              </tr>
            ) : jobs.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-6 text-center text-slate-500">
                  No import jobs found. Upload a workbook above to start ingestion.
                </td>
              </tr>
            ) : (
              jobs.map((job) => (
                <tr key={job.id} className="hover:bg-slate-800/30 transition">
                  <td className="py-3 px-4 font-mono font-semibold text-indigo-300">{job.job_number}</td>
                  <td className="py-3 px-4 text-slate-200">{job.file_name}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2.5 py-0.5 rounded-full font-semibold ${
                        job.status === 'COMPLETED' || job.status === 'UPLOADED'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : job.status === 'FAILED'
                          ? 'bg-rose-500/20 text-rose-400'
                          : 'bg-indigo-500/20 text-indigo-300'
                      }`}
                    >
                      {job.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-300 font-mono">
                    {job.processed_rows} / {job.total_rows}
                  </td>
                  <td className="py-3 px-4 text-rose-400 font-mono font-bold">{job.error_count}</td>
                  <td className="py-3 px-4 text-slate-400">{new Date(job.created_at).toLocaleTimeString()}</td>
                  <td className="py-3 px-4 text-right space-x-2">
                    <button
                      type="button"
                      onClick={() => onSelectJob(job)}
                      className="p-1 text-slate-400 hover:text-indigo-300 rounded hover:bg-slate-800"
                      title="Inspect Job"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => retryJob(job.job_number)}
                      className="p-1 text-slate-400 hover:text-emerald-400 rounded hover:bg-slate-800"
                      title="Retry Job"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => cancelJob(job.job_number)}
                      className="p-1 text-slate-400 hover:text-rose-400 rounded hover:bg-slate-800"
                      title="Cancel Job"
                    >
                      <XCircle className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
