import React from 'react';
import { ShieldCheck } from 'lucide-react';
import { useERPProgressStore } from '../stores';

interface VerificationItem {
  id: string;
  label: string;
  check: (stage?: string) => 'PASS' | 'WARNING' | 'PENDING';
}

const CHECKS: VerificationItem[] = [
  { id: 'storage', label: 'Workbook File Stored in Local Storage Provider', check: (s) => (s ? 'PASS' : 'PENDING') },
  { id: 'checksum', label: 'SHA-256 Checksum Streaming Verified', check: (s) => (s ? 'PASS' : 'PENDING') },
  { id: 'validation', label: 'Layer 1 & Layer 2 Validation Rules Passed', check: (s) => (s === 'PERSISTING' || s === 'COMPLETED' ? 'PASS' : 'PENDING') },
  { id: 'persistence', label: 'PostgreSQL UnitOfWork Transaction Committed', check: (s) => (s === 'COMPLETED' ? 'PASS' : 'PENDING') },
  { id: 'audit', label: 'ImportAuditLog Entry Written', check: (s) => (s === 'COMPLETED' ? 'PASS' : 'PENDING') },
  { id: 'metrics', label: 'ImportStatistic & Telemetry Metrics Recorded', check: (s) => (s === 'COMPLETED' ? 'PASS' : 'PENDING') },
];

export const VerificationPanel: React.FC = () => {
  const currentStage = useERPProgressStore((s) => s.snapshot?.stage);

  return (
    <div className="p-6 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4">
      <div className="flex items-center gap-2 text-slate-200">
        <ShieldCheck className="w-5 h-5 text-emerald-400" />
        <h3 className="font-semibold text-sm">Backend Integrity & Verification Panel</h3>
      </div>

      <div className="space-y-2">
        {CHECKS.map((item) => {
          const status = item.check(currentStage);
          return (
            <div
              key={item.id}
              className="flex items-center justify-between p-2.5 rounded-lg bg-slate-800/40 text-xs"
            >
              <span className="text-slate-300">{item.label}</span>
              <span
                className={`px-2 py-0.5 font-bold rounded ${
                  status === 'PASS'
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : status === 'WARNING'
                    ? 'bg-amber-500/20 text-amber-400'
                    : 'bg-slate-700 text-slate-400'
                }`}
              >
                {status}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
