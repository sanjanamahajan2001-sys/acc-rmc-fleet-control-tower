import React from 'react';
import { Clock, CheckCircle2 } from 'lucide-react';
import { useERPProgressStore } from '../stores';

export const ImportTimeline: React.FC = () => {
  const snapshot = useERPProgressStore((s) => s.snapshot);

  const timelineSteps = [
    { stage: 'QUEUED', label: 'Import Job Enqueued', time: 'T+0.00s' },
    { stage: 'PARSING', label: 'Streaming Batch Excel Parsing', time: 'T+0.25s' },
    { stage: 'VALIDATING', label: 'Layer 1 & 2 Canonical Validation', time: 'T+0.80s' },
    { stage: 'PERSISTING', label: 'PostgreSQL Atomic Persistence', time: 'T+1.40s' },
    { stage: 'COMPLETED', label: 'Pipeline Completed & Audit Logged', time: 'T+1.85s' },
  ];

  const currentStageIndex = timelineSteps.findIndex((s) => s.stage === snapshot?.stage);

  return (
    <div className="p-6 rounded-xl bg-slate-900/60 border border-slate-800 space-y-4">
      <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
        <Clock className="w-4 h-4 text-indigo-400" />
        Import Execution Timeline
      </h3>

      <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800">
        {timelineSteps.map((step, index) => {
          const isPassed = currentStageIndex >= 0 && index <= currentStageIndex;
          const isActive = snapshot?.stage === step.stage;

          return (
            <div key={step.stage} className="relative flex items-center justify-between text-xs">
              <div
                className={`absolute -left-6 w-4 h-4 rounded-full flex items-center justify-center transition-all ${
                  isPassed
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-slate-800 border-2 border-slate-700 text-slate-500'
                }`}
              >
                {isPassed ? <CheckCircle2 className="w-3.5 h-3.5" /> : null}
              </div>

              <div>
                <p
                  className={`font-semibold ${
                    isActive
                      ? 'text-indigo-400 animate-pulse'
                      : isPassed
                      ? 'text-emerald-400'
                      : 'text-slate-400'
                  }`}
                >
                  {step.label}
                </p>
                <p className="text-slate-500 font-mono text-[10px]">{step.stage}</p>
              </div>

              <span className={`font-mono ${isPassed ? 'text-emerald-400/80' : 'text-slate-600'}`}>
                {step.time}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
