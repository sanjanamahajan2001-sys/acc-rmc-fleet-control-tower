import React, { useEffect, useState } from 'react';
import { Layers, RefreshCw, Trash2, AlertTriangle, X } from 'lucide-react';
import {
  UploadZone,
  LivePipelineVisualization,
  PipelineStages,
  ImportStatusDrawer,
  VerificationPanel,
  KPICards,
  ImportTimeline,
  RecentImports,
  NotificationToast,
} from '../components';
import {
  useERPJobsStore,
  useERPStatisticsStore,
  useERPNotificationStore,
  useERPProgressStore,
  useERPUploadStore,
} from '../stores';
import { erpApiClient } from '../api';
import { ImportJobResponse } from '../types';

export const ERPImportWorkspacePage: React.FC = () => {
  const [selectedJob, setSelectedJob] = useState<ImportJobResponse | null>(null);
  const [showResetModal, setShowResetModal] = useState(false);
  const [resetting, setResetting] = useState(false);

  const fetchJobs = useERPJobsStore((s) => s.fetchJobs);
  const fetchStatistics = useERPStatisticsStore((s) => s.fetchStatistics);
  const fetchAuditLogs = useERPStatisticsStore((s) => s.fetchAuditLogs);
  const addNotification = useERPNotificationStore((s) => s.addNotification);
  const disconnectSSE = useERPProgressStore((s) => s.disconnectSSE);
  const resetUpload = useERPUploadStore((s) => s.resetUpload);

  useEffect(() => {
    fetchJobs();
    fetchStatistics();
    fetchAuditLogs();
  }, [fetchJobs, fetchStatistics, fetchAuditLogs]);

  const handleRefresh = () => {
    fetchJobs();
    fetchStatistics();
    fetchAuditLogs();
  };

  const handleConfirmReset = async () => {
    setResetting(true);
    try {
      const summary = await erpApiClient.resetDemoData();
      disconnectSSE();
      resetUpload();
      setSelectedJob(null);
      await fetchJobs();
      await fetchStatistics();
      await fetchAuditLogs();
      setShowResetModal(false);
      addNotification(
        'success',
        `Demo data reset complete. ${summary.total_records_deleted} records deleted across ${Object.keys(summary.deleted_counts).length} tables.`
      );
    } catch (err: any) {
      addNotification('error', err.message || 'Demo data reset failed.');
    } finally {
      setResetting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6 md:p-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/20">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-100 tracking-tight">
                ERP Import Workspace
              </h1>
              <p className="text-xs text-slate-400">
                Operational Control Center for Ingestion, Validation & Persistence Telemetry
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setShowResetModal(true)}
            className="px-4 py-2 rounded-lg bg-rose-500/10 border border-rose-500/30 hover:bg-rose-500/20 text-xs font-semibold text-rose-400 flex items-center gap-2 transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Reset Demo Data
          </button>
          <button
            type="button"
            onClick={handleRefresh}
            className="px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 hover:bg-slate-800 text-xs font-semibold text-slate-300 flex items-center gap-2 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh Telemetry
          </button>
        </div>
      </div>

      {/* Real-time KPI Cards */}
      <KPICards />

      {/* Primary Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Upload & Live Streaming */}
        <div className="lg:col-span-2 space-y-6">
          <UploadZone />
          <LivePipelineVisualization />
          <PipelineStages />
          <RecentImports onSelectJob={(job) => setSelectedJob(job)} />
        </div>

        {/* Right Column: Verification & Timeline */}
        <div className="space-y-6">
          <VerificationPanel />
          <ImportTimeline />
        </div>
      </div>

      {/* Admin Reset Modal */}
      {showResetModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 text-rose-400 font-bold">
                <AlertTriangle className="w-5 h-5" />
                <span>Confirm Admin Reset</span>
              </div>
              <button
                type="button"
                onClick={() => setShowResetModal(false)}
                className="p-1 text-slate-400 hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <p className="font-semibold text-slate-100">
                Are you sure you want to reset all ERP demo data?
              </p>
              <p className="text-slate-400">
                This action executes inside a single PostgreSQL transaction to permanently delete:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-slate-400">
                <li>All Import Jobs & Workbook Storage files</li>
                <li>All Ingestion Entities (Plants, Sites, Customers, Vehicles, Drivers, Orders, Tickets, Dispatches, Invoices, Trips)</li>
                <li>Audit Logs, Events, Checkpoints & Statistics</li>
              </ul>
              <p className="p-3 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400">
                ⚠️ Platform authentication, user claims, and core system settings will be preserved.
              </p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowResetModal(false)}
                className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={resetting}
                onClick={handleConfirmReset}
                className="px-4 py-2 rounded-lg bg-rose-600 text-white text-xs font-semibold hover:bg-rose-500 disabled:opacity-50 flex items-center gap-2"
              >
                {resetting ? 'Resetting Data...' : 'Confirm Transactional Reset'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Status Drawer Overlay */}
      <ImportStatusDrawer job={selectedJob} onClose={() => setSelectedJob(null)} />

      {/* Global Toast Notifications */}
      <NotificationToast />
    </div>
  );
};

export default ERPImportWorkspacePage;
