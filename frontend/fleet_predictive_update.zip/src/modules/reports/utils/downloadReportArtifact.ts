import { reportsApiClient } from '../api/reports.api';
import { ReportFormat } from '../types/report.types';

export interface DownloadReportArtifactOptions {
  executionId: string;
  format: ReportFormat | string;
  reportId?: string;
  onSuccess?: () => void;
  onError?: (error: any) => void;
}

export const downloadReportArtifact = async ({
  executionId,
  format,
  reportId,
  onSuccess,
  onError,
}: DownloadReportArtifactOptions): Promise<void> => {
  try {
    const fmtStr = typeof format === 'string' ? format.toLowerCase() : String(format).toLowerCase();
    
    // 1. Get short-lived download token
    const tokenResponse = await reportsApiClient.getDownloadToken(executionId, fmtStr);

    // 2. Fetch binary blob using token
    const blob = await reportsApiClient.downloadArtifact(
      executionId,
      fmtStr,
      tokenResponse.download_token
    );

    // 3. Construct object URL and trigger download
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    
    const fallbackName = `${reportId || 'report'}_${executionId}.${fmtStr}`;
    link.setAttribute('download', fallbackName);
    
    document.body.appendChild(link);
    link.click();

    // 4. Cleanup DOM and Object URL
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);

    if (onSuccess) onSuccess();
  } catch (err: any) {
    if (onError) onError(err);
    throw err;
  }
};
