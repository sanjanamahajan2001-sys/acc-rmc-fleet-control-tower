import React, { useState } from 'react';
import { ReportDefinitionDTO } from '../types/report.types';
import { ReportCatalogCard } from './ReportCatalogCard';
import { TextInput } from '../../../components/inputs/TextInput';
import { Search } from 'lucide-react';

export interface ReportCatalogGridProps {
  catalog: ReportDefinitionDTO[];
  onExportSelect: (report: ReportDefinitionDTO) => void;
}

export const ReportCatalogGrid: React.FC<ReportCatalogGridProps> = ({ catalog = [], onExportSelect }) => {
  const [searchQuery, setSearchQuery] = useState<string>('');

  const safeCatalog = Array.isArray(catalog) ? catalog : [];
  const filteredCatalog = safeCatalog.filter((item) => {
    if (item.report_id === 'erp_data_explorer') return false;
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      item.title.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      item.report_id.toLowerCase().includes(q) ||
      (item.category && item.category.toLowerCase().includes(q))
    );
  });



  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 16 }}>
        <div style={{ position: 'relative', width: '100%', maxWidth: 360 }}>
          <TextInput
            placeholder="Search report catalog..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            data-testid="catalog-search-input"
          />
          <Search
            size={16}
            style={{
              position: 'absolute',
              right: 12,
              top: '50%',
              transform: 'translateY(-50%)',
              color: '#64748B',
              pointerEvents: 'none',
            }}
          />
        </div>
        <div style={{ fontSize: 12, color: '#94A3B8' }}>
          Showing {filteredCatalog.length} of {catalog.length} reports
        </div>
      </div>

      {filteredCatalog.length === 0 ? (
        <div
          style={{
            padding: 40,
            textAlign: 'center',
            backgroundColor: '#0F172A',
            borderRadius: 8,
            border: '1px dashed #1E293B',
            color: '#94A3B8',
            fontSize: 14,
          }}
          data-testid="catalog-empty-state"
        >
          No reports match your search criteria.
        </div>
      ) : (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
            gap: 20,
          }}
          data-testid="catalog-grid-container"
        >
          {filteredCatalog.map((report) => (
            <ReportCatalogCard key={report.report_id} report={report} onExportSelect={onExportSelect} />
          ))}
        </div>
      )}
    </div>
  );
};
