import React from 'react';
import { Button } from '../../../components/inputs/Button';
import { ReportDefinitionDTO } from '../types/report.types';
import { FileText, Download } from 'lucide-react';

export interface ReportCatalogCardProps {
  report: ReportDefinitionDTO;
  onExportSelect: (report: ReportDefinitionDTO) => void;
}

export const ReportCatalogCard: React.FC<ReportCatalogCardProps> = ({ report, onExportSelect }) => {
  return (
    <div
      className="glass-card"
      style={{
        padding: 20,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',

        gap: 12,
        borderRadius: 8,
        border: '1px solid rgba(255, 255, 255, 0.08)',
        backgroundColor: '#0F172A',
      }}
      data-testid={`report-card-${report.report_id}`}
    >
      <div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <FileText size={18} style={{ color: '#38BDF8' }} />
            <span style={{ fontSize: 11, fontWeight: 700, color: '#38BDF8', letterSpacing: '0.05em' }}>
              {(report.category || 'GENERAL').toUpperCase()}
            </span>
          </div>
          {report.is_active ? (
            <span style={{ fontSize: 10, padding: '2px 8px', borderRadius: 10, backgroundColor: 'rgba(52, 211, 153, 0.15)', color: '#34D399', fontWeight: 600 }}>
              ACTIVE
            </span>
          ) : (
            <span style={{ fontSize: 10, padding: '2px 8px', borderRadius: 10, backgroundColor: 'rgba(248, 113, 113, 0.15)', color: '#F87171', fontWeight: 600 }}>
              DISABLED
            </span>
          )}
        </div>
        
        <h3 style={{ fontSize: 16, fontWeight: 600, color: '#F8FAFC', marginBottom: 6 }}>{report.title}</h3>
        <p style={{ fontSize: 13, color: '#94A3B8', lineHeight: 1.4, minHeight: 36 }}>{report.description}</p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, paddingTop: 12, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 11, color: '#64748B' }}>Formats:</span>
          <div style={{ display: 'flex', gap: 4 }}>
            {report.supported_formats.map((fmt) => (
              <span
                key={fmt}
                style={{
                  fontSize: 10,
                  fontWeight: 600,
                  padding: '2px 6px',
                  borderRadius: 4,
                  backgroundColor: '#1E293B',
                  color: '#CBD5E1',
                  border: '1px solid rgba(255,255,255,0.05)',
                }}
              >
                {fmt}
              </span>
            ))}
          </div>
        </div>

        <Button
          variant="primary"
          size="sm"
          disabled={!report.is_active}
          onClick={() => onExportSelect(report)}
          icon={<Download size={14} />}
          data-testid={`export-btn-${report.report_id}`}
        >
          Export Report
        </Button>
      </div>
    </div>
  );
};
