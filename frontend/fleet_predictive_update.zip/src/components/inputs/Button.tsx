import React from 'react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  style,
  disabled,
  ...props
}) => {
  const getBgColor = () => {
    if (disabled) return '#334155';
    switch (variant) {
      case 'primary':
        return '#38BDF8';
      case 'secondary':
        return '#1E293B';
      case 'danger':
        return '#EF4444';
      case 'outline':
        return 'transparent';
    }
  };

  const getTextColor = () => {
    if (disabled) return '#64748B';
    return variant === 'primary' ? '#0F172A' : '#F8FAFC';
  };

  const getPadding = () => {
    switch (size) {
      case 'sm':
        return '4px 10px';
      case 'lg':
        return '10px 20px';
      default:
        return '6px 14px';
    }
  };

  return (
    <button
      disabled={disabled}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        backgroundColor: getBgColor(),
        color: getTextColor(),
        border: variant === 'outline' ? '1px solid rgba(255,255,255,0.2)' : 'none',
        borderRadius: 4,
        padding: getPadding(),
        fontSize: size === 'sm' ? 12 : 13,
        fontWeight: 600,
        cursor: disabled ? 'not-allowed' : 'pointer',
        transition: 'all 0.15s ease',
        ...style,
      }}
      {...props}
    >
      {icon && <span>{icon}</span>}
      {children}
    </button>
  );
};
