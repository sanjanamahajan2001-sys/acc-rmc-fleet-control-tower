import React from 'react';

export interface SelectOption {
  label: string;
  value: string | number;
}

export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  options: SelectOption[];
  error?: string;
}

export const Select: React.FC<SelectProps> = ({ label, options, error, style, ...props }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
    {label && <label style={{ fontSize: 12, color: '#94A3B8', fontWeight: 500 }}>{label}</label>}
    <select
      style={{
        backgroundColor: '#1E293B',
        border: error ? '1px solid #EF4444' : '1px solid rgba(255,255,255,0.1)',
        borderRadius: 4,
        padding: '6px 12px',
        color: '#F8FAFC',
        fontSize: 13,
        outline: 'none',
        ...style,
      }}
      {...props}
    >
      {options.map((opt) => (
        <option key={opt.value} value={opt.value}>
          {opt.label}
        </option>
      ))}
    </select>
    {error && <span style={{ fontSize: 11, color: '#EF4444' }}>{error}</span>}
  </div>
);
