import React from 'react';

export interface TextInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const TextInput: React.FC<TextInputProps> = ({ label, error, style, ...props }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
    {label && <label style={{ fontSize: 12, color: '#94A3B8', fontWeight: 500 }}>{label}</label>}
    <input
      style={{
        backgroundColor: '#1E293B',
        border: error ? '1px solid #EF4444' : '1px solid rgba(255,255,255,0.1)',
        borderRadius: 4,
        padding: '6px 12px',
        color: '#F8FAFC',
        fontSize: 13,
        outline: 'none',
        ...style,
      }}
      {...props}
    />
    {error && <span style={{ fontSize: 11, color: '#EF4444' }}>{error}</span>}
  </div>
);
