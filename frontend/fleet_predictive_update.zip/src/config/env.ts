export interface EnvConfig {
  VITE_API_BASE_URL: string;
  VITE_ENVIRONMENT: string;
  VITE_APP_TITLE: string;
}

export const env: EnvConfig = {
  VITE_API_BASE_URL: import.meta.env.VITE_API_BASE_URL || '/fleet-api/v1',
  VITE_ENVIRONMENT: import.meta.env.VITE_ENVIRONMENT || 'development',
  VITE_APP_TITLE: import.meta.env.VITE_APP_TITLE || 'Fleet Control Tower',
};
