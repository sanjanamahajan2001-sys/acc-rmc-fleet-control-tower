import { create } from 'zustand';
import { APP_CONSTANTS } from '../config/constants';
import { UserClaims } from '../types/auth';

interface AuthState {
  token: string | null;
  user: UserClaims | null;
  setAuth: (token: string, user: UserClaims) => void;
  clearAuth: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  token: localStorage.getItem(APP_CONSTANTS.STORAGE_KEYS.AUTH_TOKEN),
  user: null,
  setAuth: (token: string, user: UserClaims) => {
    localStorage.setItem(APP_CONSTANTS.STORAGE_KEYS.AUTH_TOKEN, token);
    set({ token, user });
  },
  clearAuth: () => {
    localStorage.removeItem(APP_CONSTANTS.STORAGE_KEYS.AUTH_TOKEN);
    set({ token: null, user: null });
  },
}));
